/*
  =====================================================================
  ADVANCED SMOKE / AIR QUALITY MONITOR
  =====================================================================
  Hardware : Arduino Uno/Nano, MQ-135 (analog), 16x2 I2C LCD,
             Green LED, Red LED, Buzzer

  Upgrades over the basic version:
   1. Non-blocking timing (no delay() in loop) using millis()
   2. Rolling average filter to smooth noisy ADC readings
   3. Hysteresis on thresholds to stop state "flickering" at the edges
   4. Auto baseline calibration at boot + EEPROM persistence
   5. Non-blocking buzzer patterns (slow beep = warning, fast/solid = critical)
   6. Clean state machine (enum) instead of nested if/else duplication
   7. LCD only redraws when something actually changed (less flicker)
   8. Serial debug as one-line JSON for reliable PC/dashboard ingestion
   9. Custom LCD icons (warning triangle / skull-ish flame) for feedback
  =====================================================================
*/

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>

// ---------------------------------------------------------------------
// Hardware configuration
// ---------------------------------------------------------------------
LiquidCrystal_I2C lcd(0x27, 16, 2);

#define MQ135_PIN     A0
#define GREEN_LED     6
#define RED_LED       7
#define BUZZER        8

// ---------------------------------------------------------------------
// AI-SAFE thresholds (absolute MQ-135 ADC units, 0-1023).
// These start from ZERO and match the dashboard defaults.
// ---------------------------------------------------------------------
const int WARNING_THRESHOLD  = 500;
const int CRITICAL_THRESHOLD = 700;
const int HYSTERESIS         = 20;

// ---------------------------------------------------------------------
// Timing
// ---------------------------------------------------------------------
const unsigned long SENSOR_INTERVAL_MS = 250;   // how often we sample
const unsigned long LCD_INTERVAL_MS    = 500;   // how often we refresh LCD
const unsigned long SERIAL_INTERVAL_MS = 1000;  // how often we log to serial

const unsigned long WARNING_BEEP_ON_MS  = 100;
const unsigned long WARNING_BEEP_OFF_MS = 900;
const unsigned long CRITICAL_BEEP_ON_MS  = 150;
const unsigned long CRITICAL_BEEP_OFF_MS = 150;

// ---------------------------------------------------------------------
// Smoothing filter
// ---------------------------------------------------------------------
const uint8_t SAMPLE_COUNT = 10;
int samples[SAMPLE_COUNT];
uint8_t sampleIndex = 0;
long sampleSum = 0;
bool bufferFilled = false;

// ---------------------------------------------------------------------
// EEPROM
// ---------------------------------------------------------------------
const int EEPROM_ADDR_BASELINE = 0;   // stores int (2 bytes)
const int EEPROM_MAGIC_ADDR    = 2;   // stores a "has been calibrated" flag
const byte EEPROM_MAGIC_VALUE  = 0x42;

int baseline = 0;

// ---------------------------------------------------------------------
// State machine
// ---------------------------------------------------------------------
enum AirState { SAFE, WARNING, CRITICAL };
AirState currentState = SAFE;
AirState lastDrawnState = SAFE; // forces first LCD draw

// ---------------------------------------------------------------------
// Non-blocking scheduling variables
// ---------------------------------------------------------------------
unsigned long lastSensorRead = 0;
unsigned long lastLcdUpdate  = 0;
unsigned long lastSerialLog  = 0;
unsigned long lastBuzzerToggle = 0;
bool buzzerState = false;

int smoothedValue = 0;
int lastDrawnValue = -1;

// ---------------------------------------------------------------------
// Custom LCD characters
// ---------------------------------------------------------------------
byte warnIcon[8] = {
  0b00100, 0b00100, 0b01110, 0b01010,
  0b11111, 0b00000, 0b00100, 0b00000
};

byte flameIcon[8] = {
  0b00100, 0b00110, 0b01011, 0b01101,
  0b01111, 0b00111, 0b00010, 0b00000
};

// =====================================================================
void setup() {
  Serial.begin(9600);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  lcd.init();
  lcd.backlight();
  lcd.createChar(0, warnIcon);
  lcd.createChar(1, flameIcon);

  lcd.setCursor(0, 0);
  lcd.print("Smoke Monitor");
  lcd.setCursor(0, 1);
  lcd.print("Calibrating...");

  calibrateBaseline();

  lcd.clear();

  // Prime the smoothing buffer so the first readings aren't skewed
  for (uint8_t i = 0; i < SAMPLE_COUNT; i++) {
    samples[i] = analogRead(MQ135_PIN);
    sampleSum += samples[i];
  }
  bufferFilled = true;
  smoothedValue = sampleSum / SAMPLE_COUNT;
}

// =====================================================================
void loop() {
  unsigned long now = millis();

  if (now - lastSensorRead >= SENSOR_INTERVAL_MS) {
    lastSensorRead = now;
    readSensor();
    updateState();
  }

  updateOutputs(now);

  if (now - lastLcdUpdate >= LCD_INTERVAL_MS) {
    lastLcdUpdate = now;
    updateLCD();
  }

  if (now - lastSerialLog >= SERIAL_INTERVAL_MS) {
    lastSerialLog = now;
    logSerial(now);
  }
}

// =====================================================================
// Calibration: average 50 readings at boot to establish "clean air"
// baseline, unless a valid one is already stored in EEPROM.
// =====================================================================
void calibrateBaseline() {
  byte magic;
  EEPROM.get(EEPROM_MAGIC_ADDR, magic);

  if (magic == EEPROM_MAGIC_VALUE) {
    EEPROM.get(EEPROM_ADDR_BASELINE, baseline);
    Serial.print("Loaded baseline from EEPROM: ");
    Serial.println(baseline);
    return;
  }

  long total = 0;
  const int CAL_SAMPLES = 50;
  for (int i = 0; i < CAL_SAMPLES; i++) {
    total += analogRead(MQ135_PIN);
    delay(20); // acceptable here: only runs once, before loop() starts
  }
  baseline = total / CAL_SAMPLES;

  EEPROM.put(EEPROM_ADDR_BASELINE, baseline);
  EEPROM.put(EEPROM_MAGIC_ADDR, EEPROM_MAGIC_VALUE);

  Serial.print("New baseline calibrated: ");
  Serial.println(baseline);
}

// =====================================================================
// Read sensor into rolling average buffer
// =====================================================================
void readSensor() {
  int raw = analogRead(MQ135_PIN);

  sampleSum -= samples[sampleIndex];
  samples[sampleIndex] = raw;
  sampleSum += raw;
  sampleIndex = (sampleIndex + 1) % SAMPLE_COUNT;

  smoothedValue = sampleSum / SAMPLE_COUNT;
}

// =====================================================================
// State machine with hysteresis so it doesn't flicker at the boundary
// =====================================================================
void updateState() {
  int warningThreshold  = WARNING_THRESHOLD;
  int criticalThreshold = CRITICAL_THRESHOLD;

  switch (currentState) {

    case SAFE:
      if (smoothedValue >= warningThreshold) currentState = WARNING;
      break;

    case WARNING:
      if (smoothedValue >= criticalThreshold) currentState = CRITICAL;
      else if (smoothedValue < warningThreshold - HYSTERESIS) currentState = SAFE;
      break;

    case CRITICAL:
      if (smoothedValue < criticalThreshold - HYSTERESIS) currentState = WARNING;
      break;
  }
}

// =====================================================================
// Drive LEDs + non-blocking buzzer pattern based on state
// =====================================================================
void updateOutputs(unsigned long now) {
  switch (currentState) {

    case SAFE:
      digitalWrite(GREEN_LED, HIGH);
      digitalWrite(RED_LED, LOW);
      digitalWrite(BUZZER, LOW);
      buzzerState = false;
      break;

    case WARNING:
      digitalWrite(GREEN_LED, LOW);
      digitalWrite(RED_LED, HIGH);
      runBuzzerPattern(now, WARNING_BEEP_ON_MS, WARNING_BEEP_OFF_MS);
      break;

    case CRITICAL:
      digitalWrite(GREEN_LED, LOW);
      digitalWrite(RED_LED, HIGH);
      runBuzzerPattern(now, CRITICAL_BEEP_ON_MS, CRITICAL_BEEP_OFF_MS);
      break;
  }
}

// Toggles the buzzer on/off at custom on/off durations without delay()
void runBuzzerPattern(unsigned long now, unsigned long onMs, unsigned long offMs) {
  unsigned long interval = buzzerState ? onMs : offMs;

  if (now - lastBuzzerToggle >= interval) {
    lastBuzzerToggle = now;
    buzzerState = !buzzerState;
    digitalWrite(BUZZER, buzzerState ? HIGH : LOW);
  }
}

// =====================================================================
// LCD update — only rewrites what changed to minimize flicker
// =====================================================================
void updateLCD() {
  if (smoothedValue != lastDrawnValue) {
    lcd.setCursor(0, 0);
    lcd.print("Smoke: ");
    lcd.print(smoothedValue);
    lcd.print("    "); // clear trailing digits
    lastDrawnValue = smoothedValue;
  }

  if (currentState != lastDrawnState) {
    lcd.setCursor(0, 1);
    switch (currentState) {
      case SAFE:
        lcd.print("Status: SAFE    ");
        break;
      case WARNING:
        lcd.write(byte(0)); // warning icon
        lcd.print(" WARNING       ");
        break;
      case CRITICAL:
        lcd.write(byte(1)); // flame icon
        lcd.print(" CRITICAL!     ");
        break;
    }
    lastDrawnState = currentState;
  }
}

// =====================================================================
// Serial protocol used by AI-SAFE.
// One JSON object per line makes the Arduino -> PC connection reliable.
// The PC software reads this continuously and updates the dashboard/database.
// =====================================================================
void logSerial(unsigned long now) {
  const char* stateText = "SAFE";
  if (currentState == WARNING) stateText = "WARNING";
  if (currentState == CRITICAL) stateText = "CRITICAL";

  Serial.print("{");
  Serial.print("\"mq135\":"); Serial.print(smoothedValue);
  Serial.print(",\"raw\":"); Serial.print(analogRead(MQ135_PIN));
  Serial.print(",\"baseline\":"); Serial.print(baseline);
  Serial.print(",\"warning_threshold\":"); Serial.print(WARNING_THRESHOLD);
  Serial.print(",\"critical_threshold\":"); Serial.print(CRITICAL_THRESHOLD);
  Serial.print(",\"state\":\""); Serial.print(stateText); Serial.print("\"");
  Serial.print(",\"uptime_ms\":"); Serial.print(now);
  Serial.println("}");
}
