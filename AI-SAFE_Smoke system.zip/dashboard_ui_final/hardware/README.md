# AI-SAFE Simple Hardware

Components:
- Arduino UNO
- MQ-135 gas sensor -> A0
- PC/AI monitoring temperature/humidity sensor -> D2
- LED -> D13
- Buzzer -> D8

## Wiring

MQ-135: VCC -> 5V, GND -> GND, AO -> A0
PC/AI monitoring: VCC -> 5V, GND -> GND, DATA -> D2
LED: use the onboard LED on D13 (no extra wiring required)
Buzzer: + -> D8 through a suitable resistor/transistor driver if required, - -> GND

## Arduino

Install the `DHT sensor library` in Arduino IDE and upload `AI_SAFE_Arduino_MQ135_PC/AI monitoring.ino`.

## Flask

Install requirements, then set the serial port if needed:

Windows PowerShell: `$env:ARDUINO_PORT="COM3"`

The dashboard Refresh button calls `/api/hardware/read`, reads one JSON line from Arduino, and updates the live hardware cards.

The Gas Index is a simple 0-100 project/demo mapping of MQ-135 raw ADC data. It is **not an official regulatory AQI calculation**.
