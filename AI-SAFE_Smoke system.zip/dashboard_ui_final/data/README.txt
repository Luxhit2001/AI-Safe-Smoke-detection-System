The supplied air-quality datasets have been imported into instance/ai_safe.db.

file1.csv = Dataset 1 (1,600,000 rows)
file2.csv = Dataset 2 (20,000 rows)

The dashboard uses the SQLite database for normal operation.
