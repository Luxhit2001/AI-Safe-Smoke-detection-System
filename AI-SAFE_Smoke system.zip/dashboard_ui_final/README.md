# AI-SAFE Smoke Detection & Alert System

AI-SAFE is a Flask-based college project for smoke detection, air-quality monitoring, alerts, incidents, emergency response and user management.

## 🔐 Secure Gmail OTP Login

This version has two-step email verification:

**Registration:**
`Create account → OTP to personal Gmail → Verify OTP → Account created`

**Login:**
`Username + Password → OTP to verified Gmail → Verify OTP → Dashboard`

### Easiest Windows setup

1. Open the AI-SAFE folder.
2. Double-click **`START_AI_SAFE.bat`**.
3. On the first run, enter:
   - Sender Gmail address
   - Google Gmail App Password
   - Admin personal Gmail address
4. The program automatically starts.
5. Open **http://127.0.0.1:5000**.

The setup creates a private `.env` file and automatically generates the AI-SAFE secret key.

### Google App Password

Use a dedicated Gmail sender account if possible. Turn on Google 2-Step Verification first, then create an App Password for AI-SAFE.

**Never use or save your normal Gmail password in AI-SAFE.**

For detailed Gmail steps, see `EMAIL_OTP_SETUP.md`.

## Demo admin

Username: `admin`
Password: `admin123`

The admin password is still the project demo password. For a real deployment, change it before use.

## Run manually

```text
pip install -r requirements.txt
python app.py
```

Then open:

```text
http://127.0.0.1:5000
```

## Important files

- `app.py` — Flask application and authentication
- `templates/login.html` — login page
- `templates/register.html` — registration page
- `templates/verify_otp.html` — OTP page
- `setup_email.py` — simple first-time Gmail setup
- `START_AI_SAFE.bat` — one-click Windows startup
- `.env` — private Gmail settings (created on first setup; do not share it)
- `instance/ai_safe.db` — local SQLite database

## OTP security controls

- 6-digit cryptographically random OTP
- 5-minute expiration
- 5 incorrect attempts maximum
- 60-second resend cooldown
- Hashed OTP storage
- Passwords stored as Werkzeug password hashes
- HTTP-only session cookies
- Same-site session cookies
- Secure cookie option available for HTTPS

## Arduino

The Arduino Uno R3 remains responsible for sensor readings. The PC handles the web dashboard and other processing.

## Security and demo/live data notes
- The admin password is no longer hard-coded. Set `AI_SAFE_ADMIN_PASSWORD` before first startup. If omitted, AI-SAFE creates a random first-run password in `instance/ADMIN_CREDENTIALS.txt` and prints it to the console. Admin password reset requires a verified admin email and SMTP configuration.
- Forgot Password now uses a verified email + one-time OTP and requires Gmail SMTP configuration.
- Seeded stations/incidents/sensor readings/notifications are explicitly marked as `demo` data. Arduino readings and manually created incidents are marked `live`.
- Punjab Station 01 and its demo safety-zone coordinates are now in Punjab (Patiala area), not Dehradun.

## 🔴 Real-time Arduino → AI-SAFE integration

The project now uses a **continuous Arduino USB serial reader** instead of opening COM3 for every browser request.

### Data flow

`MQ-135 → Arduino UNO R3 → USB Serial → Flask background reader → SQLite → Dashboard → In-app + Browser notification`

- Arduino sends one JSON reading about every second.
- Flask keeps the serial connection open and continuously stores valid readings as `live`.
- The dashboard checks the latest hardware value every **1 second**.
- Threshold notifications are generated immediately when a configured threshold is crossed.
- The notification bell, alert list, smoke chart, status cards and live sensor page use the live value.
- Clicking a browser notification can return to the AI-SAFE dashboard.
- Live sensor history can be exported from `/api/sensor-data/export.csv` while logged in.

### Arduino configuration

Edit `.env` if your Arduino is not on COM3:

```text
ARDUINO_PORT=COM3
ARDUINO_BAUD=9600
ARDUINO_STATION_ID=1
```

Find the correct COM port in **Windows Device Manager → Ports (COM & LPT)**.

### Upload the correct sketch

Use:

`hardware/AI_SAFE_Arduino_MQ135.ino`

The sketch is configured for:

- MQ-135 → A0
- Green LED → D6
- Red LED → D7
- Buzzer → D8
- 16x2 I2C LCD → SDA/SCL
- Serial → 9600 baud

The Arduino sends JSON such as:

```text
{"mq135":420,"raw":425,"baseline":310,"warning_threshold":500,"critical_threshold":700,"state":"SAFE","uptime_ms":12345}
```

The software also accepts the older `millis,smoothed,state` CSV format for compatibility.

### Browser notifications

Open the dashboard and use **Enable Browser Notifications** in the notification/settings area once. Browser permission must be granted by the user.

Default smoke thresholds are:

- **0–299:** Normal
- **300–499:** Elevated
- **500–699:** Warning
- **700+:** Critical

These are project thresholds for the MQ-135's raw ADC reading, not a certified ppm/AQI measurement.

### Important

Keep the Arduino Serial Monitor closed while AI-SAFE is running. Only one application can normally own the COM port at a time. If the dashboard says **Waiting for Arduino**, verify the USB cable, COM port, 9600 baud setting, and that no Serial Monitor is open.
