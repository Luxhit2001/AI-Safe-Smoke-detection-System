import csv
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB = BASE_DIR / 'instance' / 'ai_safe.db'
DATA_DIR = BASE_DIR / 'data'
SOURCES = [('Dataset 1', DATA_DIR / 'file1.csv'), ('Dataset 2', DATA_DIR / 'file2.csv')]


def num(value):
    if value in (None, ''):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def import_file(conn, source, path):
    print(f'Importing {source}: {path.name}')
    conn.execute('DELETE FROM air_quality WHERE source = ?', (source,))
    batch, count = [], 0
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        for count, row in enumerate(reader, 1):
            batch.append((source, count, num(row.get('no2')), num(row.get('co')), num(row.get('pm10')), num(row.get('pm25')),
                          num(row.get('AQI(NO2)')), num(row.get('AQI(CO)')), num(row.get('AQI(PM10)')), num(row.get('AQI(PM2.5)')),
                          num(row.get('AQI(overall)')), (row.get('Remarks') or '').strip()))
            if len(batch) >= 5000:
                conn.executemany('''INSERT INTO air_quality
                    (source,row_number,no2,co,pm10,pm25,aqi_no2,aqi_co,aqi_pm10,aqi_pm25,aqi_overall,remarks)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''', batch)
                batch.clear()
                if count % 100000 == 0:
                    print(f'  {count:,} rows...')
        if batch:
            conn.executemany('''INSERT INTO air_quality
                (source,row_number,no2,co,pm10,pm25,aqi_no2,aqi_co,aqi_pm10,aqi_pm25,aqi_overall,remarks)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''', batch)
    print(f'  done: {count:,} rows')


def main():
    if not all(p.exists() for _, p in SOURCES):
        raise SystemExit('Both data files must exist in data/')
    DB.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS air_quality (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL,
            row_number INTEGER NOT NULL,
            no2 REAL, co REAL, pm10 REAL, pm25 REAL,
            aqi_no2 REAL, aqi_co REAL, aqi_pm10 REAL, aqi_pm25 REAL,
            aqi_overall REAL, remarks TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_air_quality_source_id ON air_quality(source, id);
        CREATE INDEX IF NOT EXISTS idx_air_quality_source_row ON air_quality(source, row_number);
        CREATE TABLE IF NOT EXISTS air_quality_summary (
            source TEXT PRIMARY KEY, total_rows INTEGER NOT NULL,
            avg_no2 REAL, avg_co REAL, avg_pm10 REAL, avg_pm25 REAL,
            avg_aqi REAL, max_aqi REAL, min_aqi REAL,
            latest_no2 REAL, latest_co REAL, latest_pm10 REAL, latest_pm25 REAL,
            latest_aqi REAL, latest_remarks TEXT
        );
        CREATE TABLE IF NOT EXISTS air_quality_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, row_number INTEGER NOT NULL,
            no2 REAL, co REAL, pm10 REAL, pm25 REAL, aqi_overall REAL, remarks TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_air_samples_source_row ON air_quality_samples(source, row_number);
    ''')
    conn.execute('DELETE FROM air_quality_summary')
    conn.execute('DELETE FROM air_quality_samples')
    for source, path in SOURCES:
        import_file(conn, source, path)
        conn.execute('''
            INSERT INTO air_quality_summary
            (source,total_rows,avg_no2,avg_co,avg_pm10,avg_pm25,avg_aqi,max_aqi,min_aqi,
             latest_no2,latest_co,latest_pm10,latest_pm25,latest_aqi,latest_remarks)
            SELECT source, COUNT(*), AVG(no2), AVG(co), AVG(pm10), AVG(pm25), AVG(aqi_overall),
                   MAX(aqi_overall), MIN(aqi_overall),
                   (SELECT no2 FROM air_quality x WHERE x.source=a.source ORDER BY row_number DESC LIMIT 1),
                   (SELECT co FROM air_quality x WHERE x.source=a.source ORDER BY row_number DESC LIMIT 1),
                   (SELECT pm10 FROM air_quality x WHERE x.source=a.source ORDER BY row_number DESC LIMIT 1),
                   (SELECT pm25 FROM air_quality x WHERE x.source=a.source ORDER BY row_number DESC LIMIT 1),
                   (SELECT aqi_overall FROM air_quality x WHERE x.source=a.source ORDER BY row_number DESC LIMIT 1),
                   (SELECT remarks FROM air_quality x WHERE x.source=a.source ORDER BY row_number DESC LIMIT 1)
            FROM air_quality a WHERE source=? GROUP BY source
        ''', (source,))
        conn.execute('''
            INSERT INTO air_quality_samples(source,row_number,no2,co,pm10,pm25,aqi_overall,remarks)
            SELECT source,row_number,no2,co,pm10,pm25,aqi_overall,remarks
            FROM air_quality WHERE source=? AND (row_number % 10000=0 OR row_number=1)
            ORDER BY row_number
        ''', (source,))
        conn.commit()
    conn.execute('ANALYZE')
    conn.commit()
    conn.close()
    print(f'Finished: {DB}')

if __name__ == '__main__':
    main()
