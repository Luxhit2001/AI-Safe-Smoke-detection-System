/* AI-SAFE Firebase Cloud Messaging client.
   The browser only receives public Firebase web configuration + VAPID data.
   The Firebase Admin service-account private key stays on the Flask server. */

const AI_SAFE_FIREBASE_SDK = "12.19.0";
let aiSafeFirebaseReady = false;
let aiSafeFirebaseFid = null;

async function aiSafeLoadFirebase() {
    if (aiSafeFirebaseReady) return true;
    try {
        const cfgResponse = await fetch("/api/firebase-config", { credentials: "same-origin" });
        if (!cfgResponse.ok) throw new Error("Firebase configuration is unavailable");
        const cfg = await cfgResponse.json();
        if (!cfg.projectId || !cfg.messagingSenderId || !cfg.appId || !cfg.vapidKey) {
            throw new Error("Firebase FCM is not configured in .env");
        }

        const [{ initializeApp }, messagingModule] = await Promise.all([
            import(`https://www.gstatic.com/firebasejs/${AI_SAFE_FIREBASE_SDK}/firebase-app.js`),
            import(`https://www.gstatic.com/firebasejs/${AI_SAFE_FIREBASE_SDK}/firebase-messaging.js`)
        ]);
        const app = initializeApp({
            apiKey: cfg.apiKey,
            authDomain: cfg.authDomain,
            projectId: cfg.projectId,
            storageBucket: cfg.storageBucket,
            messagingSenderId: cfg.messagingSenderId,
            appId: cfg.appId
        });
        const messaging = messagingModule.getMessaging(app);

        if (!("Notification" in window)) throw new Error("This browser does not support notifications");
        const permission = Notification.permission === "granted"
            ? "granted"
            : await Notification.requestPermission();
        if (permission !== "granted") throw new Error("Browser notification permission was not granted");

        // Firebase's current web FCM API registers the app instance and exposes
        // the Firebase Installation ID (FID) for server-side targeting.
        await messagingModule.register(messaging, { vapidKey: cfg.vapidKey });
        messagingModule.onRegistered(messaging, async (fid) => {
            if (!fid) return;
            aiSafeFirebaseFid = fid;
            await aiSafeSendFid(fid);
        });

        // Also register immediately in case the callback is delivered asynchronously.
        await new Promise(resolve => setTimeout(resolve, 250));
        aiSafeFirebaseReady = true;
        return true;
    } catch (error) {
        console.error("AI-SAFE Firebase FCM setup failed", error);
        if (typeof showToast === "function") showToast(`FCM: ${error.message}`);
        return false;
    }
}

async function aiSafeSendFid(fid) {
    try {
        const response = await fetch("/api/fcm/register", {
            method: "POST",
            credentials: "same-origin",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ installation_id: fid })
        });
        if (!response.ok) throw new Error(await response.text());
        if (typeof showToast === "function") showToast("Firebase push notifications enabled");
    } catch (error) {
        console.error("AI-SAFE FID registration failed", error);
    }
}

async function enableFirebaseNotifications() {
    return aiSafeLoadFirebase();
}

window.enableFirebaseNotifications = enableFirebaseNotifications;
window.aiSafeFirebaseFid = () => aiSafeFirebaseFid;

document.addEventListener("DOMContentLoaded", () => {
    const button = document.getElementById("enablePushNotifications");
    if (!button) return;
    button.addEventListener("click", async () => {
        button.disabled = true;
        const old = button.textContent;
        button.textContent = "Enabling…";
        const ok = await enableFirebaseNotifications();
        button.textContent = ok ? "Notifications enabled" : old;
        button.disabled = false;
    });
});
