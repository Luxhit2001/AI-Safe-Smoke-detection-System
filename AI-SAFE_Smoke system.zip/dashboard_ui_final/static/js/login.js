document.addEventListener("DOMContentLoaded", () => {
  const card = document.querySelector(".login-card");
  const tabs = document.querySelectorAll(".role-tab");
  const roleInput = document.getElementById("loginRole");
  const password = document.getElementById("password");
  const eye = document.querySelector(".eye");

  function setRole(role) {
    if (!roleInput) return;
    roleInput.value = role;
    tabs.forEach(tab => {
      const active = tab.dataset.role === role;
      tab.classList.toggle("active", active);
      tab.setAttribute("aria-selected", active ? "true" : "false");
    });
  }

  const serverRole = card?.dataset.errorRole;
  setRole(serverRole === "admin" ? "admin" : "user");

  tabs.forEach(tab => tab.addEventListener("click", () => setRole(tab.dataset.role)));

  if (eye && password) {
    eye.addEventListener("click", () => {
      const visible = password.type === "text";
      password.type = visible ? "password" : "text";
      eye.textContent = visible ? "◉" : "◌";
      eye.setAttribute("aria-label", visible ? "Show password" : "Hide password");
    });
  }
});
