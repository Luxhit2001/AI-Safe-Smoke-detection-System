(function () {
    "use strict";

    const state = {
        autoRefresh: true,
        dark: false,
        compact: false,
        incidents: [],
        dashboard: null,
        editingId: null,
        dataPage: 0,
        dataPageSize: 20,
        dataTotal: 0,
        dataSource: "Dataset 1",
        smokeHistory: [],
        smokeRangeHours: 1,
        smokeWarning: 500,
        smokeCritical: 700
    };

    const $ = (id) => document.getElementById(id);

    function showToast(message) {
        const toast = $("toast");
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add("show");
        clearTimeout(showToast.timer);
        showToast.timer = setTimeout(() => toast.classList.remove("show"), 2600);
    }

    const voiceState = { speaking: false, autoCritical: false };
    function setVoiceStatus(message) { const el = $("voiceStatus"); if (el) el.textContent = message; }
    function stopVoice() { if ("speechSynthesis" in window) window.speechSynthesis.cancel(); voiceState.speaking=false; setVoiceStatus("Voice assistant ready"); }
    function speakText(text, options={}) {
        if (!("speechSynthesis" in window)) { showToast("Voice response is not supported by this browser"); return false; }
        const clean=String(text||"").replace(/\s+/g," ").trim(); if(!clean) return false;
        window.speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(clean); u.rate=options.rate||0.95; u.pitch=1; u.volume=1;
        const voices=window.speechSynthesis.getVoices?window.speechSynthesis.getVoices():[]; const v=voices.find(x=>/en-IN/i.test(x.lang))||voices.find(x=>/^en/i.test(x.lang)); if(v) u.voice=v;
        u.onstart=()=>{voiceState.speaking=true;setVoiceStatus("🔊 Speaking safety guidance…")}; u.onend=()=>{voiceState.speaking=false;setVoiceStatus("Voice assistant ready")}; u.onerror=()=>{voiceState.speaking=false;setVoiceStatus("Voice response could not be played")}; window.speechSynthesis.speak(u); return true;
    }
    function speakPrecautions() {
        speakText("AI-SAFE safety precautions. Fire or critical smoke: evacuate the affected area, move upwind if possible, do not use lifts during a fire, keep away from electrical and fuel sources, and wait for trained fire and rescue personnel. Gas, chemical, or hazardous material: do not touch, smell, or identify unknown substances; keep flames and sparks away; isolate the area; move upwind or uphill where practical; and wait for trained HazMat personnel. Hazardous air quality: reduce unnecessary outdoor exposure, avoid smoke and dust, limit strenuous outdoor activity, and follow local health guidance. Sensor failure: treat an offline sensor as unknown risk, do not assume the area is safe, and verify the situation safely. In a real emergency, follow local emergency procedures and trained responder instructions.",{rate:.9});
    }
    function speakCurrentGuidance() {
        const d=state.dashboard||{}, h=d.hardware||{}; const smoke=Number(h.mq135_raw??d.smoke_level??0), aqi=Number(d.aqi??d.air_quality?.current_aqi??0), risk=d.risk_prediction?.score??d.risk_prediction?.risk_score;
        const status=smoke>=state.smokeCritical?"critical":smoke>=state.smokeWarning?"warning":smoke>=300?"elevated":"normal";
        const action=status==="critical"?"Critical safety condition. Move away from the affected area and do not enter smoke-filled or hazardous areas. Follow your emergency plan and trained responder instructions.":status==="warning"?"Smoke is in the warning range. Avoid the affected area, monitor the alert system, and be prepared to move to a safe location if conditions worsen.":status==="elevated"?"Smoke is elevated. Avoid unnecessary exposure and continue monitoring the sensor trend for a rapid increase.":"Current smoke level is in the normal range. Continue routine monitoring and keep the sensor operational.";
        speakText(`AI-SAFE current safety guidance. Smoke level is ${Math.round(smoke)} and AQI is ${Math.round(aqi)}. ${risk!=null?`Current AI risk score is ${Math.round(Number(risk))} out of 100. `:""}${action} Do not approach unknown chemicals or attempt emergency response without appropriate training.`);
    }


    let notificationIdsSeen = new Set();
    let notificationPermissionReady = false;

    async function registerNotificationServiceWorker() {
        if (!("serviceWorker" in navigator)) return;
        try {
            await navigator.serviceWorker.register("/service-worker.js", { scope: "/" });
            notificationPermissionReady = ("Notification" in window && Notification.permission === "granted");
        } catch (error) {
            console.warn("Service worker registration failed", error);
        }
    }

    async function enableBrowserNotifications() {
        if (!("Notification" in window)) {
            showToast("This browser does not support notifications");
            return false;
        }
        const permission = await Notification.requestPermission();
        notificationPermissionReady = permission === "granted";
        showToast(notificationPermissionReady ? "Browser notifications enabled" : "Notification permission was not granted");
        return notificationPermissionReady;
    }

    function showBrowserNotification(item) {
        if (!notificationPermissionReady || !("Notification" in window) || Notification.permission !== "granted") return;
        if (notificationIdsSeen.has(Number(item.id))) return;
        notificationIdsSeen.add(Number(item.id));
        const options = {
            body: item.message,
            tag: `ai-safe-${item.notification_type}`,
            renotify: true,
            data: { notificationId: item.id, incidentId: item.incident_id, sensor: item.sensor, location: item.location }
        };
        if (navigator.serviceWorker?.controller) {
            navigator.serviceWorker.ready.then(reg => reg.showNotification(`AI-SAFE ALERT · ${item.title.replace(/^.*? /, "")}`, options));
        } else {
            new Notification(`AI-SAFE ALERT · ${item.title.replace(/^.*? /, "")}`, options);
        }
    }

    function notificationIcon(type) {
        const map = { critical_smoke:"🚨", high_smoke:"🔥", arduino_disconnected:"🔌", sensor_failure:"⚠", rapid_smoke_increase:"📈", aqi_warning:"🌫", emergency_dispatch:"🚨" };
        return map[type] || "🔔";
    }

    function renderNotifications(items) {
        const list = $("notificationList");
        if (!list) return;
        const critical=items.filter(x=>/critical|emergency/i.test(`${x.severity||""} ${x.title||""} ${x.notification_type||""}`)).length;
        const unread=items.filter(x=>!Number(x.read)).length;
        if($("alertTotalCount")) $("alertTotalCount").textContent=items.length;
        if($("alertUnreadCount")) $("alertUnreadCount").textContent=unread;
        if($("alertCriticalCount")) $("alertCriticalCount").textContent=critical;
        if($("alertWarningCount")) $("alertWarningCount").textContent=Math.max(0,items.length-critical);
        if (!items.length) {
            list.innerHTML = '<div class="empty-state">No live notifications have been generated yet.</div>';
            return;
        }
        list.innerHTML = items.map(item => `
            <div class="notification-item ${Number(item.read) ? "" : "unread"}" data-notification-id="${item.id}" data-incident-id="${item.incident_id || ""}">
                <span class="notification-icon">${notificationIcon(item.notification_type)}</span>
                <div><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.message)}</p><small>${escapeHtml(item.sensor)} · ${escapeHtml(item.location)} · ${escapeHtml(item.created_at)} · <b class="source-badge ${item.data_source === "demo" ? "demo" : "live"}">${item.data_source === "demo" ? "DEMO" : "LIVE"}</b></small></div>
                <button class="notification-read" data-read-id="${item.id}">${Number(item.read) ? "Read" : "Mark read"}</button>
            </div>`).join("");
    }

    async function loadNotifications(showBrowser = true) {
        try {
            const data = await api("/api/notifications");
            renderNotifications(data.notifications || []);
            const badge = document.querySelector(".notification-badge");
            if (badge) badge.textContent = Number(data.unread || 0);
            const newest = (data.notifications || []).slice().reverse();
            newest.forEach(item => {
                if (!notificationIdsSeen.has(Number(item.id))) {
                    if (showBrowser && Number(item.read) === 0) showBrowserNotification(item);
                    else notificationIdsSeen.add(Number(item.id));
                    if (showBrowser && Number(item.read) === 0 && voiceState.autoCritical && /critical|emergency/i.test(item.notification_type + " " + item.title)) { speakText(`AI-SAFE critical alert. ${item.title}. ${item.message} Please move away from the affected area and follow trained emergency responder instructions.`, {rate:.9}); }
                }
            });
        } catch (error) {
            console.warn("Notifications could not be loaded", error);
        }
    }

    async function openNotification(itemId, incidentId) {
        try {
            await api(`/api/notifications/${itemId}/read`, { method: "POST" });
            await loadNotifications(false);
            switchView("incidents");
            if (incidentId) {
                const incident = state.incidents.find(item => Number(item.id) === Number(incidentId));
                if (incident) {
                    openIncidentModal(incident);
                } else {
                    await loadDashboard();
                    const loaded = state.incidents.find(item => Number(item.id) === Number(incidentId));
                    if (loaded) openIncidentModal(loaded);
                }
            }
        } catch (error) {
            showToast(error.message);
        }
    }

    async function loadNotificationSettings() {
        try {
            const s = await api("/api/notification-settings");
            [["notifyCritical","critical_smoke"],["notifyHigh","high_smoke"],["notifyArduino","arduino_disconnected"],["notifySensor","sensor_failure"],["notifyRapid","rapid_smoke_increase"],["notifyAqi","aqi_warning"],["quietHours","quiet_hours"]].forEach(([id,key]) => { if ($(id)) $(id).checked = !!Number(s[key]); });
            if ($("smokeWarning")) $("smokeWarning").value = s.smoke_warning;
            if ($("smokeCritical")) $("smokeCritical").value = s.smoke_critical;
            state.smokeWarning = Number(s.smoke_warning) || 500;
            state.smokeCritical = Number(s.smoke_critical) || 700;
            renderSmokeMonitor({});
            if ($("aqiWarningThreshold")) $("aqiWarningThreshold").value = s.aqi_warning_threshold;
            if ($("notificationCooldown")) $("notificationCooldown").value = s.cooldown_seconds;
            if ($("quietStart")) $("quietStart").value = s.quiet_start;
            if ($("quietEnd")) $("quietEnd").value = s.quiet_end;
        } catch (error) { console.warn(error); }
    }

    async function saveNotificationSettings() {
        const payload = {
            critical_smoke: $("notifyCritical").checked,
            high_smoke: $("notifyHigh").checked,
            arduino_disconnected: $("notifyArduino").checked,
            sensor_failure: $("notifySensor").checked,
            rapid_smoke_increase: $("notifyRapid").checked,
            aqi_warning: $("notifyAqi").checked,
            smoke_warning: $("smokeWarning").value,
            smoke_critical: $("smokeCritical").value,
            aqi_warning_threshold: $("aqiWarningThreshold").value,
            cooldown_seconds: $("notificationCooldown").value,
            quiet_hours: $("quietHours").checked,
            quiet_start: $("quietStart").value,
            quiet_end: $("quietEnd").value
        };
        try {
            await api("/api/notification-settings", { method: "PUT", body: JSON.stringify(payload) });
            showToast("Notification settings saved");
        } catch (error) { showToast(error.message); }
    }

    function escapeHtml(value) {
        return String(value ?? "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }

    function formatNumber(value) {
        const number = Number(value);
        return Number.isFinite(number) ? number.toLocaleString(undefined, { maximumFractionDigits: 1 }) : "0";
    }

    function formatTime(value) {
        if (!value) return "—";
        return value;
    }

    function updateClock() {
        const now = new Date();
        const clock = $("clock");
        if (clock) clock.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        const updated = $("lastUpdated");
        if (updated) updated.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }

    async function api(url, options = {}) {
        const response = await fetch(url, {
            credentials: "same-origin",
            headers: { "Content-Type": "application/json", ...(options.headers || {}) },
            ...options
        });

        if (response.status === 401) {
            window.location.href = "/login";
            throw new Error("Session expired. Please log in again.");
        }

        const contentType = response.headers.get("content-type") || "";
        const body = contentType.includes("application/json") ? await response.json() : await response.text();
        if (!response.ok) {
            throw new Error(body?.error || "Request failed");
        }
        return body;
    }

    function aqiClass(aqi) {
        const value = Number(aqi || 0);
        if (value <= 50) return "aqi-good";
        if (value <= 100) return "aqi-moderate";
        if (value <= 200) return "aqi-warning";
        if (value <= 300) return "aqi-poor";
        if (value <= 400) return "aqi-very-poor";
        return "aqi-severe";
    }

    
    function renderReferenceEvents(incidents) {
        const root = $("referenceRecentEvents");
        if (!root) return;
        const rows = (incidents || []).slice(0, 5);
        if (!rows.length) {
            root.innerHTML = '<div class="reference-event-row"><span>—</span><span>No recent events</span><span>Punjab Station 01</span><span>—</span><span class="ref-status normal">Normal</span><span>—</span></div>';
            return;
        }
        root.innerHTML = rows.map(item => {
            const sev = String(item.severity || "Normal").toLowerCase();
            const cls = sev.includes("critical") || sev.includes("high") ? "critical" : sev.includes("medium") || sev.includes("warning") ? "warning" : "normal";
            const source = String(item.data_source || "demo").toLowerCase() === "live" ? "LIVE (Arduino)" : "DEMO";
            return `<div class="reference-event-row">
                <span>${escapeHtml(item.incident_time || item.occurred_at || item.created_at || "—")}</span>
                <span>${escapeHtml(item.incident_type || "System event")}</span>
                <span>${escapeHtml(item.location || "Punjab Station 01")}</span>
                <span>${item.smoke_level != null ? `${Number(item.smoke_level).toFixed(0)} ppm` : "—"}</span>
                <span><b class="ref-status ${cls}">${escapeHtml(item.severity || "Normal")}</b></span>
                <span>${source}</span>
            </div>`;
        }).join("");
    }

    function updateReferenceOverview(data) {
        const h = data?.hardware || {};
        const connected = !!h.connected;
        const hasLiveSmoke = h.mq135_raw !== null && h.mq135_raw !== undefined && Number.isFinite(Number(h.mq135_raw));
        const smoke = hasLiveSmoke ? Number(h.mq135_raw) : null;
        const smokeEl = $("overviewSmoke");
        const smokeStatus = $("overviewSmokeStatus");
        const devices = $("overviewDevices");
        const sensorHealth = $("overviewSensorHealth");
        const arduino = $("overviewArduino");
        const systemText = $("overviewSystemText");
        const systemSub = $("overviewSystemSub");
        const sideStatus = $("sidebarSystemStatus");
        const sideChecked = $("sidebarLastChecked");
        const active = $("activeAlertsCount");

        if (smokeEl) smokeEl.textContent = smoke == null ? "—" : Math.round(smoke).toLocaleString();
        if (smokeStatus) {
            const warning = state.smokeWarning, critical = state.smokeCritical;
            const label = smoke == null ? "● Waiting" : smoke >= critical ? "● Critical" : smoke >= warning ? "▲ Warning" : smoke > 300 ? "● Elevated" : "● Normal";
            const cls = smoke != null && smoke >= critical ? "critical" : smoke != null && smoke >= warning ? "warning" : "normal";
            smokeStatus.textContent = label;
            smokeStatus.className = `ref-status ${cls}`;
        }
        if (devices) devices.textContent = connected ? "3 / 3" : "2 / 3";
        if (sensorHealth) sensorHealth.textContent = connected ? "Good" : "Waiting";
        if (arduino) {
            arduino.textContent = connected ? "● Connected" : "● Waiting";
            arduino.style.color = connected ? "#087c42" : "#c87500";
        }
        if (systemText) systemText.innerHTML = connected ? "All Systems<br>Operational" : "System<br>Standby";
        if (systemSub) systemSub.textContent = connected ? "Everything is working properly" : "Connect Arduino for live sensor readings";
        if (sideStatus) sideStatus.textContent = connected ? "All Systems Normal" : "Waiting for Hardware";
        if (sideChecked) sideChecked.textContent = new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});
        if (active && data?.metrics) active.textContent = Number(data.metrics.active_incidents ?? data.metrics.high_alerts ?? 0);
        const stripState=$("overviewDataState"), stripTime=$("overviewLastUpdate");
        if(stripState) stripState.textContent=connected && hasLiveSmoke ? "LIVE — Arduino readings are being received" : "WAITING — connect Arduino to begin live readings";
        if(stripTime) stripTime.textContent=h.updated_at ? new Date(h.updated_at).toLocaleTimeString() : "—";
        const deviceChip=$("deviceOverallChip");
        if(deviceChip) deviceChip.textContent=connected ? "● Monitoring active" : "● Waiting for Arduino";
        if($("deviceArduinoState")) $("deviceArduinoState").textContent=connected?"● Connected":"● Waiting";
        if($("deviceMqState")) $("deviceMqState").textContent=hasLiveSmoke?"● Reading":"● Waiting";
        if($("deviceMqValue")) $("deviceMqValue").textContent=hasLiveSmoke?formatNumber(smoke):"—";
        if($("deviceLastReading")) $("deviceLastReading").textContent=h.updated_at?new Date(h.updated_at).toLocaleTimeString():"—";
        renderReferenceEvents(data?.incidents || []);
    }

function updateMetrics(data) {
        const m = data.metrics || {};
        const air = data.air_quality || {};
        const summary = air.summary || {};

        if ($("pm25Value")) $("pm25Value").textContent = formatNumber(m.pm25);
        if ($("pm10Value")) $("pm10Value").textContent = formatNumber(m.pm10);
        if ($("coValue")) $("coValue").textContent = formatNumber(m.co);
        if ($("no2Value")) $("no2Value").textContent = formatNumber(m.no2);
        if ($("pollPm25")) $("pollPm25").textContent = `${formatNumber(m.pm25)} µg/m³`;
        if ($("pollPm10")) $("pollPm10").textContent = `${formatNumber(m.pm10)} µg/m³`;
        if ($("pollCo")) $("pollCo").textContent = `${formatNumber(m.co)} ppm`;
        if ($("pollNo2")) $("pollNo2").textContent = `${formatNumber(m.no2)} ppb`;

        if ($("aqiValue")) $("aqiValue").textContent = formatNumber(m.aqi);
        if ($("aqiMeter")) $("aqiMeter").style.width = `${Math.min(100, Math.max(3, Number(m.aqi || 0) / 3))}%`;
        if ($("monitorPm25")) $("monitorPm25").textContent = `${formatNumber(m.pm25)} µg/m³`;
        if ($("monitorPm10")) $("monitorPm10").textContent = `${formatNumber(m.pm10)} µg/m³`;
        if ($("monitorCo")) $("monitorCo").textContent = formatNumber(m.co);
        if ($("monitorNo2")) $("monitorNo2").textContent = formatNumber(m.no2);
        if ($("monitorAqi")) $("monitorAqi").textContent = formatNumber(m.aqi);

        if ($("datasetAqiValue")) {
            $("datasetAqiValue").textContent = formatNumber(m.aqi);
            $("datasetAqiValue").className = aqiClass(m.aqi);
        }
        if ($("datasetAqiRemark")) $("datasetAqiRemark").textContent = summary.latest_remarks || m.safety_label || "—";
        if ($("datasetCount")) $("datasetCount").textContent = `${Number(summary.total_rows || 0).toLocaleString()} rows`;
        if ($("datasetInfo")) $("datasetInfo").textContent = `${air.source || "Dataset"} · imported into SQLite · latest rows shown below`;

        if ($("pm25StatusMini")) $("pm25StatusMini").textContent = formatNumber(m.pm25);
        if ($("aqiStatusMini")) $("aqiStatusMini").textContent = m.safety_label || "—";
        if ($("pm25Bar")) $("pm25Bar").style.width = `${Math.min(100, Math.max(5, Number(m.pm25 || 0) / 2.5))}%`;
        if ($("aqiBar")) $("aqiBar").style.width = `${Math.min(100, Math.max(5, Number(m.aqi || 0) / 3))}%`;

        if ($("safetyScore")) $("safetyScore").textContent = m.safety_score ?? 0;
        if ($("safetyLabel")) $("safetyLabel").textContent = m.safety_label || "Unknown";
        if ($("safetyDescription")) $("safetyDescription").textContent = `Based on the latest AQI value from ${air.source || "the selected dataset"}.`;

        const active = m.active_incidents ?? 0;
        const badge = document.querySelector(".notification-badge");
        if (badge) badge.textContent = active;

        if ($("analyticsTotal")) $("analyticsTotal").textContent = m.total_incidents ?? 0;
        if ($("analyticsActive")) $("analyticsActive").textContent = m.active_incidents ?? 0;
        if ($("analyticsHigh")) $("analyticsHigh").textContent = m.high_alerts ?? 0;
        if ($("analyticsScore")) $("analyticsScore").textContent = m.safety_score ?? 0;
    }

    function renderAirQualityTable(records) {
        const table = $("airQualityTable");
        if (!table) return;
        if (!records || !records.length) {
            table.innerHTML = `<tr><td colspan="11" class="empty-state">No air-quality records found.</td></tr>`;
        } else {
            table.innerHTML = records.map(row => `
                <tr>
                    <td>#${Number(row.row_number).toLocaleString()}</td>
                    <td>${formatNumber(row.no2)}</td>
                    <td>${formatNumber(row.co)}</td>
                    <td>${formatNumber(row.pm10)}</td>
                    <td>${formatNumber(row.pm25)}</td>
                    <td>${formatNumber(row.aqi_no2)}</td>
                    <td>${formatNumber(row.aqi_co)}</td>
                    <td>${formatNumber(row.aqi_pm10)}</td>
                    <td>${formatNumber(row.aqi_pm25)}</td>
                    <td class="${aqiClass(row.aqi_overall)}">${formatNumber(row.aqi_overall)}</td>
                    <td>${escapeHtml(row.remarks || "—")}</td>
                </tr>
            `).join("");
        }
        const totalPages = Math.max(1, Math.ceil(state.dataTotal / state.dataPageSize));
        const currentPage = Math.min(totalPages, state.dataPage + 1);
        if ($("dataPageLabel")) $("dataPageLabel").textContent = `${currentPage} / ${totalPages}`;
        if ($("tablePageInfo")) $("tablePageInfo").textContent = `${Number(state.dataTotal).toLocaleString()} readings · page ${currentPage}`;
        if ($("prevDataPage")) $("prevDataPage").disabled = currentPage <= 1;
        if ($("nextDataPage")) $("nextDataPage").disabled = currentPage >= totalPages;
    }

    async function loadAirQuality(source, showMessage = false, page = state.dataPage) {
        try {
            state.dataPage = Math.max(0, page);
            state.dataSource = source || "Dataset 1";
            const offset = state.dataPage * state.dataPageSize;
            const data = await api(`/api/air-quality?source=${encodeURIComponent(state.dataSource)}&limit=${state.dataPageSize}&offset=${offset}`);
            state.dataTotal = Number(data.total_records || 0);
            renderAirQualityTable(data.records || []);
            updateChart(data.trend || []);
            if ($("airDatasetSelect")) $("airDatasetSelect").value = data.source;
            if (showMessage) showToast(`${data.source}: ${Number(data.total_records || 0).toLocaleString()} readings loaded from SQLite`);
            return data;
        } catch (error) {
            showToast(error.message);
            console.error(error);
            return null;
        }
    }


    function makePath(values, width = 760, height = 260, max = 500) {
        if (!values.length) return "M0 260 L760 260";
        const step = values.length === 1 ? width : width / (values.length - 1);
        return values.map((value, index) => {
            const x = index * step;
            const y = height - Math.min(height - 10, Math.max(0, Number(value || 0) / max * (height - 20)));
            return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
        }).join(" ");
    }

    function updateChart(trend) {
        const values = (trend || []).map(item => Number(item.aqi_overall || 0));
        const current = $("currentPath");
        const area = $("areaPath");
        const point = $("chartPoint");
        const path = makePath(values);
        if (current) current.setAttribute("d", path);
        if (area) area.setAttribute("d", `${path} L760 260 L0 260 Z`);
        if (point && values.length) {
            const lastIndex = values.length - 1;
            const x = values.length === 1 ? 0 : (lastIndex / (values.length - 1)) * 760;
            const y = 260 - Math.min(240, Math.max(0, values[lastIndex] / 500 * 240));
            point.setAttribute("cx", String(x));
            point.setAttribute("cy", String(y));
        }
    }

    // ---------------- Interactive air-quality charts ----------------
    let selectedMetric = "aqi_overall";

    function metricLabel(key) {
        return ({aqi_overall:"AQI", pm25:"PM2.5", pm10:"PM10", co:"CO", no2:"NO₂"})[key] || key;
    }

    function metricUnit(key) {
        return key === "aqi_overall" ? "AQI" : (key === "co" ? "CO" : "µg/m³");
    }

    function niceNumber(v) {
        if (!Number.isFinite(v)) return "—";
        if (Math.abs(v) >= 1000) return v.toLocaleString(undefined,{maximumFractionDigits:0});
        return v.toLocaleString(undefined,{maximumFractionDigits:2});
    }

    function renderMetricTrend(trend) {
        const svg = $("metricTrendChart");
        if (!svg) return;
        const values = (trend || []).map(r => Number(r[selectedMetric])).filter(Number.isFinite);
        svg.innerHTML = "";
        if (!values.length) return;

        const W=900,H=300,left=42,right=12,top=20,bottom=34;
        const iw=W-left-right, ih=H-top-bottom;
        const min=Math.min(...values), max=Math.max(...values);
        const range=(max-min)||1;
        const x=i=>left+(i/Math.max(1,values.length-1))*iw;
        const y=v=>top+(1-(v-min)/range)*ih;

        // AQI storytelling bands: clean → moderate → unhealthy → hazardous.
        if(selectedMetric==="aqi_overall"){
            const bands=[{a:0,b:50,c:"chart-band-good"},{a:50,b:100,c:"chart-band-moderate"},{a:100,b:200,c:"chart-band-unhealthy"},{a:200,b:max,c:"chart-band-hazardous"}];
            bands.forEach(b=>{
                const lo=Math.max(min,b.a), hi=Math.min(max,b.b);
                if(hi<=lo) return;
                const r=document.createElementNS("http://www.w3.org/2000/svg","rect");
                r.setAttribute("x",left); r.setAttribute("y",y(hi)); r.setAttribute("width",iw); r.setAttribute("height",Math.max(0,y(lo)-y(hi))); r.setAttribute("class",b.c); svg.appendChild(r);
            });
        }

        const defs=document.createElementNS("http://www.w3.org/2000/svg","defs");
        const grad=document.createElementNS("http://www.w3.org/2000/svg","linearGradient");
        grad.id="interactiveFill"; grad.setAttribute("x1","0");grad.setAttribute("y1","0");grad.setAttribute("x2","0");grad.setAttribute("y2","1");
        const st1=document.createElementNS("http://www.w3.org/2000/svg","stop"); st1.setAttribute("offset","0%");st1.setAttribute("stop-color","#8fc8e8");st1.setAttribute("stop-opacity",".35");
        const st2=document.createElementNS("http://www.w3.org/2000/svg","stop"); st2.setAttribute("offset","100%");st2.setAttribute("stop-color","#8fc8e8");st2.setAttribute("stop-opacity","0");
        grad.append(st1,st2); defs.appendChild(grad); svg.appendChild(defs);

        [0,.25,.5,.75,1].forEach(frac=>{
            const yy=top+ih*frac;
            const line=document.createElementNS("http://www.w3.org/2000/svg","line"); line.setAttribute("x1",left);line.setAttribute("x2",W-right);line.setAttribute("y1",yy);line.setAttribute("y2",yy);line.setAttribute("class","chart-grid");svg.appendChild(line);
            const text=document.createElementNS("http://www.w3.org/2000/svg","text"); text.setAttribute("x",5);text.setAttribute("y",yy+4);text.setAttribute("class","chart-axis-label");text.textContent=niceNumber(max-(max-min)*frac);svg.appendChild(text);
        });

        let d="";
        values.forEach((v,i)=>d+=(i?" L":"M")+x(i).toFixed(1)+" "+y(v).toFixed(1));
        const area=document.createElementNS("http://www.w3.org/2000/svg","path"); area.setAttribute("d",`${d} L ${x(values.length-1)} ${top+ih} L ${x(0)} ${top+ih} Z`); area.setAttribute("class","chart-area-path");svg.appendChild(area);
        const path=document.createElementNS("http://www.w3.org/2000/svg","path"); path.setAttribute("d",d);path.setAttribute("class","chart-line-path");svg.appendChild(path);

        values.forEach((v,i)=>{
            if(i!==values.length-1 && i%5!==0) return;
            const c=document.createElementNS("http://www.w3.org/2000/svg","circle"); c.setAttribute("cx",x(i));c.setAttribute("cy",y(v));c.setAttribute("r",i===values.length-1?6:3.5);c.setAttribute("class","chart-point");
            c.addEventListener("click",()=>showToast(`${metricLabel(selectedMetric)}: ${niceNumber(v)} ${metricUnit(selectedMetric)}`)); svg.appendChild(c);
        });

        // These summary labels are optional on the current dashboard layout.
        // Guard them so a missing element cannot stop the whole dashboard refresh.
        if ($("trendMin")) $("trendMin").textContent=`Min ${niceNumber(Math.min(...values))}`;
        if ($("trendAvg")) $("trendAvg").textContent=`Avg ${niceNumber(values.reduce((a,b)=>a+b,0)/values.length)}`;
        if ($("trendMax")) $("trendMax").textContent=`Max ${niceNumber(Math.max(...values))}`;
        if ($("trendChartTitle")) $("trendChartTitle").textContent=`${metricLabel(selectedMetric)} trend`;
        if ($("trendChartSubtitle")) $("trendChartSubtitle").textContent=selectedMetric==="aqi_overall"
            ? `${values.length} readings · story: normal → pollution build-up → recovery`
            : `${values.length} readings from the selected dataset`;
    }

    function renderComparison(trend) {
        const box=$("comparisonChart"); if(!box) return;
        if(!trend?.length){box.innerHTML='<div class="empty-state">No data available.</div>';return;}
        const last=trend[trend.length-1];
        const items=[['PM2.5','pm25'],['PM10','pm10'],['CO','co'],['NO₂','no2']].map(([label,key])=>({label,key,value:Number(last[key])||0}));
        const max=Math.max(...items.map(x=>x.value),1);
        box.innerHTML=items.map(x=>`<div class="compare-row"><span>${x.label}</span><div class="compare-track"><div class="compare-fill" style="width:${Math.max(3,(x.value/max)*100)}%"></div></div><strong class="compare-value">${niceNumber(x.value)}</strong></div>`).join('');
    }

    function renderAqiDistribution(trend) {
        const legend=$("aqiLegend"), donut=$("aqiDonut"), count=$("aqiSampleCount"); if(!legend||!donut||!count)return;
        const cats={Good:0,"Satisfactory/Moderate":0,"Moderate/Poor":0,Poor:0,"Very Poor":0,Severe:0};
        (trend||[]).forEach(r=>{const v=Number(r.aqi_overall); if(!Number.isFinite(v))return; if(v<=50)cats.Good++; else if(v<=100)cats["Satisfactory/Moderate"]++; else if(v<=200)cats["Moderate/Poor"]++; else if(v<=300)cats.Poor++; else if(v<=400)cats["Very Poor"]++; else cats.Severe++;});
        const total=Object.values(cats).reduce((a,b)=>a+b,0); count.textContent=total.toLocaleString();
        const colors={Good:'#51a878',"Satisfactory/Moderate":'#e3b44a',"Moderate/Poor":'#f0a15a',Poor:'#e97a62',"Very Poor":'#b05b8c',Severe:'#8d4c72'};
        let start=0; const stops=[]; Object.entries(cats).forEach(([k,v])=>{const pct=total?v/total*100:0;stops.push(`${colors[k]} ${start}% ${start+pct}%`);start+=pct;}); donut.style.background=stops.length?`conic-gradient(${stops.join(',')})`: '#e9edf1';
        legend.innerHTML=Object.entries(cats).map(([k,v])=>`<div class="legend-row"><i class="legend-swatch" style="background:${colors[k]}"></i><span>${k}</span><strong>${v}</strong></div>`).join('');
    }

    function renderInteractiveCharts(trend) {
        renderMetricTrend(trend); renderComparison(trend); renderAqiDistribution(trend);
    }

    function statusClass(value) {
        return String(value || "").toLowerCase().replaceAll(" ", "-");
    }

    function severityClass(value) {
        return String(value || "").toLowerCase();
    }

    function renderIncidents() {
        const table = $("incidentTable");
        if (!table) return;
        const total=state.incidents.length;
        const critical=state.incidents.filter(x=>String(x.severity).toLowerCase()==="critical").length;
        const warning=state.incidents.filter(x=>["high","medium"].includes(String(x.severity).toLowerCase())).length;
        const resolved=state.incidents.filter(x=>["resolved","completed"].includes(String(x.status).toLowerCase())).length;
        if($("historyTotal")) $("historyTotal").textContent=total;
        if($("historyCritical")) $("historyCritical").textContent=critical;
        if($("historyWarning")) $("historyWarning").textContent=warning;
        if($("historyResolved")) $("historyResolved").textContent=resolved;
        const search=String($("historySearch")?.value||"").toLowerCase();
        const sev=$("historySeverityFilter")?.value||"all";
        const stat=$("historyStatusFilter")?.value||"all";
        const items=state.incidents.filter(x=>{
            const text=`${x.incident_type||""} ${x.sensor||""} ${x.station_name||x.location||""}`.toLowerCase();
            return (!search||text.includes(search)) && (sev==="all"||x.severity===sev) && (stat==="all"||x.status===stat);
        });
        const guide=$("incidentEmptyGuide"); if(guide) guide.style.display=items.length?"none":"flex";
        if (!items.length) {
            table.innerHTML = `<tr><td colspan="9" class="empty-state">${total?"No incidents match the selected filters.":"No live incidents are currently recorded."}</td></tr>`;
            return;
        }
        table.innerHTML = items.map(incident => `
            <tr>
                <td>${escapeHtml(formatTime(incident.incident_time))}</td>
                <td><strong>${escapeHtml(incident.incident_type)}</strong><small class="table-subline">${escapeHtml(incident.station_name||incident.location||"AI-SAFE station")}</small></td>
                <td>${escapeHtml(incident.sensor)}</td>
                <td>${escapeHtml(formatNumber(incident.smoke_level))}</td>
                <td>${escapeHtml(formatNumber(incident.aqi))}</td>
                <td><span class="severity-pill ${severityClass(incident.severity)}">${escapeHtml(incident.severity)}</span></td>
                <td><span class="db-status ${statusClass(incident.status)}">${escapeHtml(incident.status)}</span></td>
                <td><span class="source-badge ${incident.data_source === "demo" ? "demo" : "live"}">${incident.data_source === "demo" ? "DEMO" : "LIVE"}</span></td>
                <td><button class="table-action" data-action="edit" data-id="${incident.id}">Edit</button> <button class="table-action delete" data-action="delete" data-id="${incident.id}">Delete</button></td>
            </tr>`).join("");
    }

    function renderActivity(incidents) {
        const list = $("activityList");
        if (!list) return;
        list.innerHTML = incidents.slice(0, 4).map(incident => {
            const cls = incident.severity === "High" ? "danger" : incident.severity === "Medium" ? "warning" : "safe";
            const icon = incident.severity === "High" ? "🔥" : incident.severity === "Medium" ? "!" : "✓";
            return `<div class="activity-item"><span class="activity-avatar ${cls}">${icon}</span><div><strong>${escapeHtml(incident.incident_type)}</strong><small>${escapeHtml(incident.sensor)} · ${escapeHtml(incident.severity)}</small></div><time>${escapeHtml(incident.incident_time)}</time></div>`;
        }).join("");
    }

    function renderAlerts(incidents) {
        const alerts = $("alertPageList");
        if (!alerts) return;
        alerts.innerHTML = incidents.slice(0, 8).map(incident => {
            const cls = incident.severity === "High" ? "danger" : incident.severity === "Medium" ? "warning" : "safe";
            return `<div class="activity-item"><span class="activity-avatar ${cls}">${incident.severity === "High" ? "!" : "✓"}</span><div><strong>${escapeHtml(incident.incident_type)}</strong><small>${escapeHtml(incident.sensor)} · ${escapeHtml(incident.status)}</small></div><time>${escapeHtml(incident.incident_time)}</time></div>`;
        }).join("");
    }

    function updateRightRail(incidents) {
        const container = document.querySelector(".right-rail .rail-section:first-child");
        if (!container) return;
        const items = incidents.slice(0, 4).map(incident => {
            const cls = incident.severity === "High" ? "red" : incident.severity === "Medium" ? "orange" : "green";
            const icon = incident.severity === "High" ? "!" : incident.severity === "Medium" ? "!" : "✓";
            return `<div class="rail-item"><span class="rail-avatar ${cls}">${icon}</span><div><strong>${escapeHtml(incident.incident_type)}</strong><small>${escapeHtml(incident.incident_time)}</small></div></div>`;
        }).join("");
        const title = container.querySelector(".rail-title");
        container.innerHTML = "";
        if (title) container.appendChild(title);
        container.insertAdjacentHTML("beforeend", items);
    }

    function smokeZone(value) {
        const v=Number(value||0);
        if(v>=state.smokeCritical) return {label:"CRITICAL", cls:"critical"};
        if(v>=state.smokeWarning) return {label:"WARNING", cls:"warning"};
        if(v>=300) return {label:"ELEVATED", cls:"elevated"};
        return {label:"NORMAL", cls:"normal"};
    }

    function recordSmokeReading(data) {
        const raw=Number(data?.mq135_raw);
        if(!Number.isFinite(raw)) return;
        const parsedTime = data?.updated_at ? new Date(data.updated_at).getTime() : Date.now();
        const readingTime = Number.isFinite(parsedTime) ? parsedTime : Date.now();
        const last = state.smokeHistory[state.smokeHistory.length - 1];
        // The hardware endpoint may be polled faster than Arduino emits a new line.
        // Do not duplicate the same automatic reading in the graph.
        if (!last || last.time !== readingTime || last.value !== raw) {
            state.smokeHistory.push({time:readingTime, value:raw, connected:!!data.connected});
        }
        const cutoff=Date.now()-30*24*60*60*1000;
        state.smokeHistory=state.smokeHistory.filter(x=>x.time>=cutoff).slice(-10000);
        renderSmokeMonitor(data);
    }

    async function loadLiveSmokeHistory() {
        try {
            const data = await api("/api/smoke-history?limit=10000");
            state.smokeHistory = (data.readings || []).map(r => ({
                time: new Date(r.recorded_at).getTime(),
                value: Number(r.value),
                connected: true
            })).filter(r => Number.isFinite(r.time) && Number.isFinite(r.value));
            renderSmokeMonitor(state.dashboard?.hardware || {});
        } catch (error) {
            console.warn("Live smoke history could not be loaded", error);
        }
    }

    function renderSmokeMonitor(hardware={}) {
        const svg=$("smokeLevelChart"); if(!svg) return;
        const now=Date.now(), cutoff=now-state.smokeRangeHours*60*60*1000;
        let points=state.smokeHistory.filter(p=>p.time>=cutoff);
        const demoMode=false;
        const values=points.map(p=>p.value);
        const current=values.length?values[values.length-1]:Number(hardware.mq135_raw);
        const zone=smokeZone(current);
        if($("smokeCurrent")) $("smokeCurrent").textContent=Number.isFinite(current)?formatNumber(current):"—";
        if($("smokeStatus")){ $("smokeStatus").textContent=zone.label; $("smokeStatus").className=`smoke-status ${zone.cls}`; }
        if($("smokeUpdated")) $("smokeUpdated").textContent=hardware.updated_at?new Date(hardware.updated_at).toLocaleTimeString():"—";
        if($("smokeConnection")) $("smokeConnection").textContent=hardware.connected?"● ONLINE":"● OFFLINE";
        if($("smokeMin")) $("smokeMin").textContent=values.length?formatNumber(Math.min(...values)):"—";
        if($("smokeAvg")) $("smokeAvg").textContent=values.length?formatNumber(values.reduce((a,b)=>a+b,0)/values.length):"—";
        if($("smokeMax")) $("smokeMax").textContent=values.length?formatNumber(Math.max(...values)):"—";
        let rate=0;
        const five=now-5*60*1000, old=state.smokeHistory.filter(p=>p.time<=five).slice(-1)[0];
        if(old && Number.isFinite(current) && old.value!==0) rate=((current-old.value)/Math.abs(old.value))*100;
        const trend=rate>3?"↗ Rising":rate<-3?"↘ Falling":"→ Stable";
        if($("smokeTrend")) $("smokeTrend").textContent=trend;
        if($("smokeRate")) $("smokeRate").textContent=`${rate>=0?"+":""}${rate.toFixed(1)}% / 5 min`;
        const trendBox=$("smokeTrendAlert");
        if(trendBox) trendBox.innerHTML=`<b>${rate>=15?"🚨 Rapid Smoke Increase":"📈 Trend analysis"}</b><span>${rate>=15?`Smoke increased ${rate.toFixed(1)}% in the last 5 minutes. Existing rapid-rise notification rules apply.`:`Current trend is ${trend.toLowerCase()} at ${rate>=0?"+":""}${rate.toFixed(1)}% over the last 5 minutes.`}</span>`;
        const warning=Number(state.smokeWarning)||500, critical=Number(state.smokeCritical)||700;
        if($("smokeWarningThresholdLabel")) $("smokeWarningThresholdLabel").textContent=warning;
        if($("smokeCriticalThresholdLabel")) $("smokeCriticalThresholdLabel").textContent=critical;
        if($("warningZoneText")) $("warningZoneText").textContent=`${warning}–${critical-1} · WARNING`;
        if($("criticalZoneText")) $("criticalZoneText").textContent=`${critical}+ · CRITICAL`;
        if(!svg) return;
        const W=1000,H=390,L=55,R=20,T=18,B=38,iw=W-L-R,ih=H-T-B;
        svg.innerHTML="";
        const max=Math.max(1000,critical+200, ...values, 100), min=0;
        const x=i=>L+(i/Math.max(1,points.length-1))*iw, y=v=>T+(1-(Math.min(max,Math.max(min,v))-min)/(max-min))*ih;
        const ns="http://www.w3.org/2000/svg";
        function line(yv,cls,label){const l=document.createElementNS(ns,"line");l.setAttribute("x1",L);l.setAttribute("x2",W-R);l.setAttribute("y1",y(yv));l.setAttribute("y2",y(yv));l.setAttribute("class",cls);svg.appendChild(l);const t=document.createElementNS(ns,"text");t.setAttribute("x",8);t.setAttribute("y",y(yv)+4);t.setAttribute("class","smoke-axis-label");t.textContent=`${label} ${Math.round(yv)}`;svg.appendChild(t);}
        function band(a,b,cls){const r=document.createElementNS(ns,"rect");r.setAttribute("x",L);r.setAttribute("y",y(b));r.setAttribute("width",iw);r.setAttribute("height",Math.max(0,y(a)-y(b)));r.setAttribute("class",cls);svg.appendChild(r);}
        band(0,300,"smoke-band-normal"); band(300,warning,"smoke-band-elevated"); band(warning,critical,"smoke-band-warning"); band(critical,max,"smoke-band-critical");
        [300,warning,critical].forEach((v,i)=>line(v,`smoke-threshold t${i}`,i===0?"Elevated":i===1?"Warning":"Critical"));
        [0,.25,.5,.75,1].forEach(f=>{const l=document.createElementNS(ns,"line");l.setAttribute("x1",L);l.setAttribute("x2",W-R);l.setAttribute("y1",T+ih*f);l.setAttribute("y2",T+ih*f);l.setAttribute("class","smoke-grid");svg.appendChild(l);});
        if(points.length){let d="";points.forEach((p,i)=>d+=(i?" L":"M")+x(i).toFixed(1)+" "+y(p.value).toFixed(1));const area=document.createElementNS(ns,"path");area.setAttribute("d",`${d} L ${x(points.length-1)} ${T+ih} L ${x(0)} ${T+ih} Z`);area.setAttribute("class","smoke-area");svg.appendChild(area);const path=document.createElementNS(ns,"path");path.setAttribute("d",d);path.setAttribute("class","smoke-line");svg.appendChild(path);const p=points[points.length-1];const c=document.createElementNS(ns,"circle");c.setAttribute("cx",x(points.length-1));c.setAttribute("cy",y(p.value));c.setAttribute("r",7);c.setAttribute("class",`smoke-point ${zone.cls}`);svg.appendChild(c);}
        // Story markers make the chart readable as an incident narrative.
        if(points.length>1){
            const markers=[
                {value:300,text:"Rising",cls:"story-marker story-rising"},
                {value:warning,text:"Warning",cls:"story-marker story-warning"},
                {value:critical,text:"Critical",cls:"story-marker story-critical"}
            ];
            markers.forEach(marker=>{
                const idx=points.findIndex(p=>Number(p.value)>=marker.value);
                if(idx<0) return;
                const g=document.createElementNS(ns,"g");
                const c=document.createElementNS(ns,"circle"); c.setAttribute("cx",x(idx)); c.setAttribute("cy",y(points[idx].value)); c.setAttribute("r",5); c.setAttribute("class",marker.cls); g.appendChild(c);
                const t=document.createElementNS(ns,"text"); t.setAttribute("x",Math.min(W-R-6,Math.max(L+6,x(idx)+8))); t.setAttribute("y",Math.max(T+16,y(points[idx].value)-10)); t.setAttribute("class","smoke-story-label"); t.textContent=marker.text; g.appendChild(t); svg.appendChild(g);
            });
            const recoveryIdx=points.findIndex((p,i)=>i>0 && Number(p.value)<warning && Number(points[i-1].value)>=warning);
            if(recoveryIdx>=0){
                const t=document.createElementNS(ns,"text"); t.setAttribute("x",Math.min(W-R-80,x(recoveryIdx)+8)); t.setAttribute("y",Math.max(T+18,y(points[recoveryIdx].value)-10)); t.setAttribute("class","smoke-story-label"); t.textContent="Recovery"; svg.appendChild(t);
            }
        }
        const label=document.createElementNS(ns,"text");label.setAttribute("x",W-R);label.setAttribute("y",H-8);label.setAttribute("text-anchor","end");label.setAttribute("class","smoke-axis-label");label.textContent=points.length?`${points.length} automatic live sample${points.length===1?"":"s"}`:"Waiting for automatic Arduino readings";svg.appendChild(label);
        const storyNote=$("smokeEmergencyAlert");
        if(storyNote) storyNote.innerHTML=points.length
            ? '<b>🔔 Live alert integration</b><span>Notifications are generated automatically from the MQ-135 reading and Arduino SAFE/WARNING/CRITICAL state.</span>'
            : '<b>🔌 Waiting for Arduino</b><span>Connect the Arduino by USB. New smoke readings and notifications will appear automatically.</span>';
    }

    function updateHardware(data) {
        const h = data || {};
        const connected = !!h.connected;
        const status = $("hardwareStatus");
        const dot = $("hardwareDot");
        const mode = $("hardwareMode");
        const raw = $("mq135Raw");
        const gas = $("gasIndex");
        const temp = $("sensorTemperature");
        const humidity = $("sensorHumidity");
        const level = $("sensorLevel");
        const time = $("sensorUpdated");
        if (status) status.textContent = connected ? "Arduino Online" : "Waiting for Arduino";
        if (dot) dot.className = `hardware-dot ${connected ? "online" : "offline"}`;
        if (mode) mode.textContent = h.mode || "Offline";
        const dataBadge = $("dataModeBadge");
        if (dataBadge) { dataBadge.textContent = connected ? "LIVE DATA" : "WAITING FOR HARDWARE"; dataBadge.className = `data-mode-badge ${connected ? "live" : "demo"}`; }
        const liveBadge = $("liveBadge");
        if (liveBadge) { liveBadge.innerHTML = connected ? '<i></i>Live' : '<i></i>Waiting'; liveBadge.className = `live-badge ${connected ? "" : "waiting"}`; }
        if (raw) raw.textContent = h.mq135_raw == null ? "—" : formatNumber(h.mq135_raw);
        if (gas) gas.textContent = h.gas_index == null ? "—" : formatNumber(h.gas_index);
        if (temp) temp.textContent = h.temperature == null ? "—" : `${formatNumber(h.temperature)} °C`;
        if (humidity) humidity.textContent = h.humidity == null ? "—" : `${formatNumber(h.humidity)} %`;
        if (level) level.textContent = h.level || "Waiting";
        if (time) time.textContent = h.updated_at ? new Date(h.updated_at).toLocaleTimeString() : "Not read";
        recordSmokeReading(h);
        if ($("sideTemperature")) $("sideTemperature").textContent = h.temperature == null ? "—" : `${formatNumber(h.temperature)}°C`;
        if ($("sideHumidity")) $("sideHumidity").textContent = h.humidity == null ? "—" : `${formatNumber(h.humidity)}%`;
    }

    async function refreshHardware(showMessage = false) {
        try {
            const data = await api("/api/hardware/read");
            updateHardware(data);
            if (showMessage) showToast(data.connected ? "Arduino + MQ-135 reading refreshed" : "Dashboard refreshed; Arduino is offline");
            return data;
        } catch (error) {
            console.error(error);
            updateHardware({ connected: false, mode: "Offline", message: error.message });
            return null;
        }
    }

    async function loadDashboard(showMessage = false) {
        try {
            const selected = $("airDatasetSelect")?.value || "Dataset 1";
            const [data, hardware] = await Promise.all([
                api(`/api/dashboard?source=${encodeURIComponent(selected)}`),
                refreshHardware(false)
            ]);
            state.dashboard = data;
            updateHardware(hardware || data.hardware || {});
            state.incidents = data.incidents || [];
            if($("reportReadingCount")) $("reportReadingCount").textContent=Number(data.air_quality?.total_records||data.air_quality?.summary?.total_rows||0).toLocaleString();
            if($("reportIncidentCount")) $("reportIncidentCount").textContent=state.incidents.length;
            if($("reportStationCount")) $("reportStationCount").textContent=Number(data.station_count||5);
            updateMetrics(data);
            updateReferenceOverview(data);
            renderIncidents();
            renderActivity(state.incidents);
            renderAlerts(state.incidents);
            updateRightRail(state.incidents);
            state.dataTotal = Number(data.air_quality?.total_records || data.air_quality?.summary?.total_rows || 0);
            state.dataPage = 0;
            state.dataSource = data.air_quality?.source || selected;
            renderAirQualityTable(data.air_quality?.records || []);
            updateChart(data.air_quality?.trend || []);
            renderInteractiveCharts(data.air_quality?.trend || []);
            updateClock();
            if (showMessage) showToast(`${data.air_quality?.source || "Dataset"} loaded from SQLite`);
        } catch (error) {
            showToast(error.message);
            console.error(error);
        }
    }

    function openIncidentModal(incident = null) {
        state.editingId = incident ? incident.id : null;
        $("incidentModalTitle").textContent = incident ? "Edit Incident" : "Add Incident";
        $("incidentId").value = incident?.id || "";
        $("incidentTime").value = incident?.incident_time || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        $("incidentType").value = incident?.incident_type || "";
        $("incidentSensor").value = incident?.sensor || "Gas Sensor";
        $("incidentSeverity").value = incident?.severity || "Medium";
        $("incidentStatus").value = incident?.status || "Active";
        $("incidentSmoke").value = incident?.smoke_level ?? 0;
        $("incidentAqi").value = incident?.aqi ?? 0;
        $("incidentTemp").value = incident?.temperature ?? 0;
        $("incidentHumidity").value = incident?.humidity ?? 0;
        $("incidentLat").value = incident?.latitude ?? "";
        $("incidentLng").value = incident?.longitude ?? "";
        $("incidentDescription").value = incident?.description || "";
        $("incidentModal").classList.add("open");
        $("incidentModal").setAttribute("aria-hidden", "false");
        setTimeout(() => $("incidentType").focus(), 50);
    }

    function closeIncidentModal() {
        $("incidentModal").classList.remove("open");
        $("incidentModal").setAttribute("aria-hidden", "true");
        state.editingId = null;
    }

    function formPayload() {
        return {
            incident_time: $("incidentTime").value.trim(),
            incident_type: $("incidentType").value.trim(),
            sensor: $("incidentSensor").value.trim(),
            severity: $("incidentSeverity").value,
            status: $("incidentStatus").value,
            smoke_level: $("incidentSmoke").value,
            aqi: $("incidentAqi").value,
            temperature: $("incidentTemp").value,
            humidity: $("incidentHumidity").value,
            latitude: $("incidentLat").value,
            longitude: $("incidentLng").value,
            description: $("incidentDescription").value.trim()
        };
    }

    async function saveIncident(event) {
        event.preventDefault();
        const payload = formPayload();
        if (!payload.incident_type || !payload.sensor) {
            showToast("Incident type and sensor are required");
            return;
        }

        try {
            const url = state.editingId ? `/api/incidents/${state.editingId}` : "/api/incidents";
            const method = state.editingId ? "PUT" : "POST";
            await api(url, { method, body: JSON.stringify(payload) });
            closeIncidentModal();
            await loadDashboard();
            showToast(state.editingId ? "Incident updated" : "Incident saved to SQLite");
        } catch (error) {
            showToast(error.message);
        }
    }

    async function deleteIncident(id) {
        const incident = state.incidents.find(item => Number(item.id) === Number(id));
        if (!incident) return;
        if (!window.confirm(`Delete “${incident.incident_type}” from the database?`)) return;
        try {
            await api(`/api/incidents/${id}`, { method: "DELETE" });
            await loadDashboard();
            showToast("Incident deleted from SQLite");
        } catch (error) {
            showToast(error.message);
        }
    }

    function setCriticalVoiceAlerts(enabled, notify=true) {
        voiceState.autoCritical = !!enabled;
        const toggle = $("autoVoiceAlerts");
        if (toggle) toggle.checked = voiceState.autoCritical;
        const stateLabel = $("voiceToggleState");
        if (stateLabel) stateLabel.textContent = voiceState.autoCritical ? "ON" : "OFF";
        const status = $("voiceStatus");
        if (status) status.textContent = voiceState.autoCritical ? "Critical voice alerts are ON — manual control" : "Critical voice alerts are OFF";
        if (notify) showToast(voiceState.autoCritical ? "Critical voice alerts turned ON" : "Critical voice alerts turned OFF");
    }

    async function loadPrecautions() {
        try { await api("/api/precautions"); } catch (e) { console.warn(e); }
    }

    function renderDispatches(rows) {
        const table = $("dispatchTable"); if (!table) return;
        if (!rows?.length) { table.innerHTML = '<tr><td colspan="6" class="empty-state">No emergency dispatches yet.</td></tr>'; return; }
        table.innerHTML = rows.map(r => `<tr><td>${escapeHtml(r.created_at)}</td><td>${escapeHtml(r.event_type)}</td><td><b>${escapeHtml(r.severity)}</b></td><td>${escapeHtml(r.recipient)}</td><td>${escapeHtml(r.location)}</td><td><span class="dispatch-pill">${escapeHtml(r.status)}</span></td></tr>`).join("");
    }

    async function loadEmergencySettings() {
        try {
            const s = await api("/api/emergency-settings");
            [["autoDispatch","auto_dispatch"],["dispatchFire","fire_department"],["dispatchAmbulance","ambulance"],["dispatchHazmat","hazmat"],["dispatchPolice","police_control"]].forEach(([id,key]) => { if ($(id)) $(id).checked = !!Number(s[key]); });
            [["fireContact","fire_contact"],["ambulanceContact","ambulance_contact"],["hazmatContact","hazmat_contact"],["policeContact","police_contact"]].forEach(([id,key]) => { if ($(id)) $(id).value = s[key] || ""; });
            const status = $("dispatchStatus"); if (status) status.textContent = Number(s.auto_dispatch) ? "Automatic enabled" : "Automatic off";
        } catch(e) { console.warn(e); }
    }

    async function saveEmergencySettings() {
        const payload = {
            auto_dispatch: $("autoDispatch").checked,
            fire_department: $("dispatchFire").checked,
            ambulance: $("dispatchAmbulance").checked,
            hazmat: $("dispatchHazmat").checked,
            police_control: $("dispatchPolice").checked,
            fire_contact: $("fireContact").value,
            ambulance_contact: $("ambulanceContact").value,
            hazmat_contact: $("hazmatContact").value,
            police_contact: $("policeContact").value
        };
        try { const s = await api("/api/emergency-settings", {method:"PUT", body:JSON.stringify(payload)}); $("dispatchStatus").textContent = Number(s.auto_dispatch) ? "Automatic enabled" : "Automatic off"; showToast("Emergency response settings saved"); }
        catch(e) { showToast(e.message); }
    }

    async function loadDispatches() {
        try { const rows = await api("/api/emergency-dispatches"); renderDispatches(rows); } catch(e) { console.warn(e); }
    }

    async function testEmergencyAlert() {
        try {
            const result = await api("/api/emergency-test", {method:"POST", body:JSON.stringify({event_type:"critical smoke", severity:"Critical", smoke:800, aqi:320, location:"Punjab Station 01"})});
            renderDispatches(result.dispatches || []);
            showToast("Demo emergency messages queued — no real agency contacted");
            await loadDispatches();
        } catch(e) { showToast(e.message); }
    }


    let networkMap=null;
    let networkMarkers=[];
    let networkStations=[];
    let networkStatusFilter="all";
    let networkSearch="";
    let networkLayer="light";
    let lightTileLayer=null;
    let satelliteTileLayer=null;

    const MAP_SAMPLE_STATIONS = [
        {id:101,station_name:"Punjab Station 01",location:"Ludhiana, Punjab",latitude:30.9010,longitude:75.8573,current_aqi:82,current_smoke:18,current_pm25:34,current_pm10:61,status:"Normal",updated_at:"10:42 PM"},
        {id:102,station_name:"Delhi Station 02",location:"New Delhi",latitude:28.6139,longitude:77.2090,current_aqi:156,current_smoke:42,current_pm25:78,current_pm10:126,status:"Warning",updated_at:"10:39 PM"},
        {id:103,station_name:"Haryana Station 03",location:"Panipat, Haryana",latitude:29.3909,longitude:76.9635,current_aqi:238,current_smoke:67,current_pm25:121,current_pm10:194,status:"High",updated_at:"10:38 PM"},
        {id:104,station_name:"UP Station 04",location:"Noida, Uttar Pradesh",latitude:28.5355,longitude:77.3910,current_aqi:421,current_smoke:91,current_pm25:218,current_pm10:367,status:"Critical",updated_at:"10:42 PM"},
        {id:105,station_name:"Rajasthan Station 05",location:"Jaipur, Rajasthan",latitude:26.9124,longitude:75.7873,current_aqi:104,current_smoke:29,current_pm25:51,current_pm10:88,status:"Moderate",updated_at:"10:17 PM"},
        {id:106,station_name:"Uttarakhand Station 06",location:"Dehradun, Uttarakhand",latitude:30.3165,longitude:78.0322,current_aqi:65,current_smoke:14,current_pm25:27,current_pm10:49,status:"Normal",updated_at:"10:35 PM"},
        {id:107,station_name:"Maharashtra Station 07",location:"Pune, Maharashtra",latitude:18.5204,longitude:73.8567,current_aqi:187,current_smoke:48,current_pm25:93,current_pm10:141,status:"Warning",updated_at:"10:24 PM"},
        {id:108,station_name:"Gujarat Station 08",location:"Ahmedabad, Gujarat",latitude:23.0225,longitude:72.5714,current_aqi:276,current_smoke:73,current_pm25:138,current_pm10:219,status:"High",updated_at:"10:31 PM"}
    ];

    async function loadNetworkStations(){
        // Reference/demo map content. Live Arduino/API data can still be used elsewhere in AI-SAFE.
        networkStations=MAP_SAMPLE_STATIONS.map(s=>({...s}));
        renderNetworkStations(networkStations);
        const role=(window.AI_SAFE_ROLE||"").toLowerCase();
        if(role==="admin") loadUsers();
    }

    function stationStatusKey(status){
        const s=String(status||"Normal").toLowerCase();
        if(s.includes("critical") || s.includes("danger")) return "critical";
        if(s.includes("warning") || s.includes("moderate") || s.includes("high")) return s.includes("high") ? "high" : "warning";
        if(s.includes("offline") || s.includes("disconnected")) return "offline";
        return "normal";
    }
    function stationStatusIcon(status){
        const key=stationStatusKey(status);
        return key==="critical"?"🔴":key==="high"?"🟠":key==="warning"?"🟡":key==="offline"?"🔵":"🟢";
    }
    function mapMarkerIcon(status){
        const key=stationStatusKey(status);
        const glyph=key==="critical"?"!":key==="high"?"!":key==="warning"?"!":key==="offline"?"×":"✓";
        return L.divIcon({className:"",html:`<div class="ai-safe-map-marker ${key}"><span>${glyph}</span></div>`,iconSize:[34,34],iconAnchor:[17,34],popupAnchor:[0,-30]});
    }
    function mapStatusLabel(status){ return stationStatusKey(status).toUpperCase(); }

    function initProfessionalMap(){
        const mapEl=$("networkMap");
        if(!mapEl || typeof L==="undefined") return;
        if(!networkMap){
            networkMap=L.map(mapEl,{zoomControl:false,preferCanvas:true}).setView([23.7,78.8],5);
            lightTileLayer=L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:20,attribution:"© OpenStreetMap contributors"}).addTo(networkMap);
            satelliteTileLayer=L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{maxZoom:19,attribution:"Tiles © Esri"});
        }
        setTimeout(()=>networkMap.invalidateSize(),120);
    }

    function filteredNetworkStations(){
        const q=networkSearch.trim().toLowerCase();
        return networkStations.filter(st=>{
            const status=stationStatusKey(st.status);
            const matchesStatus=networkStatusFilter==="all" || status===networkStatusFilter;
            const hay=[st.station_name,st.location,st.status,st.station_code].filter(Boolean).join(" ").toLowerCase();
            return matchesStatus && (!q || hay.includes(q));
        });
    }

    function renderMapRecentAlerts(stations){
        const el=$("mapRecentAlerts");
        if(!el) return;
        const rows=stations.map(st=>({st,key:stationStatusKey(st.status),time:st.updated_at||"—"}))
            .filter(x=>x.key!=="normal" || stations.length<=5)
            .sort((a,b)=>({critical:0,warning:1,offline:2,normal:3}[a.key]-({critical:0,warning:1,offline:2,normal:3}[b.key])) || String(b.time).localeCompare(String(a.time)))
            .slice(0,6);
        el.innerHTML=rows.length?rows.map(x=>`<div class="map-alert-item" data-station-id="${Number(x.st.id)}"><div class="map-alert-icon">${stationStatusIcon(x.st.status)}</div><div class="map-alert-main"><b>${escapeHtml(x.st.station_name||"AI SAFE Device")}</b><small>${escapeHtml(x.st.location||x.st.station_name||"Assigned station")}</small></div><div class="map-alert-meta"><time>${escapeHtml(x.time)}</time><span class="map-severity ${x.key}">${mapStatusLabel(x.st.status)}</span></div></div>`).join(""):'<div class="empty-state" style="padding:30px;text-align:center">No recent alerts.</div>';
        el.querySelectorAll(".map-alert-item").forEach(item=>item.addEventListener("click",()=>{
            const st=networkStations.find(x=>Number(x.id)===Number(item.dataset.stationId));
            if(st && networkMap){ networkMap.setView([Number(st.latitude),Number(st.longitude)],14,{animate:true}); const marker=networkMarkers.find(m=>m._aiSafeStationId===Number(st.id)); if(marker) marker.openPopup(); }
        }));
    }

    function updateMapSummary(stations){
        const counts={critical:0,warning:0,normal:0,offline:0};
        networkStations.forEach(st=>counts[stationStatusKey(st.status)]++);
        const high=networkStations.filter(st=>stationStatusKey(st.status)==="high").length;
        const warning=networkStations.filter(st=>stationStatusKey(st.status)==="warning").length;
        $("mapCriticalCount") && ($("mapCriticalCount").textContent=counts.critical);
        $("mapWarningCount") && ($("mapWarningCount").textContent=warning);
        $("mapHighCount") && ($("mapHighCount").textContent=high);
        $("mapNormalCount") && ($("mapNormalCount").textContent=counts.normal);
        $("mapDeviceCount") && ($("mapDeviceCount").textContent=networkStations.length);
        const visible=stations.length?stations:networkStations;
        if(visible.length){
            const lat=Number(visible[0].latitude),lng=Number(visible[0].longitude);
            $("mapLatitude") && ($("mapLatitude").textContent=isFinite(lat)?lat.toFixed(4)+"° N":"—");
            $("mapLongitude") && ($("mapLongitude").textContent=isFinite(lng)?lng.toFixed(4)+"° E":"—");
        }
        $("mapAccuracy") && ($("mapAccuracy").textContent="Live sensor data");
        $("mapUpdated") && ($("mapUpdated").textContent=new Date().toLocaleTimeString());
    }

    function renderExactStationList(stations){
        const box=$("mapStationList");
        if(!box) return;
        const list=stations||[];
        box.innerHTML=list.map(st=>{
            const key=stationStatusKey(st.status);
            const label=String(st.status||"Normal");
            const statusText=label==="Moderate"?"Moderate":label;
            return `<div class="station-row" data-station-id="${Number(st.id)}">
                <span class="station-name"><i class="station-dot ${key}"></i>${escapeHtml(st.station_name)}</span>
                <span class="station-loc">${escapeHtml(st.location)}</span>
                <span class="station-aqi ${key}">${formatNumber(st.current_aqi)}</span>
                <span class="station-smoke">${formatNumber(st.current_smoke)}%</span>
                <span class="station-status-pill ${key}">${escapeHtml(statusText)}</span>
            </div>`;
        }).join("");
        box.querySelectorAll(".station-row").forEach(row=>row.addEventListener("click",()=>{
            const st=list.find(x=>Number(x.id)===Number(row.dataset.stationId));
            if(st&&networkMap){ networkMap.setView([Number(st.latitude),Number(st.longitude)],7,{animate:true}); const marker=networkMarkers.find(m=>m._aiSafeStationId===Number(st.id)); marker?.openPopup(); }
        }));
    }

    function renderNetworkStations(stations){
        initProfessionalMap();
        if(!networkMap) return;
        networkStations=stations||networkStations||[];
        const filterSelect=$("mapDeviceFilter");
        if(filterSelect){ const current=filterSelect.value; filterSelect.innerHTML='<option value="all">All Devices</option>'+networkStations.map(st=>`<option value="${Number(st.id)}">${escapeHtml(st.station_name||("Device "+st.id))}</option>`).join(""); if([...filterSelect.options].some(o=>o.value===current)) filterSelect.value=current; }
        networkMarkers.forEach(m=>networkMap.removeLayer(m)); networkMarkers=[];
        const visible=filteredNetworkStations();
        visible.forEach(st=>{
            const lat=Number(st.latitude),lng=Number(st.longitude);
            if(!isFinite(lat)||!isFinite(lng)) return;
            const key=stationStatusKey(st.status);
            const popup=`<div class="map-popup-card"><h3>${escapeHtml(st.station_name||"AI SAFE Device")}</h3><p>${escapeHtml(st.location||"Sensor station")}</p><div class="map-popup-status ${key}">${stationStatusIcon(st.status)} ${escapeHtml(st.status||"Normal")}</div><div class="map-popup-metrics"><div><small>AQI</small><b>${formatNumber(st.current_aqi)}</b></div><div><small>Smoke</small><b>${formatNumber(st.current_smoke)}</b></div><div><small>PM2.5</small><b>${formatNumber(st.current_pm25)}</b></div><div><small>PM10</small><b>${formatNumber(st.current_pm10)}</b></div></div><p style="margin-top:9px">Updated ${escapeHtml(st.updated_at||"—")}</p></div>`;
            const marker=L.marker([lat,lng],{icon:mapMarkerIcon(st.status)}).addTo(networkMap).bindPopup(popup);
            marker._aiSafeStationId=Number(st.id); marker._aiSafeStatus=key; networkMarkers.push(marker);
        });
        updateMapSummary(visible); renderExactStationList(networkStations); renderMapRecentAlerts(networkStations); renderStationExplorer(networkStations);
        if(visible.length===1){
            networkMap.setView([Number(visible[0].latitude),Number(visible[0].longitude)],14);
            if($("networkMapSubtitle")) $("networkMapSubtitle").textContent=`Showing ${visible[0].station_name}.`;
        }else if(visible.length){
            const bounds=L.latLngBounds(visible.map(s=>[Number(s.latitude),Number(s.longitude)]));
            networkMap.fitBounds(bounds.pad(.18),{maxZoom:13});
            if($("networkMapSubtitle")) $("networkMapSubtitle").textContent=`Showing ${visible.length} device${visible.length===1?"":"s"} on the live map.`;
        }else if($("networkMapSubtitle")) $("networkMapSubtitle").textContent="No devices match the current filter.";
        setTimeout(()=>networkMap.invalidateSize(),150);
    }

    function renderStationExplorer(stations){
        const box=$("mapStationCards");
        if(!box) return;
        const list=(stations||[]).filter(st=>isFinite(Number(st.latitude))&&isFinite(Number(st.longitude)));
        if($("mapExplorerCount")) $("mapExplorerCount").textContent=`${list.length} configured station${list.length===1?"":"s"}`;
        if(!list.length){
            box.innerHTML='<article class="station-explorer-placeholder"><b>No station records are available.</b><span>Check the SQLite stations table and refresh the dashboard.</span></article>';
            return;
        }
        box.innerHTML=list.map(st=>{
            const key=stationStatusKey(st.status);
            const statusLabel=String(st.status||"Normal");
            return `<article class="station-explorer-card" data-station-id="${Number(st.id)}">
                <h3>${escapeHtml(st.station_name||"AI-SAFE Station")}</h3>
                <p>⌖ ${escapeHtml(st.location||"Punjab, India")}</p>
                <span class="station-explorer-status ${key}">${stationStatusIcon(st.status)} ${escapeHtml(statusLabel)}</span>
                <div class="station-explorer-metrics">
                  <div><small>Smoke</small><b>${formatNumber(st.current_smoke)}</b></div>
                  <div><small>AQI</small><b>${formatNumber(st.current_aqi)}</b></div>
                  <div><small>PM2.5</small><b>${formatNumber(st.current_pm25)}</b></div>
                  <div><small>Updated</small><b>${escapeHtml(String(st.updated_at||"—").slice(11,19)||"—")}</b></div>
                </div>
            </article>`;
        }).join("");
        box.querySelectorAll(".station-explorer-card").forEach(card=>card.addEventListener("click",()=>{
            const id=Number(card.dataset.stationId);
            const st=list.find(x=>Number(x.id)===id);
            if(st && networkMap){
                networkMap.setView([Number(st.latitude),Number(st.longitude)],15,{animate:true});
                const marker=networkMarkers.find(m=>m._aiSafeStationId===id);
                marker?.openPopup();
            }
        }));
    }

    async function loadStationExplorer(){
        networkStations=MAP_SAMPLE_STATIONS.map(s=>({...s}));
        renderExactStationList(networkStations);
        renderNetworkStations(networkStations);
    }

        async function loadUsers(){
        const table=$("userTable"), stationSelect=$("newUserStation");
        if(!table) return;
        try{
            const [u,s]=await Promise.all([api("/api/users"),api("/api/stations")]);
            if(stationSelect) stationSelect.innerHTML=(s.stations||[]).map(x=>`<option value="${x.id}">${escapeHtml(x.station_name)}</option>`).join("");
            table.innerHTML=(u.users||[]).map(x=>`<tr><td>${escapeHtml(x.name)}</td><td>${escapeHtml(x.username)}</td><td>${escapeHtml(String(x.role).toUpperCase())}</td><td>${escapeHtml(x.station_name||"All Stations")}</td><td>${escapeHtml(x.created_at||"")}</td><td>${Number(x.id)===Number(window.AI_SAFE_USER_ID)?"Current":"<button class='small-button delete-user' data-id='"+x.id+"'>Delete</button>"}</td></tr>`).join("") || '<tr><td colspan="6" class="empty-state">No users found.</td></tr>';
        }catch(e){showToast(e.message);}
    }

    async function createUser(){
        try{
            const payload={name:$("newUserName").value.trim(),username:$("newUserUsername").value.trim(),password:$("newUserPassword").value,role:$("newUserRole").value,station_id:$("newUserStation").value};
            const u=await api("/api/users",{method:"POST",body:JSON.stringify(payload)});
            $("newUserName").value=$("newUserUsername").value=$("newUserPassword").value="";
            $("userCreateStatus").textContent=`Created ${u.name} successfully.`;
            await loadUsers(); showToast("User account created");
        }catch(e){showToast(e.message);}
    }

    let cameraStreamRunning = false;
    let cameraRangeTimer = null;
    let cameraVisionTimer = null;

    async function loadCameraStatus() {
        try {
            const data = await api("/api/camera/status");
            const chip = $("cameraStatusChip");
            const text = $("cameraStatusText");
            if ($("cameraIndexValue")) $("cameraIndexValue").textContent = `Webcam ${data.camera_index}`;
            if ($("cameraMarkerValue")) $("cameraMarkerValue").textContent = `ID ${data.marker_id} · ${data.marker_size_cm} cm`;
            if (chip) { chip.textContent = data.available ? "Camera ready" : "Camera unavailable"; chip.className = `status-chip ${data.available ? "camera-good" : "camera-bad"}`; }
            if (text && !cameraStreamRunning) text.textContent = data.available ? "Ready to start" : (data.message || "Unavailable");
        } catch (error) {
            if ($("cameraStatusChip")) { $("cameraStatusChip").textContent = "Camera unavailable"; $("cameraStatusChip").className = "status-chip camera-bad"; }
            if ($("cameraStatusText")) $("cameraStatusText").textContent = error.message;
        }
    }

    function stopCameraVision() {
        const feed = $("cameraLiveFeed");
        if (feed) feed.removeAttribute("src");
        cameraStreamRunning = false;
        if (cameraRangeTimer) { clearInterval(cameraRangeTimer); cameraRangeTimer = null; }
        if (cameraVisionTimer) { clearInterval(cameraVisionTimer); cameraVisionTimer = null; }
        if ($("cameraPlaceholder")) { $("cameraPlaceholder").style.display = "flex"; $("cameraPlaceholder").querySelector("strong").textContent = "Camera is off"; }
        if ($("cameraStatusText")) $("cameraStatusText").textContent = "Stopped";
        if ($("cameraStatusChip")) { $("cameraStatusChip").textContent = "Camera stopped"; $("cameraStatusChip").className = "status-chip"; }
    }

    async function updateCameraRange() {
        if (!cameraStreamRunning) return;
        try {
            const data = await api("/api/camera/range");
            if ($("cameraRangeValue")) $("cameraRangeValue").textContent = data.detected ? `${formatNumber(data.distance_cm)} cm` : "—";
            if ($("cameraRangeStatus")) $("cameraRangeStatus").textContent = data.detected ? `Marker ID ${data.marker_id} detected · approximate range` : (data.message || "Show the range marker");
        } catch (error) {
            if ($("cameraRangeStatus")) $("cameraRangeStatus").textContent = error.message;
        }
    }

    async function updateCameraVision() {
        if (!cameraStreamRunning) return;
        try {
            const data = await api("/api/camera/vision");
            const status = data.fire_detected ? "FIRE DETECTED" : (data.smoke_detected ? "SMOKE DETECTED" : (data.status === "analyzing" ? "Analyzing…" : "VISUAL CLEAR"));
            if ($("cameraVisionStatus")) $("cameraVisionStatus").textContent = status;
            if ($("cameraVisionMessage")) $("cameraVisionMessage").textContent = data.message || "Waiting for visual analysis.";
            if ($("cameraVisionConfidence")) $("cameraVisionConfidence").textContent = data.confidence != null ? `${formatNumber(data.confidence)}%` : "—";
            if ($("cameraSmokeScore")) $("cameraSmokeScore").textContent = data.smoke_score != null ? `${formatNumber(data.smoke_score)}%` : "—";
            if ($("cameraFireScore")) $("cameraFireScore").textContent = data.fire_score != null ? `${formatNumber(data.fire_score)}%` : "—";
            if ($("cameraMotionScore")) $("cameraMotionScore").textContent = data.motion_score != null ? `${formatNumber(data.motion_score)}%` : "—";
            const card = $("cameraVisionCard");
            if (card) { card.classList.remove("vision-fire","vision-smoke","vision-clear"); card.classList.add(data.fire_detected ? "vision-fire" : (data.smoke_detected ? "vision-smoke" : "vision-clear")); }
        } catch (error) {
            if ($("cameraVisionStatus")) $("cameraVisionStatus").textContent = "Unavailable";
            if ($("cameraVisionMessage")) $("cameraVisionMessage").textContent = error.message;
        }
    }

    async function startCameraVision() {
        try {
            const data = await api("/api/camera/status");
            if (!data.available) throw new Error(data.message || "PC camera is unavailable");
            const feed = $("cameraLiveFeed");
            if (feed) feed.src = `/camera/stream?ts=${Date.now()}`;
            cameraStreamRunning = true;
            if ($("cameraPlaceholder")) $("cameraPlaceholder").style.display = "none";
            if ($("cameraStatusText")) $("cameraStatusText").textContent = "Live · local processing";
            if ($("cameraStatusChip")) { $("cameraStatusChip").textContent = "Camera live"; $("cameraStatusChip").className = "status-chip camera-good"; }
            if (cameraRangeTimer) clearInterval(cameraRangeTimer);
            await updateCameraRange();
            await updateCameraVision();
            cameraRangeTimer = setInterval(updateCameraRange, 1200);
            cameraVisionTimer = setInterval(updateCameraVision, 900);
        } catch (error) {
            showToast(error.message);
            if ($("cameraStatusText")) $("cameraStatusText").textContent = error.message;
        }
    }

    function captureCameraSnapshot() {
        if (!cameraStreamRunning) { showToast("Start the camera first"); return; }
        const image = $("cameraLiveFeed");
        if (!image) return;
        const link = document.createElement("a");
        link.href = `/api/camera/snapshot?ts=${Date.now()}`;
        link.download = `ai-safe-camera-${new Date().toISOString().replaceAll(":","-")}.jpg`;
        document.body.appendChild(link); link.click(); link.remove();
        showToast("Camera image captured");
    }

    function switchView(view) {
        document.querySelectorAll(".view-panel").forEach(panel => panel.classList.remove("active"));
        const target = $(`view-${view}`);
        if (target) target.classList.add("active");
        document.querySelectorAll(".side-link").forEach(link => link.classList.toggle("active", link.dataset.view === view));
        const title = $("pageTitle");
        const pageTitles = {
            overview: "Overview",
            monitoring: "Live Monitoring",
            camera: "Camera & Range Vision",
            map: "Incident Map",
            "precautions-emergency": "Precautions & Emergency",
            alerts: "Alerts",
            incidents: "History",
            reports: "Reports",
            devices: "Device Status",
            admin: "User Management",
            settings: "Settings"
        };
        if (title) title.textContent = pageTitles[view] || view.charAt(0).toUpperCase() + view.slice(1);
        if (window.innerWidth <= 760) $("sidebar").classList.remove("open");
        if (view === "incidents") loadDashboard();
        if (view === "smoke") renderSmokeMonitor(state.dashboard?.hardware || {});
        if (view === "precautions-emergency") { loadPrecautions(); loadEmergencySettings(); loadDispatches(); }
        if (view === "map") { loadNetworkStations(); loadStationExplorer(); }
        if (view === "admin" && window.AI_SAFE_ROLE === "admin") loadUsers();
        if (view === "camera") loadCameraStatus();
        if (view !== "camera" && cameraStreamRunning) stopCameraVision();
    }


    async function loadAdvancedInsights() {
        try {
            const data=await api("/api/advanced-insights");
            const r=data.risk||{};
            if($("riskScoreValue")) $("riskScoreValue").textContent=r.score ?? 0;
            if($("riskLabelValue")) { $("riskLabelValue").textContent=r.label||"—"; $("riskLabelValue").className=`risk-${String(r.label||"").toLowerCase()}`; }
            if($("riskPredictionValue")) $("riskPredictionValue").textContent=r.prediction||"—";
            if($("anomalyValue")) { $("anomalyValue").textContent=r.anomaly?"YES":"No"; $("anomalyValue").className=r.anomaly?"risk-critical":"risk-low"; }
            if($("riskExplanation")) $("riskExplanation").textContent=`Current smoke: ${formatNumber(r.smoke_current)} · Recent average: ${formatNumber(r.smoke_average)} · AQI is weighted with smoke and recent trend. ${r.anomaly?"A possible sensor/incident anomaly was detected.":"No major anomaly detected."}`;
            renderMap();
            const h=data.hardware||{};
            if($("healthArduino")) $("healthArduino").textContent=h.connected?"ONLINE":"OFFLINE";
            if($("healthMq")) $("healthMq").textContent=h.mq135_raw==null?"NO READING":formatNumber(h.mq135_raw);
            if($("healthLast")) $("healthLast").textContent=h.updated_at||"Not read";
            const c=data.calibration||{};
            if($("calBaseline")) $("calBaseline").value=c.baseline??0;
            if($("calNextDue")) $("calNextDue").value=(c.next_due||"").slice(0,10);
            if($("calNotes")) $("calNotes").value=c.notes||"";
            if($("calibrationStatus")) $("calibrationStatus").textContent=`Last calibrated: ${c.calibrated_at||"—"}`;
        } catch(e) { console.warn("Advanced insights",e); }
    }

    let liveLocationMap = null;
    let liveLocationMarker = null;
    let liveLocationAccuracy = null;
    let liveLocationWatchId = null;

    function initLiveLocationMap() {
        const mapEl = $("incidentMap");
        if (!mapEl || typeof L === "undefined") return;
        if (!liveLocationMap) {
            liveLocationMap = L.map(mapEl, { zoomControl: true }).setView([20.5937, 78.9629], 5);
            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }).addTo(liveLocationMap);
        }
        setTimeout(() => liveLocationMap.invalidateSize(), 100);
    }

    function updateLiveLocation(position) {
        initLiveLocationMap();
        if (!liveLocationMap) return;
        const lat = position.coords.latitude, lng = position.coords.longitude, accuracy = position.coords.accuracy;
        const icon = L.divIcon({ className: "live-location-marker", html: "📍", iconSize: [28,28], iconAnchor: [14,28] });
        if (!liveLocationMarker) liveLocationMarker = L.marker([lat,lng], {icon}).addTo(liveLocationMap).bindPopup("<b>📍 Your current location</b><br>AI-SAFE live GPS");
        else liveLocationMarker.setLatLng([lat,lng]);
        if (!liveLocationAccuracy) liveLocationAccuracy = L.circle([lat,lng], {radius:accuracy, color:"#1976d2", fillColor:"#1976d2", fillOpacity:.12, weight:1}).addTo(liveLocationMap);
        else liveLocationAccuracy.setLatLng([lat,lng]).setRadius(accuracy);
        liveLocationMap.setView([lat,lng], Math.max(liveLocationMap.getZoom(),16), {animate:true});
        if ($("currentLatitude")) $("currentLatitude").textContent=lat.toFixed(6);
        if ($("currentLongitude")) $("currentLongitude").textContent=lng.toFixed(6);
        if ($("currentAccuracy")) $("currentAccuracy").textContent=`±${Math.round(accuracy)} m`;
        if ($("currentLocationUpdated")) $("currentLocationUpdated").textContent=new Date().toLocaleTimeString();
        if ($("locationStatus")) { $("locationStatus").textContent="● LIVE LOCATION"; $("locationStatus").style.color="#16955c"; }
        if ($("mapNote")) $("mapNote").textContent="Your live device location is shown. Move with your device and the marker will update automatically.";
        const card=document.querySelector(".location-card strong"); if(card) card.textContent=`⌖ ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    }

    function handleLocationError(error) {
        const messages={1:"Location permission was denied. Allow location access in the browser.",2:"Your location is currently unavailable. Check GPS/location services.",3:"Location request timed out. Try again."};
        if ($("locationStatus")) { $("locationStatus").textContent=messages[error.code]||"Unable to get your location."; $("locationStatus").style.color="#d63e43"; }
        if ($("mapNote")) $("mapNote").textContent=messages[error.code]||"Unable to get your location.";
    }

    function startLiveLocation() {
        initLiveLocationMap();
        if (!navigator.geolocation) return handleLocationError({code:2});
        if (liveLocationWatchId !== null) navigator.geolocation.clearWatch(liveLocationWatchId);
        if ($("locationStatus")) $("locationStatus").textContent="Requesting live location…";
        liveLocationWatchId=navigator.geolocation.watchPosition(updateLiveLocation,handleLocationError,{enableHighAccuracy:true,maximumAge:5000,timeout:15000});
    }

    function renderMap() {
        initProfessionalMap();
        if(networkStations.length) renderNetworkStations(networkStations);
        else loadNetworkStations();
    }

    function initHistoryFilters(){
        ["historySearch","historySeverityFilter","historyStatusFilter"].forEach(id=>{
            $(id)?.addEventListener(id==="historySearch"?"input":"change",()=>renderIncidents());
        });
        $("refreshIncidents")?.addEventListener("click",()=>loadDashboard(true));
    }

    function initMapControls(){
        document.querySelectorAll("[data-map-status]").forEach(btn=>btn.addEventListener("click",()=>{
            document.querySelectorAll("[data-map-status]").forEach(b=>b.classList.remove("active"));
            btn.classList.add("active"); networkStatusFilter=btn.dataset.mapStatus||"all"; renderNetworkStations(networkStations);
        }));
        $("mapSearch")?.addEventListener("input",e=>{networkSearch=e.target.value||""; renderNetworkStations(networkStations);});
        $("mapDeviceFilter")?.addEventListener("change",e=>{networkSearch=e.target.value==="all"?"":(networkStations.find(s=>String(s.id)===String(e.target.value))?.station_name||""); if($("mapSearch")) $("mapSearch").value=networkSearch; renderNetworkStations(networkStations);});
        $("mapLayerSelect")?.addEventListener("change",e=>{
            networkLayer=e.target.value; initProfessionalMap();
            if(networkLayer==="satellite"){ if(lightTileLayer) networkMap.removeLayer(lightTileLayer); if(satelliteTileLayer) satelliteTileLayer.addTo(networkMap); }
            else { if(satelliteTileLayer) networkMap.removeLayer(satelliteTileLayer); if(lightTileLayer) lightTileLayer.addTo(networkMap); }
        });
        $("mapZoomIn")?.addEventListener("click",()=>networkMap?.zoomIn());
        $("mapZoomOut")?.addEventListener("click",()=>networkMap?.zoomOut());
        $("mapLocateButton")?.addEventListener("click",()=>centerActiveMapAlerts());
        $("mapCenterActive")?.addEventListener("click",()=>centerActiveMapAlerts());
        $("mapViewAllAlerts")?.addEventListener("click",()=>switchView("alerts"));
        $("mapOptionsButton")?.addEventListener("click",()=>showToast("Map options: use the filters, Map/Satellite selector and exploration controls."));
        $("mapShowStations")?.addEventListener("click",()=>{
            networkStatusFilter="all"; document.querySelectorAll("[data-map-status]").forEach(b=>b.classList.toggle("active",b.dataset.mapStatus==="all"));
            renderNetworkStations(networkStations);
        });
        $("mapShowAlerts")?.addEventListener("click",()=>centerActiveMapAlerts());
        $("mapResetView")?.addEventListener("click",()=>{
            networkStatusFilter="all"; networkSearch="";
            if($("mapSearch")) $("mapSearch").value="";
            if($("mapDeviceFilter")) $("mapDeviceFilter").value="all";
            renderNetworkStations(networkStations);
        });
    }

    function centerActiveMapAlerts(){
        if(!networkMap) return;
        const active=networkStations.filter(st=>["critical","warning"].includes(stationStatusKey(st.status)));
        if(!active.length){ showToast("No active critical or warning alerts"); return; }
        if(active.length===1){ const st=active[0]; networkMap.setView([Number(st.latitude),Number(st.longitude)],15,{animate:true}); const marker=networkMarkers.find(m=>m._aiSafeStationId===Number(st.id)); marker?.openPopup(); }
        else { networkMap.fitBounds(L.latLngBounds(active.map(s=>[Number(s.latitude),Number(s.longitude)])).pad(.3),{maxZoom:14,animate:true}); }
    }

    async function saveCalibration(){
        try { const d=await api("/api/calibration",{method:"PUT",body:JSON.stringify({baseline:$('calBaseline').value,next_due:$('calNextDue').value,notes:$('calNotes').value})}); if($("calibrationStatus")) $("calibrationStatus").textContent=`Calibration saved: ${d.calibrated_at}`; showToast("Calibration record saved"); } catch(e){showToast(e.message)}
    }

    navigator.serviceWorker?.addEventListener("message", event => {
        const data = event.data || {};
        if (data.type === "AI_SAFE_NOTIFICATION_CLICK") openNotification(data.notificationId, data.incidentId);
    });


    function guardianRead(text) {
        const status = $("guardianVoiceStatus");
        if (status) status.textContent = "🔊 Speaking…";
        const ok = speakText(text, {rate:.95});
        if (!ok && status) status.textContent = "Voice not supported — use the text reply.";
        const popupStatus = $("guardianPopupStatus");
        if (popupStatus) popupStatus.textContent = text;
    }

    function guardianDataReply(query) {
        const q = String(query || "").toLowerCase().trim();
        const d = state.dashboard || {}, h = d.hardware || {};
        const smoke = Number(h.mq135_raw ?? d.smoke_level ?? 0);
        const aqi = Number(d.aqi ?? d.air_quality?.current_aqi ?? 0);
        const risk = d.risk_prediction?.score ?? d.risk_prediction?.risk_score;
        const sensor = h.connected === false ? "offline" : "online";
        if (!q || q.includes("help") || q.includes("what can you")) return "I can help with live AQI, smoke level, risk, sensor status, precautions, alerts, maps, reports, emergency response, and manual ON or OFF settings. Try asking: How do I turn automatic updates off?";
        if (q.includes("manual") || q.includes("on off") || q.includes("turn") || q.includes("switch")) return "Manual controls guide. Automatic Updates: turn ON for automatic refresh about every five seconds, or OFF and use the refresh button manually. Critical Voice Alerts: ON speaks critical alerts, OFF keeps them silent. Automatic Emergency Alerts: ON queues demo emergency messages for critical events, OFF leaves the emergency workflow manual. Browser Notifications are enabled from Settings. Quiet Hours suppress browser notifications during the selected hours. Compact Mode reduces dashboard spacing.";
        if (q.includes("aqi") || q.includes("air quality")) return `Current AQI is ${Math.round(aqi)}. Use AQI Analytics for trends and pollutant details.`;
        if (q.includes("smoke")) return `Current smoke level is ${Math.round(smoke)}. ${smoke>=state.smokeCritical?"This is critical. Move away from the affected area and follow emergency guidance.":smoke>=state.smokeWarning?"This is in the warning range. Avoid the affected area and monitor the trend.":smoke>=300?"This is elevated. Continue monitoring for rapid increase.":"This is in the normal range."}`;
        if (q.includes("risk")) return risk != null ? `The current AI risk score is ${Math.round(Number(risk))} out of 100.` : "The AI risk score is not available yet.";
        if (q.includes("sensor") || q.includes("arduino")) return `The current hardware status is ${sensor}. The dashboard also shows MQ-135 and MQ-135 status in Device Status and Sensor Health.`;
        if (q.includes("precaution") || q.includes("safe") || q.includes("hazard")) return "For critical smoke, evacuate the affected area and avoid smoke-filled areas. For gas or chemicals, do not touch unknown substances and wait for trained HazMat personnel. For hazardous AQI, reduce exposure and follow local guidance.";
        if (q.includes("alert") || q.includes("notification")) return "Open Alerts to review recent notifications. Browser notifications can be enabled in Settings, and quiet hours can suppress them during selected times.";
        if (q.includes("map") || q.includes("location")) return "Open Incident Map to use the live location feature. Allow browser location permission when prompted.";
        if (q.includes("report")) return "Open Reports to export database records and incident reports.";
        if (q.includes("emergency")) return "Open Emergency Response to review manual and automatic emergency-response settings. The project queues demo messages and does not contact real agencies unless an approved integration is connected.";
        return "I can help with that. For project navigation, ask me to open the map, alerts, precautions, smoke monitor, analytics, reports, or manual controls.";
    }

    function guardianHandleQuery(query) {
        const q = String(query || "").trim(); if (!q) return;
        const lower=q.toLowerCase();
        const routes=[
            ["dashboard","overview"],["home","overview"],["smoke monitor","smoke"],["smoke","smoke"],["precautions","precautions"],["safety guide","precautions"],["emergency response","emergency"],["emergency","emergency"],["alerts","alerts"],["notifications","alerts"],["map","map"],["location","map"],["aqi analytics","analytics"],["analytics","analytics"],["risk prediction","risk"],["sensor health","health"],["device status","devices"],["reports","reports"]
        ];
        const nav=routes.find(([phrase])=>lower.includes(phrase));
        if(nav && !lower.includes("what") && !lower.includes("how") && !lower.includes("status") && !lower.includes("current")){ switchView(nav[1]); }
        let reply = guardianDataReply(q);
        if (lower.includes("turn automatic updates off") || lower.includes("turn auto refresh off") || lower.includes("automatic updates off")) {
            state.autoRefresh=false; if($("autoRefresh")) $("autoRefresh").checked=false; reply="Automatic updates are now OFF. Use the ↻ Refresh button whenever you want fresh data."; showToast("Automatic updates turned OFF");
        } else if (lower.includes("turn automatic updates on") || lower.includes("turn auto refresh on") || lower.includes("automatic updates on")) {
            state.autoRefresh=true; if($("autoRefresh")) $("autoRefresh").checked=true; reply="Automatic updates are now ON and the dashboard will refresh about every five seconds."; showToast("Automatic updates turned ON");
        } else if (lower.includes("turn voice alerts off") || lower.includes("critical voice alerts off")) {
            setCriticalVoiceAlerts(false, false); reply="Critical voice alerts are now OFF. Visual and in-app alerts can still appear."; showToast("Critical voice alerts turned OFF");
        } else if (lower.includes("turn voice alerts on") || lower.includes("critical voice alerts on")) {
            setCriticalVoiceAlerts(true, false); reply="Critical voice alerts are now ON. AI-SAFE can speak critical safety alerts."; showToast("Critical voice alerts turned ON");
        }
        if ($("guardianUserMessage")) $("guardianUserMessage").textContent = `You: ${q}`;
        if ($("guardianReply")) $("guardianReply").textContent = `AI-SAFE Guardian: ${reply}`;
        if ($("guardianPopupReply")) $("guardianPopupReply").textContent = reply;
        if ($("guardianPopupStatus")) $("guardianPopupStatus").textContent = "Ready to help";
        return reply;
    }

    function initGuardian() {
        const fab=$("guardianFab"), popup=$("guardianPopup");
        const openPopup=()=>{ if(popup){popup.classList.add("open");popup.setAttribute("aria-hidden","false");} };
        const closePopup=()=>{ if(popup){popup.classList.remove("open");popup.setAttribute("aria-hidden","true");} };
        fab?.addEventListener("click",openPopup); $("guardianPopupClose")?.addEventListener("click",closePopup);
        $("guardianAsk")?.addEventListener("click",()=>{const r=guardianHandleQuery($("guardianInput")?.value); if(r) guardianRead(r);});
        $("guardianInput")?.addEventListener("keydown",e=>{if(e.key==="Enter") $("guardianAsk")?.click();});
        document.querySelectorAll("[data-guardian-query]").forEach(b=>b.addEventListener("click",()=>{const q=b.dataset.guardianQuery; const r=guardianHandleQuery(q); if(r) guardianRead(r);}));
        $("guardianPopupAsk")?.addEventListener("click",()=>{const r=guardianHandleQuery($("guardianPopupInput")?.value); if(r) guardianRead(r);});
        $("guardianPopupInput")?.addEventListener("keydown",e=>{if(e.key==="Enter") $("guardianPopupAsk")?.click();});
        $("guardianPopupRead")?.addEventListener("click",()=>guardianRead($("guardianPopupReply")?.textContent||""));
        $("guardianPopupStop")?.addEventListener("click",stopVoice); $("guardianStop")?.addEventListener("click",stopVoice);
        $("guardianSpeak")?.addEventListener("click",()=>guardianRead($("guardianReply")?.textContent||""));
        $("guardianGuideToggle")?.addEventListener("click",()=>{const g=$("guardianPopupGuide"); if(g){g.hidden=!g.hidden;}});
        $("guardianListen")?.addEventListener("click",()=>{
            const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
            if(!SR){showToast("Voice input is not supported in this browser. Use the text box instead.");return;}
            const rec=new SR(); rec.lang="en-IN"; rec.interimResults=false; rec.maxAlternatives=1;
            const status=$("guardianVoiceStatus"); if(status) status.textContent="🎤 Listening…";
            rec.onresult=e=>{const text=e.results[0][0].transcript; const r=guardianHandleQuery(text); if(r) guardianRead(r);};
            rec.onerror=()=>{if(status) status.textContent="Could not hear you. Try again or type your question.";}; rec.onend=()=>{if(!voiceState.speaking&&status) status.textContent="Assistant ready";}; rec.start();
        });
        $("guardianPopupListen")?.addEventListener("click",()=>$("guardianListen")?.click());
        $("guardianPopupInput")?.addEventListener("focus",openPopup);
    }

    document.addEventListener("DOMContentLoaded", async () => {
        try{
            const sessionData=await api("/api/session");
            window.AI_SAFE_ROLE=String(sessionData.role||"user").toLowerCase();
            window.AI_SAFE_USER_ID=sessionData.user?.id;
            document.querySelectorAll(".admin-only").forEach(el=>el.hidden=window.AI_SAFE_ROLE!=="admin");
            const adminPanel=$("view-admin"); if(adminPanel) adminPanel.hidden=window.AI_SAFE_ROLE!=="admin";
            if($("roleBadge") && sessionData.user) $("roleBadge").textContent=`${String(sessionData.role||"USER").toUpperCase()} · ${sessionData.user.station_name||"ALL STATIONS"}`;
        }catch(e){console.warn(e);}
        updateClock();
        initGuardian();
        initHistoryFilters();
        initMapControls();
        setInterval(updateClock, 1000);
        await loadLiveSmokeHistory();
        loadDashboard(true);
        registerNotificationServiceWorker();
        loadNotificationSettings();
        loadNotifications(true);
        loadAdvancedInsights();

        document.querySelectorAll(".side-link").forEach(link => link.addEventListener("click", () => switchView(link.dataset.view)));
        document.querySelectorAll(".small-button[data-view]").forEach(button => button.addEventListener("click", () => switchView(button.dataset.view)));
        $("mobileMenu")?.addEventListener("click", () => $("sidebar").classList.toggle("open"));
        $("refreshButton")?.addEventListener("click", () => loadDashboard(true));
        $("startCameraButton")?.addEventListener("click", startCameraVision);
        $("stopCameraButton")?.addEventListener("click", stopCameraVision);
        $("snapshotCameraButton")?.addEventListener("click", captureCameraSnapshot);
        $("themeToggle")?.addEventListener("click", () => {
            state.dark = !state.dark;
            document.body.classList.toggle("dark", state.dark);
            showToast(state.dark ? "Dark theme enabled" : "Light theme enabled");
        });
        $("compactMode")?.addEventListener("change", event => {
            state.compact = event.target.checked;
            document.body.classList.toggle("compact", state.compact);
        });
        $("autoRefresh")?.addEventListener("change", event => {
            state.autoRefresh = event.target.checked;
            showToast(state.autoRefresh ? "Automatic database refresh enabled" : "Automatic refresh paused");
        });
        $("notificationButton")?.addEventListener("click", () => { switchView("alerts"); loadNotifications(false); });
        document.querySelectorAll(".smoke-range").forEach(btn=>btn.addEventListener("click",()=>{ document.querySelectorAll(".smoke-range").forEach(b=>b.classList.remove("active")); btn.classList.add("active"); state.smokeRangeHours=Number(btn.dataset.hours)||1; renderSmokeMonitor(state.dashboard?.hardware||{}); }));
        $("smokeSensorSelect")?.addEventListener("change",()=>showToast(`Monitoring ${$("smokeSensorSelect").value}`));
        $("enablePushNotifications")?.addEventListener("click", enableBrowserNotifications);
        $("saveNotificationSettings")?.addEventListener("click", saveNotificationSettings);
        $("saveEmergencySettings")?.addEventListener("click", saveEmergencySettings);
        $("speakPrecautions")?.addEventListener("click", speakPrecautions);
        $("speakCurrentGuidance")?.addEventListener("click", speakCurrentGuidance);
        $("stopVoice")?.addEventListener("click", stopVoice);
        $("autoVoiceAlerts")?.addEventListener("change", e => { setCriticalVoiceAlerts(e.target.checked, true); });
        $("testEmergencyAlert")?.addEventListener("click", testEmergencyAlert);
        $("refreshDispatches")?.addEventListener("click", loadDispatches);
        $("saveCalibration")?.addEventListener("click", saveCalibration);
        $("startLocationButton")?.addEventListener("click", startLiveLocation);
        $("backupDatabase")?.addEventListener("click", () => { window.location.href="/api/database-backup"; });
        $("downloadPdfReport")?.addEventListener("click", () => { window.location.href="/api/incidents/report.pdf"; });
        $("downloadCsvReport")?.addEventListener("click", () => { window.location.href="/api/incidents/export"; });
        $("markAllNotifications")?.addEventListener("click", async () => { await api("/api/notifications/read-all", { method: "POST" }); await loadNotifications(false); showToast("All notifications marked as read"); });
        $("notificationList")?.addEventListener("click", event => {
            const readButton = event.target.closest("[data-read-id]");
            if (readButton) { event.stopPropagation(); openNotification(readButton.dataset.readId, null); return; }
            const item = event.target.closest(".notification-item");
            if (item) openNotification(item.dataset.notificationId, item.dataset.incidentId);
        });
        $("exportReport")?.addEventListener("click", () => { window.location.href = "/api/incidents/export"; });
        $("dateButton")?.addEventListener("click", () => showToast("Showing records currently stored in the database"));
        $("globalSearch")?.addEventListener("input", event => {
            const query = event.target.value.trim().toLowerCase();
            if (!query) {
                renderIncidents();
                return;
            }
            const filtered = state.incidents.filter(item => `${item.incident_type} ${item.sensor} ${item.severity} ${item.status}`.toLowerCase().includes(query));
            const original = state.incidents;
            state.incidents = filtered;
            renderIncidents();
            state.incidents = original;
        });
        document.querySelectorAll(".chart-tab").forEach(button => button.addEventListener("click", () => {
            document.querySelectorAll(".chart-tab").forEach(item => item.classList.remove("active"));
            button.classList.add("active");
            showToast(button.dataset.range === "week" ? "Showing database trend" : "Showing today's database trend");
        }));

        document.querySelectorAll(".metric-tab, .clickable-metric").forEach(button => button.addEventListener("click", () => {
            const metric=button.dataset.metric; if(!metric) return;
            selectedMetric=metric;
            document.querySelectorAll(".metric-tab").forEach(b=>b.classList.toggle("active", b.dataset.metric===metric));
            renderInteractiveCharts(state.dashboard?.air_quality?.trend || []);
            showToast(`${metricLabel(metric)} chart selected`);
        }));

        $("airDatasetSelect")?.addEventListener("change", async event => {
            state.dataPage = 0;
            await loadDashboard(true);
        });

        $("prevDataPage")?.addEventListener("click", async () => {
            if (state.dataPage > 0) {
                state.dataPage -= 1;
                await loadAirQuality(state.dataSource, true, state.dataPage);
            }
        });

        $("nextDataPage")?.addEventListener("click", async () => {
            const totalPages = Math.max(1, Math.ceil(state.dataTotal / state.dataPageSize));
            if (state.dataPage + 1 < totalPages) {
                state.dataPage += 1;
                await loadAirQuality(state.dataSource, true, state.dataPage);
            }
        });

        $("addIncidentButton")?.addEventListener("click", () => openIncidentModal());
        $("createUserButton")?.addEventListener("click", createUser);
        $("refreshUsers")?.addEventListener("click", loadUsers);
        $("userTable")?.addEventListener("click", async event => {
            const b=event.target.closest(".delete-user"); if(!b) return;
            if(!confirm("Delete this user account?")) return;
            try{await api(`/api/users/${b.dataset.id}`,{method:"DELETE"}); await loadUsers(); showToast("User deleted");}
            catch(e){showToast(e.message);}
        });
        $("closeIncidentModal")?.addEventListener("click", closeIncidentModal);
        $("cancelIncidentButton")?.addEventListener("click", closeIncidentModal);
        $("incidentForm")?.addEventListener("submit", saveIncident);
        $("incidentModal")?.addEventListener("click", event => {
            if (event.target === $("incidentModal")) closeIncidentModal();
        });

        $("incidentTable")?.addEventListener("click", event => {
            const button = event.target.closest("button[data-action]");
            if (!button) return;
            const id = Number(button.dataset.id);
            const incident = state.incidents.find(item => Number(item.id) === id);
            if (button.dataset.action === "edit" && incident) openIncidentModal(incident);
            if (button.dataset.action === "delete") deleteIncident(id);
        });

        document.addEventListener("keydown", event => {
            if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
                event.preventDefault();
                $("globalSearch")?.focus();
            }
            if (event.key === "Escape" && $("incidentModal")?.classList.contains("open")) closeIncidentModal();
        });

        // Fast live channel: Arduino readings + notifications are checked every second.
        // The serial reader is already running continuously in Flask, so this request is non-blocking.
        setInterval(() => {
            if (state.autoRefresh && !$("incidentModal")?.classList.contains("open")) {
                refreshHardware(false);
                loadNotifications(true);
            }
        }, 1000);

        // Heavier dashboard/SQLite refresh remains every 5 seconds.
        setInterval(() => {
            if (state.autoRefresh && !$("incidentModal")?.classList.contains("open")) {
                loadDashboard();
                loadAdvancedInsights();
            }
        }, 5000);
    });
})();
