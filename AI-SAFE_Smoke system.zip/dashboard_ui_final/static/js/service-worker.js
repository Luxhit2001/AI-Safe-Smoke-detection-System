self.addEventListener("install", event => {
  self.skipWaiting();
});
self.addEventListener("activate", event => {
  event.waitUntil(self.clients.claim());
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  const data = event.notification.data || {};
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then(clientList => {
      for (const client of clientList) {
        if ("focus" in client) {
          if (data.incidentId) client.postMessage({ type: "AI_SAFE_NOTIFICATION_CLICK", incidentId: data.incidentId, notificationId: data.notificationId });
          return client.focus();
        }
      }
      if (clients.openWindow) return clients.openWindow("/dashboard");
    })
  );
});
