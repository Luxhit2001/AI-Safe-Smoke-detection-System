/* AI-SAFE Firebase Cloud Messaging service worker. */
importScripts("https://www.gstatic.com/firebasejs/12.19.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/12.19.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyCDKc_h8FlcUpnWY5WUrBhuNDW4tK5j_hg",
  authDomain: "smoke-ai-safe-system.firebaseapp.com",
  projectId: "smoke-ai-safe-system",
  storageBucket: "smoke-ai-safe-system.firebasestorage.app",
  messagingSenderId: "386340271277",
  appId: "1:386340271277:web:4d6982058d07c4e5634224"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const notification = payload.notification || {};
  const data = payload.data || {};
  const title = notification.title || "AI-SAFE Safety Alert";
  const options = {
    body: notification.body || "New AI-SAFE safety alert.",
    icon: "/static/img/login-industrial-bg.jpg",
    tag: `ai-safe-${data.notification_id || Date.now()}`,
    renotify: true,
    data: {
      notificationId: data.notification_id,
      incidentId: data.incident_id,
      location: data.location
    }
  };
  self.registration.showNotification(title, options);
});

self.addEventListener("notificationclick", event => {
  event.notification.close();
  const data = event.notification.data || {};
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then(clientList => {
      for (const client of clientList) {
        if ("focus" in client) {
          client.postMessage({
            type: "AI_SAFE_NOTIFICATION_CLICK",
            notificationId: data.notificationId,
            incidentId: data.incidentId
          });
          return client.focus();
        }
      }
      if (clients.openWindow) return clients.openWindow("/dashboard");
    })
  );
});
