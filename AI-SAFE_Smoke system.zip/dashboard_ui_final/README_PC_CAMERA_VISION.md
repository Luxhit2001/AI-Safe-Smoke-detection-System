# AI-SAFE PC Camera & Range Vision

AI-SAFE can use the computer's built-in webcam for local computer vision. The Arduino UNO continues to provide MQ-135 sensor readings over USB; it does not process images.

## Features
- Live PC webcam feed at `/camera/stream`
- Single-frame camera snapshot at `/api/camera/snapshot`
- Camera status at `/api/camera/status`
- Approximate range at `/api/camera/range`
- ArUco marker-based range estimate

## Install
Run from `dashboard_ui_final`:

```powershell
pip install -r requirements.txt
```

## Start

```powershell
python app.py
```

Open the dashboard and choose **Camera & Range Vision**.

## Range setup
A normal single webcam does not directly measure depth. For a repeatable project demonstration, print an OpenCV ArUco 4x4 marker with ID `0` and a known side length of `10 cm`. Keep the full marker visible to the webcam.

Default settings:

```env
AI_SAFE_CAMERA_INDEX=0
AI_SAFE_RANGE_MARKER_SIZE_M=0.10
AI_SAFE_RANGE_MARKER_ID=0
AI_SAFE_CAMERA_FOCAL_LENGTH_PX=0
```

`AI_SAFE_CAMERA_FOCAL_LENGTH_PX=0` uses an initial approximate webcam field-of-view assumption. For better range accuracy, calibrate the webcam and set its focal length in pixels.

## Important
- Camera processing is local to the AI-SAFE PC; frames are not uploaded by this feature.
- Range is approximate unless the webcam is calibrated.
- Visual camera information is an aid alongside the MQ-135 alert engine; it is not a certified fire-safety measurement.
