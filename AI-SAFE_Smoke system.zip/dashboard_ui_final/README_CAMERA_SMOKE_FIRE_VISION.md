# AI-SAFE Camera Smoke/Fire Vision

AI-SAFE now combines the PC built-in webcam with the live MQ-135 Arduino reading and the existing Firebase FCM alert path.

## Detection flow

```text
PC webcam
   -> OpenCV visual analysis
      -> persistent smoke/fire-like visual signal
         + latest MQ-135 Arduino value
         + optional ArUco range estimate
            -> AI-SAFE notification center
               -> Firebase FCM push (if enabled)
```

## Visual detection

The camera uses a local OpenCV heuristic rather than claiming to be a trained/certified fire detector. It checks:

- warm red/orange/yellow high-saturation pixels for fire-like patterns
- low-saturation moving regions for smoke-like patterns
- temporal persistence so a single frame does not immediately create an alert

The live feed overlays `FIRE DETECTED`, `SMOKE DETECTED`, or `VISUAL: CLEAR`.

## Combined alerts

When a persistent camera signal is detected, AI-SAFE reads the latest MQ-135 value. The notification message records both signals and includes the approximate camera range when an ArUco marker is visible.

Examples:

- Camera + MQ-135 critical detection
- Camera + MQ-135 warning
- Camera visual smoke/fire detected (when no current MQ-135 reading is available or it is below warning)

All these notifications use the existing `create_notification()` path. Therefore they appear in the AI-SAFE Notification Center and are passed to Firebase FCM for registered devices.

## Tuning

Set these values in `.env` when needed:

```env
AI_SAFE_VISION_MIN_FRAMES=4
AI_SAFE_FIRE_SCORE_THRESHOLD=0.008
AI_SAFE_SMOKE_SCORE_THRESHOLD=0.018
AI_SAFE_VISION_MOTION_THRESHOLD=0.010
AI_SAFE_CAMERA_ALERT_COOLDOWN=60
```

Lower thresholds increase sensitivity and can also increase false positives. The camera feature is an assistive college-project computer-vision component, not a certified life-safety detector.

## Range

The existing ArUco marker range estimator remains active. A normal webcam does not directly measure depth; the displayed range is approximate unless the camera is calibrated.
