# AI-SAFE Safety & Emergency Response Update

## Precautions tab
The dashboard now includes a **Precautions to Take** tab covering:
- Fire / critical smoke
- Gas, chemical and HazMat incidents
- Hazardous air quality
- Arduino / sensor failure

Each card lists actions to take and hazards to avoid.

## Automatic Emergency Response tab
The dashboard now includes **Emergency Response** settings and a dispatch log. Critical smoke and extremely hazardous AQI can automatically create emergency-response messages for configured recipients, with a cooldown to avoid repeated dispatches.

Default response groups:
- Fire & Rescue
- Ambulance / Medical
- HazMat / Disaster Response
- Police Control (optional)

The generated message includes the event, severity, location, smoke level and AQI.

### Important demo limitation
This college-project build **does not contact real emergency agencies by itself**. Dispatch entries are labelled `Queued (Demo)` / `Test Queued`. To send real SMS, email or dispatch messages, connect an approved provider (for example an institutional emergency gateway, SMS/email service or authorized webhook) and configure it securely. Do not put real credentials in frontend JavaScript or commit them to the ZIP.

## Automatic trigger rules
- Critical smoke: automatic response can trigger.
- AQI >= 300: automatic hazardous-air response can trigger.
- Emergency response has a 10-minute event cooldown.
- Notification cooldown/quiet-hours settings remain separate from emergency dispatch.
