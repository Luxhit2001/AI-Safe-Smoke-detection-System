# AI-SAFE Login Reference Update

The login page was redesigned to closely match the supplied AI-SAFE reference:
- full-screen bright industrial/IoT background
- left-side AI-SAFE branding and four feature indicators
- single right-side frosted-glass login card
- User/Admin role tabs
- Email and Password fields
- Remember Me and Forgot Password
- teal-to-blue LOGIN button
- Register link

Existing Flask login endpoints and role handling are preserved.
