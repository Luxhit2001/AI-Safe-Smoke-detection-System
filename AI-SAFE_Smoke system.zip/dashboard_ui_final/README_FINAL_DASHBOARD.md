# AI-SAFE Final Dashboard

The dashboard was redesigned to closely match the supplied reference:
- Dark navy left navigation
- White header with System Online, notifications and user profile
- Four safety KPI cards
- Smoke level trend
- System status
- Recent alerts
- Recent events
- Quick actions
- Station information
- Technical environmental dataset moved into a collapsible section

Hardware/UI consistency:
- DHT11 removed
- MQ-135 is the smoke/gas sensor
- Arduino UNO reads MQ-135
- PC handles camera/image processing
- Live vs DEMO data is clearly labeled

Local/demo authentication:
- Fresh demo install defaults to admin / admin123 unless AI_SAFE_ADMIN_PASSWORD is set.
- Gmail SMTP is optional for local testing.
- Without SMTP, a local demo OTP is displayed on the OTP page.
