# AI-SAFE Dashboard Update

This version keeps the existing Flask login/logout flow and replaces only the dashboard presentation with a polished BCA-project dashboard inspired by the supplied reference image.

## Updated files

- `templates/dashboard.html` — new dashboard structure, sidebar, header, KPI cards, charts, activities, devices, alerts, settings and reports views.
- `static/css/dashboard.css` — responsive light dashboard styling with optional dark theme and compact mode.
- `static/js/dashboard.js` — navigation, clock, demo live updates, search shortcut, theme toggle, auto-refresh, incident table, alerts and CSV export.

## Kept unchanged

- `app.py`
- `templates/login.html`
- `static/css/login.css`
- `static/js/login.js`
- `requirements.txt`

## Run

1. Open a terminal in this project folder.
2. Install dependencies:

   `pip install -r requirements.txt`

3. Start Flask:

   `python app.py`

4. Open the local address shown by Flask (normally `http://127.0.0.1:5000`).
5. Use the existing project login.

The dashboard's sensor numbers are demonstration values and automatically refresh in the browser. Connect them to your Arduino/Flask API later without changing the visual layout.
