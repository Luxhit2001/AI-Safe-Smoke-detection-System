# AI-SAFE BCA Project – Feature Set

This version combines the college-level BCA features requested:

- AI risk prediction with explainable risk score
- Sensor anomaly detection
- Interactive GPS incident and safe-zone map
- AQI/PM2.5/PM10/CO/NO2 analytics
- Incident management with SQLite history
- Alert acknowledgement and notification center
- Browser push notifications with cooldown/quiet hours
- Emergency-response message queue for Fire & Rescue, Ambulance and HazMat (demo-safe; no real agency contacted)
- Precautions and safety checklist guidance
- Sensor health monitoring for Arduino UNO, MQ-135 and MQ-135
- Sensor calibration record and recalibration schedule
- PDF incident reports and CSV export
- SQLite database backup
- Login/session protection
- Responsive dashboard for desktop/mobile

## AI note
The risk score is an explainable project-level heuristic using AQI, smoke readings and recent incident trend. It is intended for demonstration/education and must not be treated as a certified emergency prediction system.

## Emergency note
Automatic emergency dispatch is implemented as a local queued/demo workflow. Connect an authorized messaging/dispatch provider before any real-world use. Do not rely on this project as a substitute for official emergency services.

## Voice Safety Guidance (Added)
- Browser-based text-to-speech voice response for the Precautions module.
- **Read Precautions** reads fire/smoke, HazMat, hazardous-air-quality and sensor-failure guidance aloud.
- **Speak Current Guidance** reads current smoke, AQI and AI risk context from the dashboard.
- **Stop** immediately stops speech.
- Optional automatic voice announcements for critical/emergency notifications.
- Uses the browser's built-in Speech Synthesis API; no API key is required.
- Voice guidance is informational only and does not replace trained emergency responders or local emergency procedures.


## Final polish added
- Removed duplicate dashboard element IDs so voice and settings controls target one element each.
- Added storytelling chart presentation: normal → rising → warning → critical → recovery.
- Added readable smoke-chart event markers and an incident-story timeline.
- Added realistic fallback smoke demo data when the Arduino is not connected, clearly labeled as demo data.
- Added subtle AQI risk bands for easier visual interpretation.
- Removed Python `__pycache__` files from the submission package.
- Reduced bundled demo datasets/database to a practical college-demo size while preserving both Dataset 1 and Dataset 2 and the SQLite schema.
- Voice controls remain independent from automatic dashboard refresh.
