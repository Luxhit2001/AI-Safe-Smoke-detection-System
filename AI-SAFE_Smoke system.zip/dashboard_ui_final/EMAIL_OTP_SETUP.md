# AI-SAFE Gmail OTP — Easy Setup

This version is designed for a simple Windows setup.

## First time only

1. Make a Gmail account for AI-SAFE to use as the **sender**.
2. Turn on **Google 2-Step Verification** for that account.
3. Create a **Google App Password** for AI-SAFE.
4. Double-click **`START_AI_SAFE.bat`**.
5. A black setup window will ask for:
   - Sender Gmail
   - Gmail App Password
   - Admin personal Gmail
6. After setup, AI-SAFE starts automatically.

You do **not** put your normal Gmail password into AI-SAFE.

## What happens after setup

### User registration
- User enters their name, username, personal Gmail and password.
- AI-SAFE sends a 6-digit OTP to that personal Gmail.
- Correct OTP creates the account.

### User login
- User enters username and password.
- AI-SAFE sends a new 6-digit OTP to the verified personal Gmail.
- Correct OTP opens the dashboard.

### Admin login
- The built-in admin account uses the Admin Gmail entered during setup for OTP delivery.

## Security

- OTPs are 6 digits.
- OTPs expire after 5 minutes.
- Maximum 5 incorrect attempts.
- Resend is limited to once every 60 seconds.
- OTPs are stored as hashes, not plain text.
- Gmail App Password is kept in the local `.env` file and is not stored in SQLite.
- `.env` is ignored by Git.

## Important

Never send your Gmail password or App Password to anyone. If an App Password is exposed, revoke it from Google and create a new one.
