# AI-SAFE UI Refinement — v2.1

This update refines the dashboard using the supplied reference screenshots.

## Main changes
- Added consistent desktop measurements, spacing and responsive breakpoints.
- Reworked Dashboard Overview with clearer smoke measurement wording, live-data state and monitoring pipeline.
- Expanded Incident History with summary metrics, filters and useful empty states.
- Expanded Alerts into a notification center with unread/critical summaries and explanation of automatic alert generation.
- Expanded Reports with report summaries, report categories and export actions.
- Expanded Device Status into a hardware/software diagnostic view.
- Added a station exploration directory below the Incident Map and controls for stations/active alerts/reset.
- Added station exploration cards linked to Leaflet markers.
- Added AQI classification reference to Precautions & Emergency.
- Removed the DHT11/temperature/humidity UI reference from Sensor Health because the current kit is Arduino UNO + MQ-135.
- Refined User Management wording and form presentation.
- Refined Login page copy so the two access modes are easier to recognize.
- Kept live hardware behavior intact: when Arduino is disconnected, the interface reports a waiting/offline state rather than inventing live readings.

## Measurement terminology
- MQ-135 Arduino raw/ADC index is displayed on a 0–1023 scale.
- Smoke warning/critical thresholds remain configurable (default 500 / 700).
- AI-SAFE's project AQI display remains 0–500 and is explicitly described as a normalized project index, not a certified regulatory AQI calculation.
- AQI reference bands are shown on the Precautions page.

## Map
Configured Punjab stations use the coordinates already present in the project database:
- Punjab Station 01 — Patiala: 30.3398, 76.3869
- Punjab Station 02 — Jalandhar: 31.3260, 75.5762
- Punjab Station 03 — Ludhiana: 30.9010, 75.8573
- Punjab Station 04 — Amritsar: 31.6340, 74.8723
- Punjab Station 05 — Chandigarh area: 30.7046, 76.7179

These labels should be treated as configured station locations; live sensor status still depends on connected hardware.
