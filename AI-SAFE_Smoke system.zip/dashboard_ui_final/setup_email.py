from pathlib import Path
import secrets
import getpass

BASE_DIR = Path(__file__).resolve().parent
ENV_FILE = BASE_DIR / '.env'


def load_existing():
    values = {}
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, v = line.split('=', 1)
            values[k.strip()] = v.strip()
    return values


def main():
    old = load_existing()
    print('\n========================================')
    print('       AI-SAFE EMAIL OTP SETUP')
    print('========================================\n')
    print('You only need to do this once.\n')
    print('1) Sender Gmail = the Gmail account AI-SAFE uses to SEND OTPs.')
    print('2) App Password = Google App Password for that sender Gmail.')
    print('3) Admin Gmail = where the built-in admin OTP will be sent.\n')

    sender = input(f"Sender Gmail [{old.get('AI_SAFE_GMAIL_ADDRESS','')}]: ").strip() or old.get('AI_SAFE_GMAIL_ADDRESS','')
    if not sender:
        print('Sender Gmail is required.')
        return 1

    app_pw = getpass.getpass('Gmail App Password (16 characters): ').strip().replace(' ', '')
    if not app_pw:
        app_pw = old.get('AI_SAFE_GMAIL_APP_PASSWORD','')
    if not app_pw:
        print('Gmail App Password is required.')
        return 1

    admin = input(f"Admin personal Gmail [{old.get('AI_SAFE_ADMIN_EMAIL','')}]: ").strip() or old.get('AI_SAFE_ADMIN_EMAIL','')
    if not admin:
        print('Admin Gmail is required.')
        return 1

    secret = old.get('AI_SAFE_SECRET_KEY') or secrets.token_urlsafe(48)
    env = (
        '# AI-SAFE local email security settings\n'
        '# This file is private. Never upload it or share the App Password.\n'
        f'AI_SAFE_GMAIL_ADDRESS={sender}\n'
        f'AI_SAFE_GMAIL_APP_PASSWORD={app_pw}\n'
        f'AI_SAFE_ADMIN_EMAIL={admin}\n'
        f'AI_SAFE_SECRET_KEY={secret}\n'
        'AI_SAFE_HTTPS=0\n'
    )
    ENV_FILE.write_text(env, encoding='utf-8')
    print('\nSaved email settings to .env')
    print('Your Gmail App Password is stored only on this computer.')
    print('You can now start AI-SAFE with START_AI_SAFE.bat.\n')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
