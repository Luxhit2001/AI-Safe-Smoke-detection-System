@echo off
setlocal
cd /d "%~dp0"

echo.
echo ========================================
echo        AI-SAFE STARTUP
 echo ========================================
echo.

if not exist ".env" (
    echo First-time setup: Gmail OTP settings are needed.
    echo.
    python setup_email.py
    if errorlevel 1 (
        echo.
        echo Setup was not completed.
        pause
        exit /b 1
    )
)

echo Checking required packages...
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo Could not install the required packages.
    pause
    exit /b 1
)

echo.
echo Loading bundled air-quality datasets...
python import_air_quality.py
if errorlevel 1 (
    echo.
echo Dataset import failed. The dashboard may start without dataset analytics.
    echo.
)

echo Starting AI-SAFE...
echo Open http://127.0.0.1:5000 in your browser.
echo Press CTRL+C in this window to stop AI-SAFE.
echo.
python app.py
pause
