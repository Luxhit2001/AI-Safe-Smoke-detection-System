# AI-SAFE Live Smoke Reading Update

This build is configured for the uploaded `smoke_monitor_advanced` Arduino sketch.

## What changed

- Old demo smoke history is removed once when this updated build starts.
- Old demo notifications are removed and are no longer seeded.
- The smoke chart no longer creates fake/demo values when Arduino is offline.
- Arduino readings are read automatically from USB serial at 9600 baud.
- Expected serial format: `millis,smoothed_smoke_value,SAFE|WARNING|CRITICAL`.
- Every valid reading is stored in SQLite as `data_source = live`.
- The dashboard reloads stored live smoke readings through `/api/smoke-history`.
- Warning/Critical notifications are generated automatically from the Arduino state.
- Rapid smoke increases also create a notification.
- Duplicate graph points are prevented when the browser polls faster than Arduino sends readings.

## Run

1. Upload `hardware/smoke_monitor_advanced_AI_SAFE.ino` to Arduino Uno.
2. Connect Arduino to the PC by USB.
3. Set `ARDUINO_PORT` in `.env` if your board is not on COM3. Example: `ARDUINO_PORT=COM5`.
4. Keep `ARDUINO_BAUD=9600`.
5. Install requirements: `pip install -r requirements.txt`.
6. Run: `python app.py`.
7. Open `http://127.0.0.1:5000`.

After connection, new smoke readings and notifications appear automatically. No manual data entry is required.


## Automatic Arduino USB detection
The live reader now defaults to `ARDUINO_PORT=AUTO`. It detects common Arduino Uno, CH340/WCH, USB-Serial and FTDI ports automatically. If you know the exact port, set `ARDUINO_PORT=COM5` (for example). The baud rate remains 9600.
