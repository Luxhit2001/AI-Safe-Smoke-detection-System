# AI-SAFE Firebase FCM Integration

## Data flow

MQ-135 → Arduino Uno → USB Serial → Flask `app.py` → AI-SAFE alert engine → SQLite Notification Center + Firebase FCM → browser/mobile push

Arduino does not connect directly to Firebase.

## Setup

1. Copy `.env.example` to `.env`.
2. Keep the Firebase web values and VAPID public key in `.env`.
3. In Firebase Console, create/download the Firebase Admin service-account JSON. Keep it private.
4. Put that JSON outside source control and set `FIREBASE_SERVICE_ACCOUNT` to its local path.
5. Run `pip install -r requirements.txt`.
6. Start `python app.py`.
7. Log in, open **Settings**, and click **Enable notifications**.
8. Allow browser notifications. The browser registers its Firebase Installation ID with Flask.
9. Test with a real Arduino reading. A threshold-crossing alert is stored in the Notification Center and sent through FCM.

## Thresholds

The existing AI-SAFE alert engine remains the source of truth: warning 500 and critical 700 by default. The server does not send a push for every reading; it uses the existing state-change/cooldown logic.

## HTTPS

FCM web push requires a secure context for deployed sites. Localhost is suitable for development in browsers that treat it as a trustworthy origin; a phone accessing the Flask app over a plain LAN HTTP address should be moved to an HTTPS deployment for reliable web push.

## Security

The Firebase web API key and VAPID public key are client-side values. The Firebase Admin service-account JSON/private key is server-only and must never be uploaded to the browser or committed to Git.
