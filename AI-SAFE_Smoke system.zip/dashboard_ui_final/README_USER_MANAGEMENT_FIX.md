# User Management / Database Initialization

The packaged project intentionally does not include the old SQLite database.
On first startup, `app.py` runs `init_db()` and creates `instance/ai_safe.db`, including the `stations` and `users` tables and the default Admin account.

Demo Admin:
- Username: `admin`
- Password: `admin123`

To test user creation:
1. Start with `python app.py`.
2. Log in as Admin.
3. Open **User Management**.
4. Create a user and assign a station.
5. Refresh User Management to confirm the user remains listed.
6. Restart the application and confirm the user is still present.
7. Log out and sign in using the new account.

Do not delete `instance/ai_safe.db` after creating users if you want the accounts to persist. Back up the database before deployment.
