from flask import Flask, render_template, request, redirect, url_for, session, jsonify, Response, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path
from datetime import datetime
import csv
import io
import os
import json
import random
import time
import shutil
import statistics
import secrets
import hashlib
import smtplib
import threading
import math

try:
    import cv2
except ImportError:
    cv2 = None

from email.message import EmailMessage

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None

BASE_DIR = Path(__file__).resolve().parent

def _load_local_env():
    """Load AI-SAFE's private .env file without requiring an extra package."""
    env_file = BASE_DIR / ".env"
    if not env_file.exists():
        return
    try:
        for raw in env_file.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key, value = key.strip(), value.strip()
            if key and key not in os.environ:
                os.environ[key] = value
    except OSError:
        pass

_load_local_env()

INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(exist_ok=True)
DATABASE = INSTANCE_DIR / "ai_safe.db"

app = Flask(__name__)
app.secret_key = os.environ.get("AI_SAFE_SECRET_KEY", secrets.token_hex(32))
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("AI_SAFE_HTTPS", "0") == "1",
)

SMTP_HOST = os.environ.get("AI_SAFE_SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("AI_SAFE_SMTP_PORT", "587"))
SMTP_USER = os.environ.get("AI_SAFE_GMAIL_ADDRESS", "").strip()
SMTP_PASSWORD = os.environ.get("AI_SAFE_GMAIL_APP_PASSWORD", "").replace(" ", "").strip()
OTP_TTL_SECONDS = 300
OTP_RESEND_SECONDS = 60
OTP_MAX_ATTEMPTS = 5


DEFAULT_ADMIN_USERNAME = "admin"
# No hard-coded administrator password. On first run, set AI_SAFE_ADMIN_PASSWORD
# or AI-SAFE generates a one-time bootstrap password in instance/ADMIN_CREDENTIALS.txt.
DEFAULT_ADMIN_PASSWORD = os.environ.get("AI_SAFE_ADMIN_PASSWORD", "admin123").strip()


LAST_NOTIFICATION_SENSOR_READING = None
LAST_NOTIFICATION_SENSOR_STATE = None
LAST_NOTIFICATION_AQI_BAND = None
EMERGENCY_DISPATCH_COOLDOWN_SECONDS = 600

LATEST_SENSOR = {
    "connected": False,
    "mode": "Waiting for Arduino",
    "mq135_raw": None,
    "gas_index": None,
    "temperature": None,
    "humidity": None,
    "updated_at": None,
    "message": "Connect Arduino by USB to start automatic smoke readings"
}

# Live Arduino serial reader state. The serial port is kept open so the dashboard
# does not repeatedly open/close COM3 and miss readings on Windows.
SERIAL_READER_STOP = threading.Event()
SERIAL_READER_THREAD = None
SERIAL_LOCK = threading.Lock()

# PC built-in camera / computer-vision state. The Arduino remains the sensor
# controller; OpenCV runs on the PC for live images and range estimation.
CAMERA_LOCK = threading.Lock()
CAMERA_CAPTURE = None
CAMERA_INDEX = int(os.environ.get("AI_SAFE_CAMERA_INDEX", "0"))
CAMERA_LAST_ERROR = ""
CAMERA_MARKER_SIZE_M = float(os.environ.get("AI_SAFE_RANGE_MARKER_SIZE_M", "0.10"))
CAMERA_MARKER_ID = int(os.environ.get("AI_SAFE_RANGE_MARKER_ID", "0"))
CAMERA_FOCAL_LENGTH_PX = float(os.environ.get("AI_SAFE_CAMERA_FOCAL_LENGTH_PX", "0"))

# Local OpenCV visual smoke/fire detection state. This is a vision-assisted
# heuristic, not a certified fire detector or a trained AI model. It is combined
# with the live MQ-135 reading before an AI-SAFE notification is created.
CAMERA_VISION_LOCK = threading.Lock()
CAMERA_VISION_STATE = {
    "status": "waiting",
    "smoke_detected": False,
    "fire_detected": False,
    "visual_alert": False,
    "confidence": 0.0,
    "smoke_score": 0.0,
    "fire_score": 0.0,
    "motion_score": 0.0,
    "message": "Start the camera to begin visual detection.",
    "updated_at": None,
    "last_alert_at": 0.0,
    "consecutive_frames": 0,
}
CAMERA_PREVIOUS_GRAY = None
CAMERA_VISION_MIN_FRAMES = int(os.environ.get("AI_SAFE_VISION_MIN_FRAMES", "4"))
CAMERA_FIRE_SCORE_THRESHOLD = float(os.environ.get("AI_SAFE_FIRE_SCORE_THRESHOLD", "0.008"))
CAMERA_SMOKE_SCORE_THRESHOLD = float(os.environ.get("AI_SAFE_SMOKE_SCORE_THRESHOLD", "0.018"))
CAMERA_MOTION_THRESHOLD = float(os.environ.get("AI_SAFE_VISION_MOTION_THRESHOLD", "0.010"))


def _camera_open():
    """Open the local PC webcam once and reuse it for the MJPEG stream."""
    global CAMERA_CAPTURE, CAMERA_LAST_ERROR
    if cv2 is None:
        CAMERA_LAST_ERROR = "OpenCV is not installed. Run pip install -r requirements.txt."
        return None
    with CAMERA_LOCK:
        if CAMERA_CAPTURE is not None and CAMERA_CAPTURE.isOpened():
            return CAMERA_CAPTURE
        try:
            cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            if not cap.isOpened():
                cap.release()
                CAMERA_CAPTURE = None
                CAMERA_LAST_ERROR = f"Could not open camera index {CAMERA_INDEX}."
                return None
            CAMERA_CAPTURE = cap
            CAMERA_LAST_ERROR = ""
            return CAMERA_CAPTURE
        except Exception as exc:
            CAMERA_CAPTURE = None
            CAMERA_LAST_ERROR = str(exc)[:240]
            return None


def _camera_frame():
    cap = _camera_open()
    if cap is None:
        return None
    with CAMERA_LOCK:
        ok, frame = cap.read()
    return frame if ok else None


def _range_from_frame(frame):
    """Estimate distance to an ArUco marker; requires a known marker size.

    A normal webcam has no depth sensor, so this is a calibrated/marker-based
    estimate rather than a claim of exact depth.
    """
    if cv2 is None or frame is None or not hasattr(cv2, "aruco"):
        return {"detected": False, "distance_m": None, "distance_cm": None, "marker_id": None, "message": "OpenCV ArUco support is unavailable."}
    try:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        aruco = cv2.aruco
        dictionary = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
        parameters = aruco.DetectorParameters() if hasattr(aruco, "DetectorParameters") else aruco.DetectorParameters_create()
        if hasattr(aruco, "ArucoDetector"):
            detector = aruco.ArucoDetector(dictionary, parameters)
            corners, ids, _ = detector.detectMarkers(gray)
        else:
            corners, ids, _ = aruco.detectMarkers(gray, dictionary, parameters=parameters)
        if ids is None:
            return {"detected": False, "distance_m": None, "distance_cm": None, "marker_id": None, "message": f"Show ArUco marker ID {CAMERA_MARKER_ID} to the camera."}
        marker_ids = [int(x[0]) for x in ids]
        if CAMERA_MARKER_ID not in marker_ids:
            return {"detected": False, "distance_m": None, "distance_cm": None, "marker_id": marker_ids[0] if marker_ids else None, "message": f"Marker detected, but ID {CAMERA_MARKER_ID} is required."}
        idx = marker_ids.index(CAMERA_MARKER_ID)
        pts = corners[idx][0]
        side_px = sum(((pts[(i+1)%4][0]-pts[i][0])**2 + (pts[(i+1)%4][1]-pts[i][1])**2)**0.5 for i in range(4)) / 4.0
        if side_px <= 1:
            return {"detected": False, "distance_m": None, "distance_cm": None, "marker_id": CAMERA_MARKER_ID, "message": "Marker is too small to estimate range."}
        focal_px = CAMERA_FOCAL_LENGTH_PX
        if focal_px <= 0:
            # Approximate initial focal length from a typical ~60° webcam horizontal FOV.
            focal_px = frame.shape[1] / (2.0 * __import__('math').tan(__import__('math').radians(60.0) / 2.0))
        distance_m = (focal_px * CAMERA_MARKER_SIZE_M) / side_px
        return {"detected": True, "distance_m": round(distance_m, 3), "distance_cm": round(distance_m*100, 1), "marker_id": CAMERA_MARKER_ID, "message": "Approximate marker distance."}
    except Exception as exc:
        return {"detected": False, "distance_m": None, "distance_cm": None, "marker_id": None, "message": str(exc)[:240]}


def _visual_detection(frame):
    """Detect smoke/fire-like visual patterns with OpenCV and combine with MQ-135.

    The method uses color, brightness, low-saturation smoke-like regions and
    temporal motion. It intentionally reports an approximate visual signal,
    not a medical/industrial/certified fire-safety determination.
    """
    global CAMERA_PREVIOUS_GRAY, CAMERA_VISION_STATE
    if cv2 is None or frame is None:
        return dict(CAMERA_VISION_STATE)
    try:
        # Work on a smaller frame for stable real-time processing.
        small = cv2.resize(frame, (640, 360), interpolation=cv2.INTER_AREA)
        hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        total = float(gray.shape[0] * gray.shape[1])

        # Fire-like pixels: red/orange/yellow, sufficiently saturated and bright.
        fire_mask = cv2.inRange(hsv, (0, 120, 150), (38, 255, 255))
        fire_score = float(cv2.countNonZero(fire_mask)) / total

        # Motion map helps distinguish smoke-like regions from a static grey wall.
        motion_score = 0.0
        motion_mask = None
        if CAMERA_PREVIOUS_GRAY is not None and CAMERA_PREVIOUS_GRAY.shape == gray.shape:
            diff = cv2.absdiff(gray, CAMERA_PREVIOUS_GRAY)
            motion_mask = cv2.threshold(diff, 18, 255, cv2.THRESH_BINARY)[1]
            motion_score = float(cv2.countNonZero(motion_mask)) / total
        CAMERA_PREVIOUS_GRAY = gray

        # Smoke-like regions: low saturation, mid/high brightness, with temporal motion.
        # Very dark pixels are excluded to reduce false positives from black objects.
        smoke_base = cv2.inRange(hsv, (0, 0, 55), (180, 95, 225))
        if motion_mask is not None:
            smoke_mask = cv2.bitwise_and(smoke_base, motion_mask)
        else:
            smoke_mask = smoke_base
        smoke_mask = cv2.morphologyEx(smoke_mask, cv2.MORPH_OPEN, None, iterations=1)
        smoke_score = float(cv2.countNonZero(smoke_mask)) / total

        fire_detected = fire_score >= CAMERA_FIRE_SCORE_THRESHOLD
        smoke_detected = (smoke_score >= CAMERA_SMOKE_SCORE_THRESHOLD and
                          motion_score >= CAMERA_MOTION_THRESHOLD)
        visual_candidate = fire_detected or smoke_detected

        with CAMERA_VISION_LOCK:
            previous_count = int(CAMERA_VISION_STATE.get("consecutive_frames", 0))
            consecutive = previous_count + 1 if visual_candidate else 0
            persistent = consecutive >= CAMERA_VISION_MIN_FRAMES
            if persistent:
                confidence = min(99.0, max(50.0, (fire_score / max(CAMERA_FIRE_SCORE_THRESHOLD, 1e-6) if fire_detected else smoke_score / max(CAMERA_SMOKE_SCORE_THRESHOLD, 1e-6)) * 55.0))
                status = "fire" if fire_detected else "smoke"
                message = "Visual fire-like pattern detected." if fire_detected else "Visual smoke-like movement detected."
            else:
                confidence = 0.0
                status = "analyzing" if visual_candidate else "clear"
                message = "Checking a possible visual signal…" if visual_candidate else "No persistent smoke/fire visual signal."
            CAMERA_VISION_STATE.update({
                "status": status,
                "smoke_detected": bool(smoke_detected and persistent),
                "fire_detected": bool(fire_detected and persistent),
                "visual_alert": bool(persistent),
                "confidence": round(confidence, 1),
                "smoke_score": round(smoke_score * 100.0, 2),
                "fire_score": round(fire_score * 100.0, 2),
                "motion_score": round(motion_score * 100.0, 2),
                "message": message,
                "updated_at": datetime.now().isoformat(timespec="seconds"),
                "consecutive_frames": consecutive,
            })
            result = dict(CAMERA_VISION_STATE)

        if persistent:
            _evaluate_camera_alert(result)
        return result
    except Exception as exc:
        with CAMERA_VISION_LOCK:
            CAMERA_VISION_STATE.update({
                "status": "error",
                "visual_alert": False,
                "message": str(exc)[:240],
                "updated_at": datetime.now().isoformat(timespec="seconds"),
            })
            return dict(CAMERA_VISION_STATE)


def _evaluate_camera_alert(vision):
    """Combine persistent camera detection with the latest MQ-135 reading.

    create_notification() is the single alert path, so the same event also
    reaches Firebase FCM when browser push is enabled.
    """
    now = time.time()
    with CAMERA_VISION_LOCK:
        last_alert = float(CAMERA_VISION_STATE.get("last_alert_at") or 0.0)
    cooldown = max(10, int(os.environ.get("AI_SAFE_CAMERA_ALERT_COOLDOWN", "60")))
    if now - last_alert < cooldown:
        return

    sensor = dict(LATEST_SENSOR)
    raw = sensor.get("mq135_raw")
    try:
        raw_value = float(raw) if raw is not None else None
    except (TypeError, ValueError):
        raw_value = None
    warning = float(sensor.get("warning_threshold") or 500)
    critical = float(sensor.get("critical_threshold") or 700)
    range_info = _range_from_frame(_camera_frame()) if CAMERA_CAPTURE is not None else {"detected": False}
    range_text = f" Approx. range: {range_info['distance_cm']:.1f} cm." if range_info.get("detected") else " Range reference not detected."
    camera_type = "FIRE" if vision.get("fire_detected") else "SMOKE"
    visual_text = f"Camera detected a persistent {camera_type.lower()}-like visual pattern (confidence {vision.get('confidence', 0):.0f}%)."

    if raw_value is not None and raw_value >= critical:
        title = "🚨 Camera + MQ-135 critical detection"
        severity = "Critical"
        message = f"{visual_text} MQ-135 = {raw_value:.0f}, in the critical range. {range_text}"
    elif raw_value is not None and raw_value >= warning:
        title = "⚠ Camera + MQ-135 warning"
        severity = "High"
        message = f"{visual_text} MQ-135 = {raw_value:.0f}, in the warning range. {range_text}"
    else:
        title = "👁 Camera visual smoke/fire detected"
        severity = "High" if vision.get("fire_detected") else "Medium"
        sensor_text = f" MQ-135 = {raw_value:.0f}." if raw_value is not None else " MQ-135 reading is not currently available."
        message = f"{visual_text}{sensor_text}{range_text} Verify the area safely; camera detection is an assistive signal."

    try:
        created = create_notification(
            "camera_visual_detection", title, message,
            "PC Camera + MQ-135", "Punjab Station 01", severity,
            bypass_quiet=False
        )
        if created:
            with CAMERA_VISION_LOCK:
                CAMERA_VISION_STATE["last_alert_at"] = now
    except Exception as exc:
        print(f"[AI-SAFE] Camera alert error: {exc}")


def _camera_release():
    global CAMERA_CAPTURE
    with CAMERA_LOCK:
        if CAMERA_CAPTURE is not None:
            try:
                CAMERA_CAPTURE.release()
            except Exception:
                pass
            CAMERA_CAPTURE = None




def _otp_hash(code):
    return hashlib.sha256((str(code) + app.secret_key).encode("utf-8")).hexdigest()


def _send_otp_email(to_email, code, purpose):
    if not SMTP_USER or not SMTP_PASSWORD:
        raise RuntimeError("Gmail SMTP is not configured. Set AI_SAFE_GMAIL_ADDRESS and AI_SAFE_GMAIL_APP_PASSWORD.")
    msg = EmailMessage()
    msg["Subject"] = f"AI-SAFE verification code ({purpose})"
    msg["From"] = SMTP_USER
    msg["To"] = to_email
    msg.set_content(
        f"AI-SAFE security verification\n\nYour one-time verification code is: {code}\n\n"
        f"This code expires in {OTP_TTL_SECONDS // 60} minutes. You have a limited number of attempts.\n"
        "If you did not request this, you can safely ignore this email.\n\nAI-SAFE Monitoring System"
    )
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)


def _new_otp():
    return f"{secrets.randbelow(1000000):06d}"


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    conn = get_db()
    row = conn.execute("""
        SELECT u.id, u.username, u.name, u.role, u.station_id,
               s.station_name, s.latitude, s.longitude, s.status,
               s.current_aqi, s.current_pm25, s.current_pm10, s.current_co,
               s.current_no2, s.current_smoke, s.updated_at AS station_updated_at
        FROM users u LEFT JOIN stations s ON s.id=u.station_id WHERE u.id=?
    """, (user_id,)).fetchone()
    conn.close()
    return row_to_dict(row)

def is_admin():
    return (session.get("role") or "").lower() == "admin"

def can_manage_users():
    return (session.get("role") or "").lower() in {"admin", "supervisor"}

def allowed_station_ids():
    if is_admin():
        return None
    user = current_user()
    return [int(user["station_id"])] if user and user.get("station_id") else []

def station_filter_sql(alias="i"):
    ids = allowed_station_ids()
    if ids is None:
        return "", []
    return f" AND {alias}.station_id IN ({','.join('?' for _ in ids)})", ids


def get_notification_settings():
    conn = get_db()
    row = conn.execute("SELECT * FROM notification_settings WHERE id = 1").fetchone()
    conn.close()
    return row_to_dict(row) or {
        "critical_smoke": 1, "high_smoke": 1, "arduino_disconnected": 1,
        "sensor_failure": 1, "rapid_smoke_increase": 1, "aqi_warning": 1,
        "smoke_warning": 500, "smoke_critical": 700,
        "aqi_warning_threshold": 101, "quiet_hours": 0,
        "quiet_start": "22:00", "quiet_end": "06:00", "cooldown_seconds": 300
    }


def in_quiet_hours(settings):
    if not settings.get("quiet_hours"):
        return False
    now = datetime.now().strftime("%H:%M")
    start, end = settings.get("quiet_start", "22:00"), settings.get("quiet_end", "06:00")
    return now >= start or now < end if start > end else start <= now < end


# -----------------------------------------------------------------------------
# Firebase Cloud Messaging (FCM)
# Arduino never talks directly to Firebase. Flask receives the Arduino reading,
# creates the normal AI-SAFE notification, then sends that same alert to the
# registered browser installations through Firebase FCM.
# -----------------------------------------------------------------------------
FIREBASE_APP = None
FIREBASE_INIT_ERROR = None


def _get_firebase_messaging():
    """Return Firebase Admin Messaging, or None when FCM is not configured."""
    global FIREBASE_APP, FIREBASE_INIT_ERROR
    if FIREBASE_APP is not None:
        from firebase_admin import messaging
        return messaging
    if FIREBASE_INIT_ERROR is not None:
        return None
    try:
        import firebase_admin
        from firebase_admin import credentials, messaging

        service_account = os.environ.get("FIREBASE_SERVICE_ACCOUNT", "").strip()
        google_credentials = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "").strip()
        credential_path = service_account or google_credentials

        if credential_path:
            path = Path(credential_path)
            if not path.is_absolute():
                path = BASE_DIR / path
            if not path.exists():
                raise FileNotFoundError(f"Firebase service-account file not found: {path}")
            cred = credentials.Certificate(str(path))
            FIREBASE_APP = firebase_admin.initialize_app(cred)
        else:
            # Application Default Credentials can be supplied by the environment.
            FIREBASE_APP = firebase_admin.initialize_app()
        return messaging
    except Exception as exc:
        FIREBASE_INIT_ERROR = str(exc)
        print(f"[AI-SAFE] Firebase FCM disabled: {exc}")
        return None


def send_fcm_notification(notification_row):
    """Send an AI-SAFE notification to registered FCM browser installations.

    Devices with station_id NULL are treated as admin/all-station devices.
    Normal users are registered against their assigned station only.
    """
    messaging = _get_firebase_messaging()
    if messaging is None or not notification_row:
        return {"sent": 0, "failed": 0, "reason": "FCM not configured"}

    station_name = str(notification_row.get("location") or "").strip()
    station_id = None
    conn = get_db()
    try:
        if station_name:
            row = conn.execute("SELECT id FROM stations WHERE station_name=?", (station_name,)).fetchone()
            station_id = int(row["id"]) if row else None
        if station_id is None:
            devices = conn.execute("SELECT id, installation_id FROM fcm_devices WHERE station_id IS NULL").fetchall()
        else:
            devices = conn.execute(
                "SELECT id, installation_id FROM fcm_devices WHERE station_id=? OR station_id IS NULL",
                (station_id,)
            ).fetchall()
    finally:
        conn.close()

    sent = failed = 0
    stale_ids = []
    for device in devices:
        fid = str(device["installation_id"] or "").strip()
        if not fid:
            continue
        try:
            data = {
                "notification_id": str(notification_row.get("id") or ""),
                "notification_type": str(notification_row.get("notification_type") or ""),
                "severity": str(notification_row.get("severity") or "Medium"),
                "sensor": str(notification_row.get("sensor") or ""),
                "location": station_name,
                "incident_id": str(notification_row.get("incident_id") or ""),
                "smoke": str(notification_row.get("smoke") or ""),
            }
            message = messaging.Message(
                notification=messaging.Notification(
                    title=str(notification_row.get("title") or "AI-SAFE Alert"),
                    body=str(notification_row.get("message") or "New AI-SAFE safety alert."),
                ),
                data=data,
                fid=fid,
            )
            messaging.send(message)
            sent += 1
            now = datetime.now().isoformat(timespec="seconds")
            conn = get_db()
            try:
                conn.execute("UPDATE fcm_devices SET last_seen=? WHERE id=?", (now, device["id"]))
                conn.commit()
            finally:
                conn.close()
        except Exception as exc:
            failed += 1
            error_text = str(exc).lower()
            if "unregistered" in error_text or "registration-token-not-registered" in error_text or "not found" in error_text:
                stale_ids.append(int(device["id"]))
            print(f"[AI-SAFE] FCM send failed for device {device['id']}: {exc}")

    if stale_ids:
        conn = get_db()
        try:
            conn.executemany("DELETE FROM fcm_devices WHERE id=?", [(x,) for x in stale_ids])
            conn.commit()
        finally:
            conn.close()
    return {"sent": sent, "failed": failed}


def create_notification(notification_type, title, message, sensor="", location="",
                        severity="Medium", incident_id=None, bypass_quiet=False):
    settings = get_notification_settings()
    if not bypass_quiet and in_quiet_hours(settings):
        return None
    cooldown = int(settings.get("cooldown_seconds") or 300)
    conn = get_db()
    recent = conn.execute(
        """SELECT id FROM notifications
           WHERE notification_type = ? AND created_at >= ?
           ORDER BY id DESC LIMIT 1""",
        (notification_type, datetime.fromtimestamp(time.time() - cooldown).isoformat(timespec="seconds"))
    ).fetchone()
    if recent:
        conn.close()
        return None
    now = datetime.now().isoformat(timespec="seconds")
    cur = conn.execute(
        """INSERT INTO notifications
           (notification_type,title,message,sensor,location,incident_id,severity,created_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (notification_type, title, message, sensor, location, incident_id, severity, now)
    )
    conn.commit()
    row = conn.execute("SELECT * FROM notifications WHERE id = ?", (cur.lastrowid,)).fetchone()
    conn.close()
    result = row_to_dict(row)
    # Push the same alert that appears in the AI-SAFE Notification Center.
    # FCM failures never block the dashboard/database alert.
    try:
        send_fcm_notification(result)
    except Exception as exc:
        print(f"[AI-SAFE] FCM notification error: {exc}")
    return result


def get_emergency_settings():
    conn = get_db()
    row = conn.execute("SELECT * FROM emergency_settings WHERE id = 1").fetchone()
    conn.close()
    return row_to_dict(row) or {
        "auto_dispatch": 1,
        "fire_department": 1,
        "ambulance": 1,
        "hazmat": 1,
        "police_control": 0,
        "fire_contact": "Fire & Rescue Control Room",
        "ambulance_contact": "Emergency Ambulance Control",
        "hazmat_contact": "HazMat / Disaster Response Control",
        "police_contact": "Police Control Room"
    }


def get_precautions_for_event(event_type, severity="Critical"):
    event = (event_type or "").lower()
    if "smoke" in event or "fire" in event:
        return [
            "Evacuate the affected area and move upwind if possible.",
            "Do not enter smoke-filled rooms or use lifts during a fire emergency.",
            "Keep away from electrical panels, fuel, cylinders and other ignition sources.",
            "Call trained fire/rescue personnel and follow the site's emergency plan.",
            "If smoke is heavy, cover your nose and mouth with a clean cloth and stay low while exiting."
        ]
    if "gas" in event or "chemical" in event or "hazmat" in event:
        return [
            "Do not touch, spill, smell or attempt to identify an unknown substance.",
            "Move people away from the area and stay upwind/uphill where practical.",
            "Avoid flames, sparks, switches and vehicle engines near a suspected leak.",
            "Isolate the area and wait for trained HazMat personnel.",
            "Do not re-enter until authorities declare the area safe."
        ]
    if "sensor" in event or "arduino" in event:
        return [
            "Treat missing sensor data as an unknown-risk condition until verified.",
            "Check the Arduino, MQ-135 wiring and power supply safely.",
            "Do not rely on a normal reading while the sensor is offline.",
            "Use manual site inspection and the emergency plan if smoke or gas is suspected."
        ]
    if "aqi" in event or "air" in event:
        return [
            "Avoid unnecessary outdoor exposure while air quality is hazardous.",
            "Move vulnerable people indoors and close doors/windows where appropriate.",
            "Avoid smoke, dust, combustion sources and strenuous outdoor activity.",
            "Wait for the air-quality warning to clear before normal outdoor activity."
        ]
    return [
        "Keep people away from the affected sensor/location.",
        "Do not approach an unknown hazard without trained personnel.",
        "Follow the site's emergency response procedure and authority instructions."
    ]


def build_emergency_message(event_type, severity, smoke=0, aqi=0, location="Punjab Station 01"):
    event = event_type.replace("_", " ").title()
    return (f"AI-SAFE EMERGENCY ALERT: {severity.upper()} {event} detected at {location}. "
            f"Smoke level: {float(smoke or 0):.0f}; AQI: {float(aqi or 0):.0f}. "
            "Keep people away from the affected area, avoid smoke/gas/unknown hazardous material, "
            "and dispatch trained emergency personnel. Follow local emergency procedures.")


def create_emergency_dispatch(event_type, severity="Critical", smoke=0, aqi=0,
                              location="Punjab Station 01", sensor="MQ-135", station_id=None):
    settings = get_emergency_settings()
    if not settings.get("auto_dispatch") or severity.lower() not in {"critical", "high"}:
        return []
    if station_id is None:
        user = current_user()
        if user and user.get("station_id"):
            station_id = int(user["station_id"])
        else:
            conn0 = get_db()
            st = conn0.execute("SELECT id FROM stations WHERE station_name=?", (location,)).fetchone()
            conn0.close()
            station_id = int(st["id"]) if st else None
    now = datetime.now()
    cutoff = datetime.fromtimestamp(time.time() - EMERGENCY_DISPATCH_COOLDOWN_SECONDS).isoformat(timespec="seconds")
    conn = get_db()
    recent = conn.execute(
        "SELECT id FROM emergency_dispatches WHERE event_type = ? AND station_id IS ? AND created_at >= ? ORDER BY id DESC LIMIT 1",
        (event_type, station_id, cutoff)
    ).fetchone()
    if recent:
        conn.close()
        return []

    targets = []
    for key, label, contact in [
        ("fire_department", "🔥 Fire & Rescue", settings.get("fire_contact")),
        ("ambulance", "🚑 Ambulance / Medical", settings.get("ambulance_contact")),
        ("hazmat", "☣ HazMat / Disaster Response", settings.get("hazmat_contact")),
        ("police_control", "🚓 Police Control", settings.get("police_contact")),
    ]:
        if settings.get(key):
            targets.append((key, label, contact or label))

    message = build_emergency_message(event_type, severity, smoke, aqi, location)
    created = now.isoformat(timespec="seconds")
    for target_key, target_label, recipient in targets:
        conn.execute(
            """INSERT INTO emergency_dispatches
               (event_type,severity,location,sensor,recipient_type,recipient,message,status,created_at,station_id)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (event_type, severity, location, sensor, target_key, recipient, message, "Queued (Demo)", created, station_id)
        )
    conn.commit()
    rows = conn.execute(
        "SELECT * FROM emergency_dispatches WHERE created_at = ? AND station_id IS ? ORDER BY id DESC", (created, station_id)
    ).fetchall()
    conn.close()
    if targets:
        create_notification(
            "emergency_dispatch", "🚨 Emergency response initiated",
            f"Automatic emergency messages queued for {len(targets)} response agencies at {location}.",
            sensor, location, severity, bypass_quiet=True
        )
    return [row_to_dict(r) for r in rows]


def maybe_emergency_dispatch(event_type, severity="Critical", smoke=0, aqi=0,
                             location="Punjab Station 01", sensor="MQ-135"):
    try:
        return create_emergency_dispatch(event_type, severity, smoke, aqi, location, sensor)
    except sqlite3.Error:
        return []


def evaluate_sensor_notifications(reading):
    """Create LIVE notifications from the actual MQ-135 Arduino stream.

    The uploaded smoke-monitor sketch sends: millis,smoothed_value,SAFE|WARNING|CRITICAL.
    Board state is preferred so the dashboard alert matches the LCD/LED/buzzer state.
    Configured 500/700 thresholds are used only as a fallback for sketches without a state.
    """
    global LAST_NOTIFICATION_SENSOR_READING, LAST_NOTIFICATION_SENSOR_STATE
    settings = get_notification_settings()
    station_name = reading.get("station_name") or "Punjab Station 01"
    raw = reading.get("mq135_raw")

    if reading.get("connected") is False:
        if settings.get("arduino_disconnected"):
            create_notification(
                "arduino_disconnected", "🔌 Arduino disconnected",
                "AI-SAFE cannot read the Arduino sensor. Check the USB connection.",
                "Arduino UNO", station_name, "High"
            )
        LAST_NOTIFICATION_SENSOR_STATE = "OFFLINE"
        return

    if raw is None:
        if settings.get("sensor_failure"):
            create_notification(
                "sensor_failure", "⚠ Sensor failure",
                "The MQ-135 smoke sensor returned no usable reading.",
                "MQ-135", station_name, "High"
            )
        return

    raw = float(raw)
    board_state = str(reading.get("state") or "").upper()
    if board_state not in {"SAFE", "WARNING", "CRITICAL"}:
        if raw >= float(settings.get("smoke_critical") or 700):
            board_state = "CRITICAL"
        elif raw >= float(settings.get("smoke_warning") or 500):
            board_state = "WARNING"
        else:
            board_state = "SAFE"

    # Only create a level notification when the actual smoke state changes.
    # This prevents one notification every second while the sensor remains in the same state.
    if board_state != LAST_NOTIFICATION_SENSOR_STATE:
        if board_state == "CRITICAL" and settings.get("critical_smoke"):
            create_notification(
                "critical_smoke", "🚨 Critical smoke detected",
                f"Live MQ-135 reading is {raw:.0f} and the Arduino state is CRITICAL at {station_name}.",
                "MQ-135", station_name, "Critical"
            )
            maybe_emergency_dispatch("critical smoke", "Critical", raw, 0, station_name, "MQ-135")
        elif board_state == "WARNING" and settings.get("high_smoke"):
            create_notification(
                "high_smoke", "🔥 Smoke warning detected",
                f"Live MQ-135 reading is {raw:.0f} and the Arduino state is WARNING at {station_name}.",
                "MQ-135", station_name, "High"
            )

    if LAST_NOTIFICATION_SENSOR_READING is not None:
        previous = float(LAST_NOTIFICATION_SENSOR_READING)
        if raw - previous >= 100 and settings.get("rapid_smoke_increase"):
            create_notification(
                "rapid_smoke_increase", "📈 Smoke level rising quickly",
                f"Live MQ-135 smoke increased by {raw - previous:.0f} points ({previous:.0f} → {raw:.0f}) at {station_name}.",
                "MQ-135", station_name, "High"
            )

    LAST_NOTIFICATION_SENSOR_READING = raw
    LAST_NOTIFICATION_SENSOR_STATE = board_state


def aqi_band(aqi):
    """AI-SAFE AQI bands used consistently by live readings and the dashboard."""
    value = float(aqi or 0)
    if value <= 50:
        return "good", "Good", "Normal"
    if value <= 100:
        return "satisfactory", "Satisfactory/Moderate", "Normal"
    if value <= 200:
        return "moderate_poor", "Moderate/Poor", "Warning"
    if value <= 300:
        return "poor", "Poor", "High"
    if value <= 400:
        return "very_poor", "Very Poor", "Critical"
    return "severe", "Severe", "Critical"


def aqi_from_mq135(raw):
    """Convert the Arduino MQ-135 10-bit index to the project's 0-500 AQI display scale.

    This is a project-level normalized index, not a regulatory AQI calculation.
    A calibrated gas/AQI model can replace this function later.
    """
    return max(0.0, min(500.0, float(raw or 0) * 500.0 / 1023.0))


def evaluate_aqi_notification(aqi, station_name=None):
    global LAST_NOTIFICATION_AQI_BAND
    settings = get_notification_settings()
    station_name = station_name or "Punjab Station 01"
    if aqi is None:
        return
    band, label, severity = aqi_band(aqi)
    # Generate an AQI notification only when entering a new alert band.
    # This prevents repeated notifications every second for an unchanged value.
    if band == LAST_NOTIFICATION_AQI_BAND:
        return
    LAST_NOTIFICATION_AQI_BAND = band
    if severity == "Normal":
        return
    if not settings.get("aqi_warning"):
        return
    value = float(aqi)
    if band == "moderate_poor":
        title = "⚠️ AQI warning"
        message = f"Live AQI is {value:.0f} ({label}) at {station_name}. Monitor air quality and smoke levels."
    elif band == "poor":
        title = "🔴 Poor air quality alert"
        message = f"Live AQI is {value:.0f} ({label}) at {station_name}. Health effects are possible; check the affected area."
    elif band == "very_poor":
        title = "🚨 Critical AQI alert"
        message = f"Live AQI is {value:.0f} ({label}) at {station_name}. Significant health risk detected."
    else:
        title = "🛑 Severe AQI alert"
        message = f"Live AQI is {value:.0f} ({label}) at {station_name}. Serious health effects are possible."
    create_notification("aqi_warning", title, message, "MQ-135 / AQI", station_name, severity)
    if severity == "Critical":
        maybe_emergency_dispatch("hazardous air quality", "Critical", 0, value, station_name, "MQ-135 / AQI")


def classify_sensor_level(gas_index):
    if gas_index is None:
        return "Unknown"
    if gas_index < 25:
        return "Good"
    if gas_index < 50:
        return "Moderate"
    if gas_index < 75:
        return "High"
    return "Critical"


def _parse_arduino_line(line):
    """Accept the new JSON protocol and the older CSV protocol."""
    line = (line or "").strip()
    if not line:
        return None
    try:
        payload = json.loads(line)
        raw = payload.get("mq135", payload.get("mq135_raw", payload.get("raw")))
        if raw is None:
            return None
        return {
            "mq135_raw": round(max(0, min(1023, float(raw))), 1),
            "baseline": payload.get("baseline"),
            "warning_threshold": payload.get("warning_threshold"),
            "critical_threshold": payload.get("critical_threshold"),
            "state": str(payload.get("state", "")).upper() or None,
            "uptime_ms": payload.get("uptime_ms")
        }
    except (ValueError, TypeError, json.JSONDecodeError):
        # Legacy advanced sketch: millis,smoothed,state
        parts = [x.strip() for x in line.split(",")]
        if len(parts) >= 3:
            try:
                return {
                    "mq135_raw": round(max(0, min(1023, float(parts[1]))), 1),
                    "state": parts[2].upper()
                }
            except ValueError:
                return None
    return None


def _store_live_sensor(reading):
    """Persist the latest Arduino reading as live data for the station."""
    station_id = int(os.getenv("ARDUINO_STATION_ID", "1"))
    now = datetime.now().isoformat(timespec="seconds")
    raw = float(reading["mq135_raw"])
    conn = get_db()
    aqi = aqi_from_mq135(raw)
    band, label, _severity = aqi_band(aqi)
    conn.execute(
        "UPDATE stations SET current_aqi=?, current_smoke=?, status=?, updated_at=? WHERE id=?",
        (aqi, raw, reading.get("state") or classify_sensor_level(round(raw / 1023 * 100, 1)), now, station_id)
    )
    conn.execute(
        """INSERT INTO sensor_data
           (station_id,aqi,pm25,pm10,co,no2,smoke,recorded_at,data_source)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (station_id, aqi, 0, 0, 0, 0, raw, now, "live")
    )
    reading["aqi"] = aqi
    reading["aqi_label"] = label
    reading["aqi_band"] = band
    evaluate_aqi_notification(aqi, station_name=reading.get("station_name") or "Punjab Station 01")
    conn.commit()
    conn.close()


def _arduino_port_candidates():
    """Return likely Arduino serial ports, preferring ARDUINO_PORT when set.
    AUTO mode detects common Arduino/CH340/USB-serial boards without requiring
    the user to edit COM3/COM4 manually.
    """
    configured = os.getenv("ARDUINO_PORT", "AUTO").strip()
    candidates = []
    if configured and configured.upper() != "AUTO":
        candidates.append(configured)
    if list_ports is None:
        return candidates
    try:
        ports = list(list_ports.comports())
    except Exception:
        return candidates
    preferred = []
    others = []
    keywords = ("arduino", "uno", "ch340", "wch", "usb serial", "usb-serial", "usb to uart", "ftdi")
    for p in ports:
        text = " ".join(str(x or "") for x in (p.device, p.description, p.manufacturer, p.hwid)).lower()
        if p.device in candidates:
            continue
        if any(k in text for k in keywords):
            preferred.append(p.device)
        else:
            others.append(p.device)
    return candidates + preferred + others


def _serial_reader_loop():
    global LATEST_SENSOR, LAST_NOTIFICATION_SENSOR_READING
    baud = int(os.getenv("ARDUINO_BAUD", "9600"))

    if serial is None:
        with SERIAL_LOCK:
            LATEST_SENSOR.update({
                "connected": False, "mode": "Offline",
                "message": "pyserial is not installed"
            })
        return

    while not SERIAL_READER_STOP.is_set():
        ser = None
        connected_port = None
        try:
            candidates = _arduino_port_candidates()
            if not candidates:
                raise RuntimeError("No USB serial ports detected. Connect Arduino by USB.")
            last_error = None
            for candidate in candidates:
                try:
                    test_ser = serial.Serial(candidate, baud, timeout=1)
                    test_ser.reset_input_buffer()
                    ser = test_ser
                    connected_port = candidate
                    break
                except Exception as exc:
                    last_error = exc
            if ser is None:
                raise RuntimeError(f"No Arduino serial port available ({last_error})")
            port = connected_port
            ser.reset_input_buffer()
            with SERIAL_LOCK:
                LATEST_SENSOR.update({
                    "connected": True,
                    "mode": "Arduino USB / LIVE",
                    "message": f"Connected to Arduino on {port}"
                })

            while not SERIAL_READER_STOP.is_set():
                raw_line = ser.readline().decode("utf-8", errors="ignore").strip()
                parsed = _parse_arduino_line(raw_line)
                if not parsed:
                    continue

                raw = parsed["mq135_raw"]
                gas_index = round(raw / 1023 * 100, 1)
                state_from_board = parsed.get("state")
                if state_from_board in {"SAFE", "WARNING", "CRITICAL"}:
                    level = state_from_board.title()
                else:
                    level = classify_sensor_level(gas_index)

                reading = {
                    "connected": True,
                    "mode": "Arduino USB / LIVE",
                    "mq135_raw": raw,
                    "gas_index": gas_index,
                    "temperature": parsed.get("temperature"),
                    "humidity": parsed.get("humidity"),
                    "baseline": parsed.get("baseline"),
                    "warning_threshold": parsed.get("warning_threshold") or 500,
                    "critical_threshold": parsed.get("critical_threshold") or 700,
                    "state": state_from_board or level.upper(),
                    "level": level,
                    "uptime_ms": parsed.get("uptime_ms"),
                    "updated_at": datetime.now().isoformat(timespec="seconds"),
                    "message": f"Live Arduino reading received from {port}",
                    "station_name": "Punjab Station 01",
                    "station_id": int(os.getenv("ARDUINO_STATION_ID", "1"))
                }

                with SERIAL_LOCK:
                    LATEST_SENSOR = reading

                # Notifications and database persistence happen for every valid reading.
                try:
                    evaluate_sensor_notifications(reading)
                    _store_live_sensor(reading)
                except Exception as exc:
                    with SERIAL_LOCK:
                        LATEST_SENSOR["message"] = f"Reading received; storage/alert error: {exc}"

        except Exception as exc:
            was_connected = bool(LATEST_SENSOR.get("connected"))
            with SERIAL_LOCK:
                LATEST_SENSOR.update({
                    "connected": False,
                    "mode": "Offline",
                    "message": f"Waiting for Arduino; auto-detecting USB serial port (9600 baud)",
                    "error": str(exc)
                })
            # A real disconnect is treated as a safety event. The normal notification
            # cooldown prevents a new push on every serial retry.
            if was_connected:
                try:
                    evaluate_sensor_notifications({
                        "connected": False,
                        "station_name": "Punjab Station 01",
                        "station_id": int(os.getenv("ARDUINO_STATION_ID", "1"))
                    })
                except Exception as notify_exc:
                    print(f"[AI-SAFE] Disconnect alert error: {notify_exc}")
            time.sleep(1.5)
        finally:
            try:
                if ser:
                    ser.close()
            except Exception:
                pass


def start_serial_reader():
    global SERIAL_READER_THREAD
    if SERIAL_READER_THREAD and SERIAL_READER_THREAD.is_alive():
        return
    SERIAL_READER_STOP.clear()
    SERIAL_READER_THREAD = threading.Thread(
        target=_serial_reader_loop, name="AI-SAFE-Arduino-Reader", daemon=True
    )
    SERIAL_READER_THREAD.start()


def stop_serial_reader():
    SERIAL_READER_STOP.set()


def read_arduino_sensor():
    """Return the latest reading collected by the background serial reader."""
    with SERIAL_LOCK:
        return dict(LATEST_SENSOR)

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()

    conn.execute("""CREATE TABLE IF NOT EXISTS stations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_name TEXT NOT NULL UNIQUE,
        latitude REAL NOT NULL, longitude REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'Normal',
        current_aqi REAL NOT NULL DEFAULT 0, current_pm25 REAL NOT NULL DEFAULT 0,
        current_pm10 REAL NOT NULL DEFAULT 0, current_co REAL NOT NULL DEFAULT 0,
        current_no2 REAL NOT NULL DEFAULT 0, current_smoke REAL NOT NULL DEFAULT 0,
        updated_at TEXT NOT NULL
    )""")
    station_seed = [
        ("Punjab Station 01",30.3398,76.3869,"Normal",72,28,46,0.7,21,120),
        ("Punjab Station 02",31.3260,75.5762,"Warning",126,61,102,1.4,38,360),
        ("Punjab Station 03",30.9010,75.8573,"Critical",248,132,176,2.1,67,760),
        ("Punjab Station 04",31.6340,74.8723,"Normal",58,23,39,0.5,18,95),
        ("Punjab Station 05",30.7046,76.7179,"Warning",154,79,118,1.6,42,470)]
    now_seed=datetime.now().isoformat(timespec="seconds")
    for row in station_seed:
        conn.execute("""INSERT OR IGNORE INTO stations
            (station_name,latitude,longitude,status,current_aqi,current_pm25,current_pm10,current_co,current_no2,current_smoke,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",row+(now_seed,))

    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL, name TEXT NOT NULL,
        email TEXT, email_verified INTEGER NOT NULL DEFAULT 0,
        role TEXT NOT NULL DEFAULT 'user', station_id INTEGER, created_at TEXT NOT NULL,
        FOREIGN KEY(station_id) REFERENCES stations(id)
    )""")
    for alter_sql in (
        "ALTER TABLE users ADD COLUMN email TEXT",
        "ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0",
    ):
        try:
            conn.execute(alter_sql)
        except sqlite3.OperationalError:
            pass

    conn.execute("""CREATE TABLE IF NOT EXISTS pending_registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
        otp_hash TEXT NOT NULL, expires_at REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
        last_sent_at REAL NOT NULL, created_at TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS login_otps (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, otp_hash TEXT NOT NULL,
        expires_at REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_sent_at REAL NOT NULL,
        created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_login_otps_user ON login_otps(user_id)")

    if not conn.execute("SELECT id FROM users WHERE username=?",(DEFAULT_ADMIN_USERNAME,)).fetchone():
        s1=conn.execute("SELECT id FROM stations WHERE station_name='Punjab Station 01'").fetchone()
        bootstrap_password = DEFAULT_ADMIN_PASSWORD or secrets.token_urlsafe(12)
        conn.execute("""INSERT INTO users(username,password_hash,name,email,email_verified,role,station_id,created_at)
                        VALUES(?,?,?,?,?,?,?,?)""",
                     (DEFAULT_ADMIN_USERNAME,generate_password_hash(bootstrap_password),
                      "System Administrator",os.environ.get("AI_SAFE_ADMIN_EMAIL", "").strip() or None,
                      1 if os.environ.get("AI_SAFE_ADMIN_EMAIL", "").strip() else 0,
                      "admin",s1["id"],now_seed))
        if not DEFAULT_ADMIN_PASSWORD:
            cred_file = INSTANCE_DIR / "ADMIN_CREDENTIALS.txt"
            if not cred_file.exists():
                cred_file.write_text(
                    "AI-SAFE first-run administrator credentials\n\n"
                    f"Username: {DEFAULT_ADMIN_USERNAME}\n"
                    f"Password: {bootstrap_password}\n\n"
                    "Change this password after first login.\n", encoding="utf-8")
            print(f"\nAI-SAFE first-run admin password: {bootstrap_password}")
    admin_email = os.environ.get("AI_SAFE_ADMIN_EMAIL", "").strip().lower()
    if admin_email:
        conn.execute("UPDATE users SET email=?, email_verified=1 WHERE username=? AND role='admin'", (admin_email, DEFAULT_ADMIN_USERNAME))
    conn.execute("CREATE INDEX IF NOT EXISTS idx_users_station ON users(station_id)")

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS incidents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_time TEXT NOT NULL,
            incident_type TEXT NOT NULL,
            sensor TEXT NOT NULL,
            severity TEXT NOT NULL,
            status TEXT NOT NULL,
            station_id INTEGER,
            smoke_level REAL NOT NULL DEFAULT 0,
            aqi REAL NOT NULL DEFAULT 0,
            temperature REAL NOT NULL DEFAULT 0,
            humidity REAL NOT NULL DEFAULT 0,
            latitude REAL,
            longitude REAL,
            description TEXT DEFAULT '',
            data_source TEXT NOT NULL DEFAULT 'live',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )

    try:
        conn.execute("ALTER TABLE incidents ADD COLUMN station_id INTEGER")
    except sqlite3.OperationalError:
        pass
    try:
        conn.execute("ALTER TABLE incidents ADD COLUMN data_source TEXT NOT NULL DEFAULT 'live'")
    except sqlite3.OperationalError:
        pass
    s1=conn.execute("SELECT id FROM stations WHERE station_name='Punjab Station 01'").fetchone()
    conn.execute("UPDATE incidents SET station_id=COALESCE(station_id,?) WHERE station_id IS NULL",(s1["id"],))
    conn.execute("CREATE INDEX IF NOT EXISTS idx_incidents_station ON incidents(station_id)")

    # Keep the dashboard safe to start even before import_air_quality.py is run.
    # The startup script imports the bundled CSV datasets, but these tables must
    # exist for a direct `python app.py` launch to avoid a 500 error.
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS air_quality (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT NOT NULL, row_number INTEGER NOT NULL,
            no2 REAL, co REAL, pm10 REAL, pm25 REAL,
            aqi_no2 REAL, aqi_co REAL, aqi_pm10 REAL, aqi_pm25 REAL,
            aqi_overall REAL, remarks TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_air_quality_source_id ON air_quality(source, id);
        CREATE INDEX IF NOT EXISTS idx_air_quality_source_row ON air_quality(source, row_number);
        CREATE TABLE IF NOT EXISTS air_quality_summary (
            source TEXT PRIMARY KEY, total_rows INTEGER NOT NULL,
            avg_no2 REAL, avg_co REAL, avg_pm10 REAL, avg_pm25 REAL,
            avg_aqi REAL, max_aqi REAL, min_aqi REAL,
            latest_no2 REAL, latest_co REAL, latest_pm10 REAL, latest_pm25 REAL,
            latest_aqi REAL, latest_remarks TEXT
        );
        CREATE TABLE IF NOT EXISTS air_quality_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, row_number INTEGER NOT NULL,
            no2 REAL, co REAL, pm10 REAL, pm25 REAL, aqi_overall REAL, remarks TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_air_samples_source_row ON air_quality_samples(source, row_number);
    """)
    conn.execute("""CREATE TABLE IF NOT EXISTS sensor_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT, station_id INTEGER NOT NULL,
        aqi REAL NOT NULL DEFAULT 0, pm25 REAL NOT NULL DEFAULT 0, pm10 REAL NOT NULL DEFAULT 0,
        co REAL NOT NULL DEFAULT 0, no2 REAL NOT NULL DEFAULT 0, smoke REAL NOT NULL DEFAULT 0,
        recorded_at TEXT NOT NULL, data_source TEXT NOT NULL DEFAULT 'live', FOREIGN KEY(station_id) REFERENCES stations(id)
    )""")
    try:
        conn.execute("ALTER TABLE sensor_data ADD COLUMN data_source TEXT NOT NULL DEFAULT 'live'")
    except sqlite3.OperationalError:
        pass
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sensor_data_station_time ON sensor_data(station_id,recorded_at DESC)")

    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS notification_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            critical_smoke INTEGER NOT NULL DEFAULT 1,
            high_smoke INTEGER NOT NULL DEFAULT 1,
            arduino_disconnected INTEGER NOT NULL DEFAULT 1,
            sensor_failure INTEGER NOT NULL DEFAULT 1,
            rapid_smoke_increase INTEGER NOT NULL DEFAULT 1,
            aqi_warning INTEGER NOT NULL DEFAULT 1,
            smoke_warning REAL NOT NULL DEFAULT 500,
            smoke_critical REAL NOT NULL DEFAULT 700,
            aqi_warning_threshold REAL NOT NULL DEFAULT 101,
            quiet_hours INTEGER NOT NULL DEFAULT 0,
            quiet_start TEXT NOT NULL DEFAULT '22:00',
            quiet_end TEXT NOT NULL DEFAULT '06:00',
            cooldown_seconds INTEGER NOT NULL DEFAULT 300
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            notification_type TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            sensor TEXT DEFAULT '',
            location TEXT DEFAULT '',
            incident_id INTEGER,
            severity TEXT DEFAULT 'Medium',
            created_at TEXT NOT NULL,
            data_source TEXT NOT NULL DEFAULT 'live',
            read INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    try:
        conn.execute("ALTER TABLE notifications ADD COLUMN data_source TEXT NOT NULL DEFAULT 'live'")
    except sqlite3.OperationalError:
        pass

    conn.execute(
        """INSERT OR IGNORE INTO notification_settings
           (id, smoke_warning, smoke_critical, aqi_warning_threshold,
            quiet_start, quiet_end, cooldown_seconds)
           VALUES (1, 500, 700, 100, '22:00', '06:00', 300)"""
    )

    # No demo notifications are seeded. Alerts appear only from new live Arduino readings.

    conn.execute("""
        CREATE TABLE IF NOT EXISTS emergency_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            auto_dispatch INTEGER NOT NULL DEFAULT 1,
            fire_department INTEGER NOT NULL DEFAULT 1,
            ambulance INTEGER NOT NULL DEFAULT 1,
            hazmat INTEGER NOT NULL DEFAULT 1,
            police_control INTEGER NOT NULL DEFAULT 0,
            fire_contact TEXT NOT NULL DEFAULT 'Fire & Rescue Control Room',
            ambulance_contact TEXT NOT NULL DEFAULT 'Emergency Ambulance Control',
            hazmat_contact TEXT NOT NULL DEFAULT 'HazMat / Disaster Response Control',
            police_contact TEXT NOT NULL DEFAULT 'Police Control Room'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS emergency_dispatches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            severity TEXT NOT NULL,
            location TEXT NOT NULL,
            sensor TEXT DEFAULT '',
            recipient_type TEXT NOT NULL,
            recipient TEXT NOT NULL,
            message TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Queued (Demo)',
            created_at TEXT NOT NULL,
            station_id INTEGER,
            FOREIGN KEY(station_id) REFERENCES stations(id)
        )
    """)
    try:
        conn.execute("ALTER TABLE emergency_dispatches ADD COLUMN station_id INTEGER")
    except sqlite3.OperationalError:
        pass
    conn.execute("CREATE INDEX IF NOT EXISTS idx_emergency_dispatch_station ON emergency_dispatches(station_id,created_at DESC)")
    conn.execute("UPDATE emergency_dispatches SET station_id=(SELECT id FROM stations WHERE station_name=emergency_dispatches.location) WHERE station_id IS NULL")
    conn.execute("""INSERT OR IGNORE INTO emergency_settings (id) VALUES (1)""")

    conn.execute("""CREATE TABLE IF NOT EXISTS sensor_calibration (
        id INTEGER PRIMARY KEY CHECK (id=1), calibrated_at TEXT NOT NULL, baseline REAL NOT NULL DEFAULT 0,
        notes TEXT DEFAULT '', next_due TEXT DEFAULT ''
    )""")
    conn.execute("INSERT OR IGNORE INTO sensor_calibration (id, calibrated_at, baseline, notes, next_due) VALUES (1, ?, 0, 'Initial calibration record', '')", (datetime.now().isoformat(timespec="seconds"),))
    conn.execute("""CREATE TABLE IF NOT EXISTS safe_zones (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, latitude REAL NOT NULL, longitude REAL NOT NULL,
        capacity INTEGER DEFAULT 0, notes TEXT DEFAULT ''
    )""")
    safe_count=conn.execute("SELECT COUNT(*) AS n FROM safe_zones").fetchone()["n"]
    if safe_count==0:
        conn.executemany("INSERT INTO safe_zones(name,latitude,longitude,capacity,notes) VALUES(?,?,?,?,?)", [
            ("Main Assembly Point",30.3398,76.3869,150,"Primary evacuation area"),
            ("Secondary Safe Zone",30.3406,76.3858,100,"Use if primary zone is affected"),
        ])
    # One-time cleanup for this live-data update. It removes old sensor history and
    # old notifications from earlier builds, then preserves all readings created after this update.
    conn.execute("CREATE TABLE IF NOT EXISTS system_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
    reset_key = "live_smoke_reset_v1"
    already_reset = conn.execute("SELECT 1 FROM system_meta WHERE key=?", (reset_key,)).fetchone()
    if not already_reset:
        conn.execute("DELETE FROM sensor_data")
        conn.execute("DELETE FROM notifications")
        conn.execute("DELETE FROM incidents WHERE data_source='demo'")
        conn.execute("UPDATE stations SET current_smoke=0, status='Waiting' WHERE id=?", (s1["id"],))
        conn.execute("INSERT INTO system_meta(key,value) VALUES(?,?)", (reset_key, datetime.now().isoformat(timespec="seconds")))


    conn.execute("""
        CREATE TABLE IF NOT EXISTS fcm_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            installation_id TEXT NOT NULL UNIQUE,
            station_id INTEGER,
            created_at TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(station_id) REFERENCES stations(id)
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_fcm_devices_station ON fcm_devices(station_id)")
    conn.commit()
    conn.close()



def logged_in():
    return session.get("logged_in") is True and session.get("user_id") is not None


def login_required_json():
    if not logged_in():
        return jsonify({"error": "Authentication required"}), 401
    return None


def row_to_dict(row):
    return dict(row) if row else None


def safe_float(value, default=0):
    if value in (None, ""):
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        raise ValueError(f"Invalid numeric value: {value}")


def get_air_quality_data(source="Dataset 1", limit=12, offset=0):
    user=current_user()
    if user and not is_admin() and user.get("station_id"):
        conn=get_db(); sid=int(user["station_id"])
        total=conn.execute("SELECT COUNT(*) AS n FROM sensor_data WHERE station_id=?",(sid,)).fetchone()["n"]
        rows=conn.execute("""
            SELECT id AS row_number,no2,co,pm10,pm25,
                   no2 AS aqi_no2,co AS aqi_co,pm10 AS aqi_pm10,pm25 AS aqi_pm25,
                   aqi AS aqi_overall,
                   CASE WHEN aqi<=50 THEN 'Good' WHEN aqi<=100 THEN 'Satisfactory/Moderate'
                   WHEN aqi<=200 THEN 'Moderate/Poor' WHEN aqi<=300 THEN 'Poor'
                   WHEN aqi<=400 THEN 'Very Poor' ELSE 'Severe' END AS remarks
            FROM sensor_data WHERE station_id=? ORDER BY recorded_at DESC LIMIT ? OFFSET ?
        """,(sid,int(limit),int(offset))).fetchall()
        trend=conn.execute("""
            SELECT id AS row_number,no2,co,pm10,pm25,aqi AS aqi_overall,'' AS remarks
            FROM sensor_data WHERE station_id=? ORDER BY recorded_at ASC LIMIT 40
        """,(sid,)).fetchall()
        conn.close()
        return {"source":user.get("station_name") or "My Station",
                "sources":[user.get("station_name") or "My Station"],
                "summary":{"latest_aqi":user.get("current_aqi"),"latest_pm25":user.get("current_pm25"),
                           "latest_pm10":user.get("current_pm10"),"latest_co":user.get("current_co"),
                           "latest_no2":user.get("current_no2"),"total_rows":total},
                "records":[row_to_dict(r) for r in rows],"total_records":int(total),
                "offset":int(offset),"limit":int(limit),"trend":[row_to_dict(r) for r in trend]}
    conn = get_db()
    sources = [row["source"] for row in conn.execute(
        "SELECT source FROM air_quality_summary ORDER BY source"
    ).fetchall()]
    if source not in sources and sources:
        source = sources[0]

    summary = conn.execute(
        "SELECT * FROM air_quality_summary WHERE source = ?",
        (source,),
    ).fetchone()

    total_rows = conn.execute(
        "SELECT COUNT(*) AS n FROM air_quality WHERE source = ?",
        (source,),
    ).fetchone()["n"]

    rows = conn.execute(
        """
        SELECT row_number, no2, co, pm10, pm25,
               aqi_no2, aqi_co, aqi_pm10, aqi_pm25,
               aqi_overall, remarks
        FROM air_quality
        WHERE source = ?
        ORDER BY row_number DESC
        LIMIT ? OFFSET ?
        """,
        (source, int(limit), int(offset)),
    ).fetchall()

    samples = conn.execute(
        """
        SELECT row_number, no2, co, pm10, pm25, aqi_overall, remarks
        FROM air_quality_samples
        WHERE source = ?
        ORDER BY row_number ASC
        """,
        (source,),
    ).fetchall()
    conn.close()

    return {
        "source": source,
        "sources": sources,
        "summary": row_to_dict(summary),
        "records": [row_to_dict(row) for row in rows],
        "total_records": int(total_rows),
        "offset": int(offset),
        "limit": int(limit),
        "trend": [row_to_dict(row) for row in samples[-40:]],
    }


def build_dashboard_data(source="Dataset 1"):
    conn = get_db()
    suffix,params=station_filter_sql("i")
    latest=conn.execute(f"SELECT i.* FROM incidents i WHERE 1=1 {suffix} ORDER BY i.id DESC LIMIT 1",params).fetchone()
    total=conn.execute(f"SELECT COUNT(*) AS n FROM incidents i WHERE 1=1 {suffix}",params).fetchone()["n"]
    active=conn.execute(f"SELECT COUNT(*) AS n FROM incidents i WHERE i.status IN ('Active','Review','Pending','In Progress') {suffix}",params).fetchone()["n"]
    high=conn.execute(f"SELECT COUNT(*) AS n FROM incidents i WHERE i.severity='High' AND i.status NOT IN ('Resolved','Completed') {suffix}",params).fetchone()["n"]
    resolved=conn.execute(f"SELECT COUNT(*) AS n FROM incidents i WHERE i.status IN ('Resolved','Completed') {suffix}",params).fetchone()["n"]
    recent=conn.execute(f"SELECT i.* FROM incidents i WHERE 1=1 {suffix} ORDER BY i.id DESC LIMIT 8",params).fetchall()
    conn.close()

    air = get_air_quality_data(source, 12)
    summary = air["summary"] or {}
    aqi = float(summary.get("latest_aqi") or 0)
    pm25 = float(summary.get("latest_pm25") or 0)
    pm10 = float(summary.get("latest_pm10") or 0)
    co = float(summary.get("latest_co") or 0)
    no2 = float(summary.get("latest_no2") or 0)
    evaluate_aqi_notification(aqi)

    # The uploaded datasets contain pollutant/AQI fields but do not contain
    # environmental temperature or humidity, so those values are deliberately not inferred.
    _band, safety_label, _severity = aqi_band(aqi)

    safety_score = max(0, min(100, round(100 - aqi / 5)))

    # Explainable AI-style risk prediction using current AQI, smoke and recent trend.
    recent_smokes=[float(r["smoke_level"] or 0) for r in recent if r["smoke_level"] is not None]
    avg_smoke=statistics.mean(recent_smokes) if recent_smokes else 0
    station_user=current_user()
    station_smoke=station_user.get("current_smoke") if station_user else None
    smoke_now=float(LATEST_SENSOR.get("mq135_raw") or station_smoke or (recent_smokes[0] if recent_smokes else 0))
    risk_points=min(100, round((aqi/3.0)*0.45 + (smoke_now/10.0)*0.4 + (min(avg_smoke*1.5,1000)/10)*0.15))
    risk_label="Low" if risk_points < 35 else ("Medium" if risk_points < 65 else ("High" if risk_points < 85 else "Critical"))
    prediction="Stable / Low risk" if risk_points < 35 else ("Monitor closely" if risk_points < 65 else ("Likely escalation" if risk_points < 85 else "Immediate response recommended"))
    anomaly=bool(recent_smokes and smoke_now > max(700, avg_smoke*2.5))

    return {
        "metrics": {
            "pm25": pm25,
            "pm10": pm10,
            "co": co,
            "no2": no2,
            "aqi": aqi,
            "safety_score": safety_score,
            "safety_label": safety_label,
            "total_incidents": total,
            "active_incidents": active,
            "high_alerts": high,
            "resolved": resolved,
        },
        "latest": row_to_dict(latest),
        "incidents": [row_to_dict(row) for row in recent],
        "air_quality": air,
        "hardware": dict(LATEST_SENSOR),
        "risk_prediction": {"score": risk_points, "label": risk_label, "prediction": prediction, "anomaly": anomaly, "smoke_current": smoke_now, "smoke_average": round(avg_smoke,1)},
    }


@app.route("/")
def home():
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    error = ""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if not name or not username or not email or not password:
            error = "Please fill in all required fields."
        elif len(username) < 3:
            error = "Username must be at least 3 characters."
        elif "@" not in email or "." not in email.split("@")[-1]:
            error = "Please enter a valid Gmail/email address."
        elif len(password) < 8:
            error = "Password must be at least 8 characters."
        elif password != confirm:
            error = "Passwords do not match."
        else:
            conn = get_db()
            exists_user = conn.execute("SELECT id FROM users WHERE lower(username)=lower(?)", (username,)).fetchone()
            exists_email = conn.execute("SELECT id FROM users WHERE lower(email)=lower(?)", (email,)).fetchone()
            if exists_user:
                error = "That username is already registered. Please choose another one."
            elif exists_email:
                error = "That email is already registered. Please use another email or log in."
            else:
                now = time.time()
                old = conn.execute("SELECT id FROM pending_registrations WHERE lower(email)=lower(?)", (email,)).fetchone()
                if old:
                    conn.execute("DELETE FROM pending_registrations WHERE id=?", (old["id"],))
                code = _new_otp()
                conn.execute("""INSERT INTO pending_registrations
                    (username,password_hash,name,email,otp_hash,expires_at,attempts,last_sent_at,created_at)
                    VALUES(?,?,?,?,?,?,?,?,?)""",
                    (username, generate_password_hash(password), name, email, _otp_hash(code),
                     now + OTP_TTL_SECONDS, 0, now, datetime.now().isoformat(timespec="seconds")))
                conn.commit()
                email_sent = False
                if SMTP_USER and SMTP_PASSWORD:
                    try:
                        _send_otp_email(email, code, "email verification")
                        email_sent = True
                    except Exception:
                        email_sent = False
                conn.close()
                session["pending_registration_email"] = email
                session["pending_registration_demo_otp"] = code if not email_sent else None
                return redirect(url_for("verify_registration"))
            conn.close()
    return render_template("register.html", error=error)


@app.route("/verify-registration", methods=["GET", "POST"])
def verify_registration():
    email = session.get("pending_registration_email")
    if not email:
        return redirect(url_for("register"))
    error = ""
    if request.method == "POST":
        code = request.form.get("otp", "").strip()
        conn = get_db()
        row = conn.execute("SELECT * FROM pending_registrations WHERE lower(email)=lower(?)", (email,)).fetchone()
        if not row:
            error = "Verification request expired. Please register again."
        elif time.time() > row["expires_at"]:
            conn.execute("DELETE FROM pending_registrations WHERE id=?", (row["id"],)); conn.commit()
            error = "OTP expired. Please register again."
        elif row["attempts"] >= OTP_MAX_ATTEMPTS:
            conn.execute("DELETE FROM pending_registrations WHERE id=?", (row["id"],)); conn.commit()
            error = "Too many incorrect attempts. Please register again."
        elif not secrets.compare_digest(_otp_hash(code), row["otp_hash"]):
            conn.execute("UPDATE pending_registrations SET attempts=attempts+1 WHERE id=?", (row["id"],)); conn.commit()
            error = "Incorrect OTP. Please try again."
        else:
            station = conn.execute("SELECT id FROM stations ORDER BY id LIMIT 1").fetchone()
            station_id = station["id"] if station else None
            conn.execute("""INSERT INTO users(username,password_hash,name,email,email_verified,role,station_id,created_at)
                            VALUES(?,?,?,?,?,?,?,?)""",
                         (row["username"], row["password_hash"], row["name"], row["email"], 1,
                          "user", station_id, datetime.now().isoformat(timespec="seconds")))
            conn.execute("DELETE FROM pending_registrations WHERE id=?", (row["id"],))
            conn.commit(); conn.close()
            session.pop("pending_registration_email", None)
            return redirect(url_for("login", registered="1"))
        conn.close()
    demo_otp = session.get("pending_registration_demo_otp")
    return render_template("verify_otp.html", email=email, error=error, purpose="registration", demo_otp=demo_otp)


@app.route("/resend-registration-otp", methods=["POST"])
def resend_registration_otp():
    email = session.get("pending_registration_email")
    if not email:
        return redirect(url_for("register"))
    conn = get_db(); row = conn.execute("SELECT * FROM pending_registrations WHERE lower(email)=lower(?)", (email,)).fetchone()
    if not row:
        conn.close(); return redirect(url_for("register"))
    if time.time() - row["last_sent_at"] < OTP_RESEND_SECONDS:
        conn.close(); return render_template("verify_otp.html", email=email, error="Please wait 60 seconds before requesting another OTP.", purpose="registration")
    code = _new_otp(); now=time.time()
    email_sent = False
    if SMTP_USER and SMTP_PASSWORD:
        try:
            _send_otp_email(email, code, "email verification")
            email_sent = True
        except Exception:
            email_sent = False
    conn.execute("UPDATE pending_registrations SET otp_hash=?,expires_at=?,attempts=0,last_sent_at=? WHERE id=?", (_otp_hash(code), now+OTP_TTL_SECONDS, now, row["id"]))
    conn.commit()
    conn.close()
    session["pending_registration_demo_otp"] = code if not email_sent else None
    return redirect(url_for("verify_registration"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error=""; error_role=""; registered = request.args.get("registered") == "1"
    reset = request.args.get("reset") == "1"
    if request.method=="POST":
        username=request.form.get("username","").strip(); password=request.form.get("password","")
        login_role=request.form.get("login_role","user").strip().lower()
        if login_role not in {"admin","user"}: login_role="user"
        conn=get_db(); user=conn.execute("SELECT * FROM users WHERE lower(username)=lower(?)",(username,)).fetchone(); conn.close()
        if user and check_password_hash(user["password_hash"],password):
            actual_role=(user["role"] or "user").lower()
            role_matches = actual_role == "admin" if login_role == "admin" else actual_role in {"user","supervisor"}
            if role_matches:
                # Admin demo login: username/password is sufficient; no email OTP required.
                if actual_role == "admin":
                    session.clear()
                    session.update({
                        "logged_in": True,
                        "user_id": int(user["id"]),
                        "username": user["username"],
                        "name": user["name"],
                        "role": actual_role,
                        "station_id": user["station_id"],
                    })
                    return redirect(url_for("dashboard"))

                # Regular users use OTP verification. Gmail is optional for local/demo use.
                user_email = (user["email"] or "").strip().lower()
                if not user_email or not user["email_verified"]:
                    error = "Please complete email verification before logging in."
                else:
                    conn=get_db(); now=time.time()
                    conn.execute("DELETE FROM login_otps WHERE user_id=?", (user["id"],))
                    code=_new_otp()
                    conn.execute("INSERT INTO login_otps(user_id,otp_hash,expires_at,attempts,last_sent_at,created_at) VALUES(?,?,?,?,?,?)",
                                 (user["id"],_otp_hash(code),now+OTP_TTL_SECONDS,0,now,datetime.now().isoformat(timespec="seconds")))
                    conn.commit()
                    email_sent = False
                    if SMTP_USER and SMTP_PASSWORD:
                        try:
                            _send_otp_email(user_email, code, "login")
                            email_sent = True
                        except Exception:
                            email_sent = False
                    conn.close()
                    session.clear()
                    session["pending_login_user_id"]=int(user["id"])
                    session["pending_login_role"]=actual_role
                    session["pending_login_demo_otp"]=code if not email_sent else None
                    return redirect(url_for("verify_login"))
            else:
                error = "This account is not an Admin account. Please use User Login." if login_role == "admin" else "This account is an Admin account. Please use Admin Login."
        else: error="Invalid username or password."
        error_role=login_role
    return render_template("login.html",error=error,error_role=error_role,registered=registered,reset=reset)


@app.route("/verify-login", methods=["GET", "POST"])
def verify_login():
    user_id=session.get("pending_login_user_id")
    if not user_id: return redirect(url_for("login"))
    error=""
    conn=get_db(); user=conn.execute("SELECT * FROM users WHERE id=?",(user_id,)).fetchone(); otp_row=conn.execute("SELECT * FROM login_otps WHERE user_id=? ORDER BY id DESC LIMIT 1",(user_id,)).fetchone()
    if not user or not otp_row:
        conn.close(); session.clear(); return redirect(url_for("login"))
    if request.method=="POST":
        code=request.form.get("otp","").strip()
        if time.time() > otp_row["expires_at"]:
            conn.execute("DELETE FROM login_otps WHERE id=?",(otp_row["id"],)); conn.commit(); error="OTP expired. Please log in again."
        elif otp_row["attempts"] >= OTP_MAX_ATTEMPTS:
            conn.execute("DELETE FROM login_otps WHERE id=?",(otp_row["id"],)); conn.commit(); error="Too many incorrect attempts. Please log in again."
        elif not secrets.compare_digest(_otp_hash(code), otp_row["otp_hash"]):
            conn.execute("UPDATE login_otps SET attempts=attempts+1 WHERE id=?",(otp_row["id"],)); conn.commit(); error="Incorrect OTP. Please try again."
        else:
            conn.execute("DELETE FROM login_otps WHERE id=?",(otp_row["id"],)); conn.commit(); conn.close()
            role=(user["role"] or "user").lower(); session.clear(); session.update({"logged_in":True,"user_id":int(user["id"]),"username":user["username"],"name":user["name"],"role":role,"station_id":user["station_id"]})
            return redirect(url_for("dashboard"))
    conn.close()
    demo_otp = session.get("pending_login_demo_otp")
    return render_template("verify_otp.html", email=user["email"], error=error, purpose="login", demo_otp=demo_otp)


@app.route("/resend-login-otp", methods=["POST"])
def resend_login_otp():
    user_id=session.get("pending_login_user_id")
    if not user_id: return redirect(url_for("login"))
    conn=get_db(); row=conn.execute("SELECT u.email, o.* FROM users u JOIN login_otps o ON o.user_id=u.id WHERE u.id=? ORDER BY o.id DESC LIMIT 1",(user_id,)).fetchone()
    if not row: conn.close(); return redirect(url_for("login"))
    if time.time()-row["last_sent_at"] < OTP_RESEND_SECONDS:
        conn.close(); return render_template("verify_otp.html",email=row["email"],error="Please wait 60 seconds before requesting another OTP.",purpose="login",demo_otp=session.get("pending_login_demo_otp"))
    code=_new_otp(); now=time.time()
    email_sent = False
    if SMTP_USER and SMTP_PASSWORD:
        try:
            _send_otp_email(row["email"],code,"login")
            email_sent = True
        except Exception:
            email_sent = False
    conn.execute("UPDATE login_otps SET otp_hash=?,expires_at=?,attempts=0,last_sent_at=? WHERE id=?",(_otp_hash(code),now+OTP_TTL_SECONDS,now,row["id"]))
    conn.commit()
    conn.close()
    session["pending_login_demo_otp"] = code if not email_sent else None
    return redirect(url_for("verify_login"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    error = ""
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip().lower()
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE lower(username)=? OR lower(email)=? LIMIT 1", (identifier, identifier)).fetchone()
        if not user or not (user["email"] or "").strip() or not user["email_verified"]:
            error = "No verified account was found for that username/email."
        else:
            now = time.time()
            conn.execute("DELETE FROM login_otps WHERE user_id=?", (user["id"],))
            code = _new_otp()
            conn.execute("INSERT INTO login_otps(user_id,otp_hash,expires_at,attempts,last_sent_at,created_at) VALUES(?,?,?,?,?,?)",
                         (user["id"], _otp_hash(code), now + OTP_TTL_SECONDS, 0, now, datetime.now().isoformat(timespec="seconds")))
            conn.commit()
            email_sent = False
            if SMTP_USER and SMTP_PASSWORD:
                try:
                    _send_otp_email(user["email"].strip(), code, "password reset")
                    email_sent = True
                except Exception:
                    email_sent = False
            conn.close()
            session.clear()
            session["pending_reset_user_id"] = int(user["id"])
            session["pending_reset_demo_otp"] = code if not email_sent else None
            return redirect(url_for("reset_password"))
        conn.close()
    return render_template("forgot_password.html", error=error)


@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    user_id = session.get("pending_reset_user_id")
    if not user_id:
        return redirect(url_for("forgot_password"))
    error = ""
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    otp = conn.execute("SELECT * FROM login_otps WHERE user_id=? ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
    if not user or not otp:
        conn.close(); session.clear(); return redirect(url_for("forgot_password"))
    if request.method == "POST":
        code = request.form.get("otp", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if time.time() > otp["expires_at"]:
            error = "OTP expired. Please request a new reset code."
        elif otp["attempts"] >= OTP_MAX_ATTEMPTS:
            error = "Too many incorrect attempts. Please request a new reset code."
        elif not secrets.compare_digest(_otp_hash(code), otp["otp_hash"]):
            conn.execute("UPDATE login_otps SET attempts=attempts+1 WHERE id=?", (otp["id"],)); conn.commit()
            error = "Incorrect OTP."
        elif len(password) < 8:
            error = "New password must be at least 8 characters."
        elif password != confirm:
            error = "Passwords do not match."
        else:
            conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(password), user_id))
            conn.execute("DELETE FROM login_otps WHERE id=?", (otp["id"],))
            conn.commit(); conn.close(); session.clear()
            return redirect(url_for("login", reset="1"))
    conn.close()
    demo_otp = session.get("pending_reset_demo_otp")
    return render_template("reset_password.html", email=user["email"], error=error, demo_otp=demo_otp)


@app.route("/resend-reset-otp", methods=["POST"])
def resend_reset_otp():
    user_id = session.get("pending_reset_user_id")
    if not user_id: return redirect(url_for("forgot_password"))
    conn = get_db(); row = conn.execute("SELECT u.email, o.* FROM users u JOIN login_otps o ON o.user_id=u.id WHERE u.id=? ORDER BY o.id DESC LIMIT 1", (user_id,)).fetchone()
    if not row: conn.close(); return redirect(url_for("forgot_password"))
    if time.time() - row["last_sent_at"] < OTP_RESEND_SECONDS:
        conn.close(); return render_template("reset_password.html", email=row["email"], error="Please wait 60 seconds before requesting another OTP.")
    code = _new_otp(); now = time.time()
    email_sent = False
    if SMTP_USER and SMTP_PASSWORD:
        try:
            _send_otp_email(row["email"], code, "password reset")
            email_sent = True
        except Exception:
            email_sent = False
    conn.execute("UPDATE login_otps SET otp_hash=?,expires_at=?,attempts=0,last_sent_at=? WHERE id=?", (_otp_hash(code), now + OTP_TTL_SECONDS, now, row["id"]))
    conn.commit()
    conn.close()
    session["pending_reset_demo_otp"] = code if not email_sent else None
    return redirect(url_for("reset_password"))


@app.route("/api/camera/status")
def api_camera_status():
    auth = login_required_json()
    if auth:
        return auth
    available = cv2 is not None and _camera_open() is not None
    return jsonify({
        "available": available,
        "camera_index": CAMERA_INDEX,
        "marker_id": CAMERA_MARKER_ID,
        "marker_size_cm": round(CAMERA_MARKER_SIZE_M * 100, 1),
        "message": CAMERA_LAST_ERROR or ("PC camera ready" if available else "PC camera unavailable"),
    })


def _camera_stream_generator():
    while True:
        frame = _camera_frame()
        if frame is None:
            time.sleep(0.25)
            continue
        try:
            # Run local visual smoke/fire detection and show the combined state.
            vision = _visual_detection(frame)
            range_info = _range_from_frame(frame)
            if range_info.get("detected"):
                cv2.putText(frame, f"Range: {range_info['distance_cm']:.1f} cm (approx)", (18, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (20, 150, 90), 2, cv2.LINE_AA)
            else:
                cv2.putText(frame, "Range: reference not detected", (18, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (210, 210, 210), 2, cv2.LINE_AA)
            label = "FIRE DETECTED" if vision.get("fire_detected") else ("SMOKE DETECTED" if vision.get("smoke_detected") else "VISUAL: CLEAR")
            label_color = (30, 30, 230) if vision.get("fire_detected") else ((70, 170, 230) if vision.get("smoke_detected") else (60, 180, 90))
            cv2.putText(frame, label, (18, 68), cv2.FONT_HERSHEY_SIMPLEX, 0.72, label_color, 2, cv2.LINE_AA)
            ok, encoded = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
            if not ok:
                continue
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + encoded.tobytes() + b'\r\n')
        except Exception:
            time.sleep(0.05)


@app.route("/camera/stream")
def camera_stream():
    auth = login_required_json()
    if auth:
        return auth
    if cv2 is None:
        return jsonify({"error":"OpenCV is not installed. Run pip install -r requirements.txt"}), 500
    if _camera_open() is None:
        return jsonify({"error": CAMERA_LAST_ERROR or "Unable to open PC camera"}), 503
    return Response(_camera_stream_generator(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/api/camera/snapshot")
def camera_snapshot():
    auth = login_required_json()
    if auth:
        return auth
    frame = _camera_frame()
    if frame is None:
        return jsonify({"error": CAMERA_LAST_ERROR or "Unable to read PC camera"}), 503
    ok, encoded = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 90])
    if not ok:
        return jsonify({"error":"Could not encode camera frame"}), 500
    return Response(encoded.tobytes(), mimetype="image/jpeg", headers={"Cache-Control":"no-store"})


@app.route("/api/camera/range")
def camera_range():
    auth = login_required_json()
    if auth:
        return auth
    frame = _camera_frame()
    if frame is None:
        return jsonify({"detected":False,"distance_m":None,"distance_cm":None,"message":CAMERA_LAST_ERROR or "Unable to read PC camera"}), 503
    return jsonify(_range_from_frame(frame))


@app.route("/api/camera/vision")
def camera_vision():
    auth = login_required_json()
    if auth:
        return auth
    frame = _camera_frame()
    if frame is None:
        return jsonify({"status":"unavailable","visual_alert":False,"message":CAMERA_LAST_ERROR or "Unable to read PC camera"}), 503
    result = _visual_detection(frame)
    result["sensor"] = dict(LATEST_SENSOR)
    return jsonify(result)


@app.route("/dashboard")
def dashboard():
    if not logged_in():
        return redirect(url_for("login"))
    user=current_user() or {}
    return render_template("dashboard.html", username=user.get("name") or session.get("username","User"),
                           role=session.get("role","user"), station=user.get("station_name") or "All Stations")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/api/public-status")
def api_public_status():
    """Small public status feed for the login page (no login required)."""
    current_aqi = None
    aqi_label = "Waiting for data"
    try:
        conn = get_db()
        table = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='air_quality_summary'"
        ).fetchone()
        if table:
            row = conn.execute(
                "SELECT latest_aqi FROM air_quality_summary ORDER BY source LIMIT 1"
            ).fetchone()
            if row and row["latest_aqi"] is not None:
                current_aqi = float(row["latest_aqi"])
        conn.close()
    except sqlite3.Error:
        current_aqi = None

    if current_aqi is not None:
        _band, aqi_label, _severity = aqi_band(current_aqi)

    return jsonify({
        "system": "Online",
        "aqi": current_aqi,
        "aqi_label": aqi_label,
        "updated_at": datetime.now().strftime("%I:%M:%S %p")
    })


@app.route("/api/hardware/read")
def api_hardware_read():
    auth = login_required_json()
    if auth:
        return auth
    return jsonify(read_arduino_sensor())


@app.route("/api/smoke-history")
def api_smoke_history():
    auth = login_required_json()
    if auth:
        return auth
    user = current_user() or {}
    station_id = int(user.get("station_id") or os.getenv("ARDUINO_STATION_ID", "1"))
    try:
        limit = max(1, min(10000, int(request.args.get("limit", 3600))))
    except ValueError:
        limit = 3600
    conn = get_db()
    rows = conn.execute(
        """SELECT smoke, recorded_at FROM sensor_data
           WHERE station_id=? AND data_source='live'
           ORDER BY id DESC LIMIT ?""",
        (station_id, limit)
    ).fetchall()
    conn.close()
    readings = [{"value": float(r["smoke"]), "recorded_at": r["recorded_at"]} for r in reversed(rows)]
    return jsonify({"readings": readings, "count": len(readings), "source": "Arduino MQ-135 / LIVE"})


@app.route("/api/session")
def api_session():
    auth=login_required_json()
    if auth: return auth
    return jsonify({"user":current_user(),"role":session.get("role","user")})

@app.route("/api/stations")
def api_stations():
    auth=login_required_json()
    if auth: return auth
    conn=get_db(); ids=allowed_station_ids()
    if ids is None:
        rows=conn.execute("SELECT * FROM stations ORDER BY id").fetchall()
    else:
        rows=conn.execute(f"SELECT * FROM stations WHERE id IN ({','.join('?' for _ in ids)}) ORDER BY id",ids).fetchall()
    result=[]
    for r in rows:
        d=row_to_dict(r)
        d["history"]=[row_to_dict(x) for x in conn.execute(
            "SELECT aqi,pm25,pm10,co,no2,smoke,recorded_at FROM sensor_data WHERE station_id=? AND data_source='live' ORDER BY recorded_at DESC LIMIT 12",(r["id"],)
        ).fetchall()]
        result.append(d)
    conn.close()
    return jsonify({"stations":result})

@app.route("/api/users",methods=["GET","POST"])
def api_users():
    auth=login_required_json()
    if auth: return auth
    if not can_manage_users(): return jsonify({"error":"Admin or Supervisor access required"}),403
    conn=get_db()
    if request.method=="GET":
        rows=conn.execute("""SELECT u.id,u.username,u.name,u.role,u.station_id,u.created_at,s.station_name
                             FROM users u LEFT JOIN stations s ON s.id=u.station_id ORDER BY u.id DESC""").fetchall()
        conn.close(); return jsonify({"users":[row_to_dict(r) for r in rows]})
    if not is_admin():
        conn.close(); return jsonify({"error":"Only Admin can create users"}),403
    data=request.get_json(silent=True) or {}
    username=str(data.get("username") or "").strip(); name=str(data.get("name") or "").strip()
    password=str(data.get("password") or ""); role=str(data.get("role") or "user").lower()
    station_id=data.get("station_id")
    if not username or not name or not password: conn.close(); return jsonify({"error":"Name, username and password are required"}),400
    if role not in {"admin","supervisor","user"}: conn.close(); return jsonify({"error":"Invalid role"}),400
    try:
        station_id=int(station_id) if station_id not in (None,"") else None
        cur=conn.execute("""INSERT INTO users(username,password_hash,name,role,station_id,created_at)
                            VALUES(?,?,?,?,?,?)""",(username,generate_password_hash(password),name,role,station_id,datetime.now().isoformat(timespec="seconds")))
        conn.commit()
        row=conn.execute("""SELECT u.id,u.username,u.name,u.role,u.station_id,s.station_name
                            FROM users u LEFT JOIN stations s ON s.id=u.station_id WHERE u.id=?""",(cur.lastrowid,)).fetchone()
        conn.close(); return jsonify(row_to_dict(row)),201
    except sqlite3.IntegrityError:
        conn.close(); return jsonify({"error":"Username already exists"}),409

@app.route("/api/users/<int:user_id>",methods=["DELETE"])
def api_user_delete(user_id):
    auth=login_required_json()
    if auth: return auth
    if not is_admin(): return jsonify({"error":"Only Admin can delete users"}),403
    if user_id==session.get("user_id"): return jsonify({"error":"You cannot delete the currently logged-in admin"}),400
    conn=get_db(); conn.execute("DELETE FROM users WHERE id=?",(user_id,)); conn.commit(); conn.close()
    return jsonify({"success":True})

@app.route("/api/dashboard")
def api_dashboard():
    auth = login_required_json()
    if auth:
        return auth
    return jsonify(build_dashboard_data(request.args.get("source", "Dataset 1")))


@app.route("/api/air-quality")
def api_air_quality():
    auth = login_required_json()
    if auth:
        return auth
    source = request.args.get("source", "Dataset 1")
    try:
        limit = max(1, min(100, int(request.args.get("limit", 20))))
    except ValueError:
        limit = 20
    try:
        offset = max(0, int(request.args.get("offset", 0)))
    except ValueError:
        offset = 0
    return jsonify(get_air_quality_data(source, limit, offset))


@app.route("/api/sensor-data/export.csv")
def export_sensor_data():
    """Export live/demo sensor history for the logged-in user's station."""
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    ids = allowed_station_ids()
    if ids is None:
        rows = conn.execute("""
            SELECT sd.recorded_at, s.station_name, sd.smoke, sd.aqi, sd.pm25, sd.pm10,
                   sd.co, sd.no2, sd.data_source
            FROM sensor_data sd JOIN stations s ON s.id=sd.station_id
            ORDER BY sd.recorded_at DESC
        """).fetchall()
    else:
        rows = conn.execute(f"""
            SELECT sd.recorded_at, s.station_name, sd.smoke, sd.aqi, sd.pm25, sd.pm10,
                   sd.co, sd.no2, sd.data_source
            FROM sensor_data sd JOIN stations s ON s.id=sd.station_id
            WHERE sd.station_id IN ({','.join('?' for _ in ids)})
            ORDER BY sd.recorded_at DESC
        """, ids).fetchall()
    conn.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["recorded_at","station","smoke_mq135_raw","aqi","pm25","pm10","co","no2","data_source"])
    for row in rows:
        writer.writerow([row[k] for k in row.keys()])
    response = Response(output.getvalue(), mimetype="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=ai-safe-sensor-data.csv"
    return response


@app.route("/api/incidents", methods=["GET", "POST"])
def api_incidents():
    auth = login_required_json()
    if auth:
        return auth

    if request.method == "GET":
        conn = get_db()
        suffix,params=station_filter_sql("i")
        rows = conn.execute(f"SELECT i.* FROM incidents i WHERE 1=1 {suffix} ORDER BY i.id DESC",params).fetchall()
        conn.close()
        return jsonify([row_to_dict(row) for row in rows])

    data = request.get_json(silent=True) or {}
    required = ["incident_type", "sensor", "severity", "status"]
    missing = [field for field in required if not str(data.get(field, "")).strip()]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    now = datetime.now().isoformat(timespec="seconds")
    incident_time = str(data.get("incident_time") or datetime.now().strftime("%I:%M %p"))
    try:
        values = (
            incident_time,
            str(data["incident_type"]).strip(),
            str(data["sensor"]).strip(),
            str(data["severity"]).strip(),
            str(data["status"]).strip(),
            (int(data.get("station_id") or session.get("station_id") or 1)
             if is_admin() else int(session.get("station_id") or 1)),
            safe_float(data.get("smoke_level"), 0),
            safe_float(data.get("aqi"), 0),
            safe_float(data.get("temperature"), 0),
            safe_float(data.get("humidity"), 0),
            safe_float(data.get("latitude"), None) if str(data.get("latitude", "")).strip() else None,
            safe_float(data.get("longitude"), None) if str(data.get("longitude", "")).strip() else None,
            str(data.get("description") or "").strip(),
            "live",
            now,
            now,
        )
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    conn = get_db()
    cur = conn.execute(
        """
        INSERT INTO incidents
        (incident_time, incident_type, sensor, severity, status, station_id,
         smoke_level, aqi, temperature, humidity, latitude, longitude,
         description, data_source, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        values,
    )
    conn.commit()
    row = conn.execute("SELECT * FROM incidents WHERE id = ?", (cur.lastrowid,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row)), 201


@app.route("/api/incidents/<int:incident_id>", methods=["GET", "PUT", "DELETE"])
def api_incident(incident_id):
    auth = login_required_json()
    if auth:
        return auth

    conn = get_db()
    existing = conn.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({"error": "Incident not found"}), 404
    allowed=allowed_station_ids()
    if allowed is not None and existing["station_id"] not in allowed:
        conn.close()
        return jsonify({"error":"You do not have access to this incident"}),403

    if request.method == "GET":
        conn.close()
        return jsonify(row_to_dict(existing))

    if request.method == "DELETE":
        conn.execute("DELETE FROM incidents WHERE id = ?", (incident_id,))
        conn.commit()
        conn.close()
        return jsonify({"success": True})

    data = request.get_json(silent=True) or {}
    try:
        fields = {
            "incident_time": str(data.get("incident_time") or existing["incident_time"]),
            "incident_type": str(data.get("incident_type") or existing["incident_type"]).strip(),
            "sensor": str(data.get("sensor") or existing["sensor"]).strip(),
            "severity": str(data.get("severity") or existing["severity"]).strip(),
            "status": str(data.get("status") or existing["status"]).strip(),
            "smoke_level": safe_float(data.get("smoke_level"), existing["smoke_level"]),
            "aqi": safe_float(data.get("aqi"), existing["aqi"]),
            "temperature": safe_float(data.get("temperature"), existing["temperature"]),
            "humidity": safe_float(data.get("humidity"), existing["humidity"]),
            "latitude": safe_float(data.get("latitude"), existing["latitude"]) if data.get("latitude") not in (None, "") else None,
            "longitude": safe_float(data.get("longitude"), existing["longitude"]) if data.get("longitude") not in (None, "") else None,
            "description": str(data.get("description") if data.get("description") is not None else existing["description"]),
            "updated_at": datetime.now().isoformat(timespec="seconds"),
        }
    except ValueError as exc:
        conn.close()
        return jsonify({"error": str(exc)}), 400
    conn.execute(
        """
        UPDATE incidents SET
            incident_time=:incident_time,
            incident_type=:incident_type,
            sensor=:sensor,
            severity=:severity,
            status=:status,
            smoke_level=:smoke_level,
            aqi=:aqi,
            temperature=:temperature,
            humidity=:humidity,
            latitude=:latitude,
            longitude=:longitude,
            description=:description,
            updated_at=:updated_at
        WHERE id=:id
        """,
        {**fields, "id": incident_id},
    )
    conn.commit()
    row = conn.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
    conn.close()
    return jsonify(row_to_dict(row))



@app.route("/api/notifications")
def api_notifications():
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    if is_admin():
        rows = conn.execute("SELECT * FROM notifications ORDER BY id DESC LIMIT 50").fetchall()
        unread = conn.execute("SELECT COUNT(*) AS n FROM notifications WHERE read = 0").fetchone()["n"]
    else:
        station_name=(current_user() or {}).get("station_name") or ""
        rows=conn.execute("SELECT * FROM notifications WHERE location=? ORDER BY id DESC LIMIT 50",(station_name,)).fetchall()
        unread=conn.execute("SELECT COUNT(*) AS n FROM notifications WHERE location=? AND read=0",(station_name,)).fetchone()["n"]
    conn.close()
    return jsonify({"notifications": [row_to_dict(r) for r in rows], "unread": int(unread)})


@app.route("/api/notifications/<int:notification_id>/read", methods=["POST"])
def api_notification_read(notification_id):
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    if is_admin():
        conn.execute("UPDATE notifications SET read=1 WHERE id=?",(notification_id,))
    else:
        station_name=(current_user() or {}).get("station_name") or ""
        conn.execute("UPDATE notifications SET read=1 WHERE id=? AND location=?",(notification_id,station_name))
    conn.commit()
    conn.close()
    return jsonify({"success": True})


@app.route("/api/notifications/read-all", methods=["POST"])
def api_notifications_read_all():
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    if is_admin():
        conn.execute("UPDATE notifications SET read=1 WHERE read=0")
    else:
        station_name=(current_user() or {}).get("station_name") or ""
        conn.execute("UPDATE notifications SET read=1 WHERE read=0 AND location=?",(station_name,))
    conn.commit()
    conn.close()
    return jsonify({"success": True})


@app.route("/api/notification-settings", methods=["GET", "PUT"])
def api_notification_settings():
    auth = login_required_json()
    if auth:
        return auth
    if request.method == "PUT" and not is_admin():
        return jsonify({"error":"Only administrators can change system-wide settings"}), 403
    if request.method == "GET":
        return jsonify(get_notification_settings())

    data = request.get_json(silent=True) or {}
    allowed_bool = [
        "critical_smoke", "high_smoke", "arduino_disconnected",
        "sensor_failure", "rapid_smoke_increase", "aqi_warning", "quiet_hours"
    ]
    numeric = ["smoke_warning", "smoke_critical", "aqi_warning_threshold", "cooldown_seconds"]
    conn = get_db()
    fields, values = [], {}
    for key in allowed_bool:
        if key in data:
            fields.append(f"{key} = :{key}")
            values[key] = 1 if bool(data[key]) else 0
    for key in numeric:
        if key in data:
            try:
                value = int(float(data[key]))
            except (TypeError, ValueError):
                conn.close()
                return jsonify({"error": f"Invalid value for {key}"}), 400
            fields.append(f"{key} = :{key}")
            values[key] = max(1, value) if key == "cooldown_seconds" else value
    for key in ["quiet_start", "quiet_end"]:
        if key in data:
            fields.append(f"{key} = :{key}")
            values[key] = str(data[key])[:5]
    if fields:
        conn.execute(f"UPDATE notification_settings SET {', '.join(fields)} WHERE id = 1", values)
        conn.commit()
    row = conn.execute("SELECT * FROM notification_settings WHERE id = 1").fetchone()
    conn.close()
    return jsonify(row_to_dict(row))


@app.route("/api/precautions")
def api_precautions():
    auth = login_required_json()
    if auth:
        return auth
    return jsonify({
        "categories": [
            {"id":"fire_smoke","title":"🔥 Fire / Critical Smoke","risk":"Critical","avoid":["Entering smoke-filled areas","Using lifts during a fire","Touching electrical/fuel sources","Returning before authorities declare the area safe"],"actions":["Evacuate","Move upwind if possible","Raise the alarm","Wait for trained fire/rescue personnel"]},
            {"id":"gas_chemical","title":"☣ Gas / Chemical / HazMat","risk":"Critical","avoid":["Unknown chemicals or spills","Flames, sparks and switches near a suspected leak","Touching or smelling unknown substances","Entering the zone without PPE/training"],"actions":["Isolate the area","Move people upwind/uphill where practical","Call HazMat/disaster response","Do not re-enter until cleared"]},
            {"id":"aqi","title":"🌫 Hazardous Air Quality","risk":"High","avoid":["Unnecessary outdoor exposure","Outdoor burning and smoke sources","Strenuous outdoor activity","Opening windows during a severe local smoke event when avoidable"],"actions":["Stay indoors where practical","Reduce exposure","Monitor AI-SAFE readings","Follow local health/emergency guidance"]},
            {"id":"sensor_failure","title":"🔌 Sensor / Arduino Failure","risk":"High","avoid":["Assuming the environment is safe because the sensor is offline","Unsafe electrical troubleshooting","Ignoring a disconnected sensor during an active incident"],"actions":["Treat the area as unknown risk","Check hardware safely","Use manual verification","Restore monitoring before normal operation"]}
        ]
    })


@app.route("/api/emergency-settings", methods=["GET", "PUT"])
def api_emergency_settings():
    auth = login_required_json()
    if auth:
        return auth
    if request.method == "PUT" and not is_admin():
        return jsonify({"error":"Only administrators can change system-wide settings"}), 403
    if request.method == "GET":
        return jsonify(get_emergency_settings())
    data = request.get_json(silent=True) or {}
    bool_keys = ["auto_dispatch", "fire_department", "ambulance", "hazmat", "police_control"]
    text_keys = ["fire_contact", "ambulance_contact", "hazmat_contact", "police_contact"]
    conn = get_db()
    fields, values = [], {}
    for key in bool_keys:
        if key in data:
            fields.append(f"{key} = :{key}")
            values[key] = 1 if bool(data[key]) else 0
    for key in text_keys:
        if key in data:
            fields.append(f"{key} = :{key}")
            values[key] = str(data[key]).strip()[:120]
    if fields:
        conn.execute(f"UPDATE emergency_settings SET {', '.join(fields)} WHERE id = 1", values)
        conn.commit()
    row = conn.execute("SELECT * FROM emergency_settings WHERE id = 1").fetchone()
    conn.close()
    return jsonify(row_to_dict(row))


@app.route("/api/emergency-dispatches")
def api_emergency_dispatches():
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    suffix, params = station_filter_sql("d")
    rows = conn.execute(f"SELECT d.* FROM emergency_dispatches d WHERE 1=1 {suffix} ORDER BY d.id DESC LIMIT 50", params).fetchall()
    conn.close()
    return jsonify([row_to_dict(r) for r in rows])


@app.route("/api/emergency-test", methods=["POST"])
def api_emergency_test():
    auth = login_required_json()
    if auth:
        return auth
    data = request.get_json(silent=True) or {}
    event = str(data.get("event_type") or "critical smoke")
    severity = str(data.get("severity") or "Critical")
    user = current_user() or {}
    station_id = int(user.get("station_id")) if user.get("station_id") else None
    if is_admin() and data.get("station_id") not in (None, ""):
        station_id = int(data.get("station_id"))
    location = str(data.get("location") or user.get("station_name") or "Punjab Station 01")
    smoke = safe_float(data.get("smoke"), 800)
    aqi = safe_float(data.get("aqi"), 320)
    settings = get_emergency_settings()
    # Test messages are allowed even when automatic dispatch is disabled, but are still labelled Demo.
    conn = get_db()
    message = build_emergency_message(event, severity, smoke, aqi, location)
    created = datetime.now().isoformat(timespec="seconds")
    targets = [("fire_department", "🔥 Fire & Rescue", settings.get("fire_contact")),
               ("ambulance", "🚑 Ambulance / Medical", settings.get("ambulance_contact")),
               ("hazmat", "☣ HazMat / Disaster Response", settings.get("hazmat_contact"))]
    rows=[]
    for key,label,recipient in targets:
        conn.execute("""INSERT INTO emergency_dispatches
            (event_type,severity,location,sensor,recipient_type,recipient,message,status,created_at,station_id)
            VALUES (?,?,?,?,?,?,?,?,?,?)""", (event,severity,location,"TEST SENSOR",key,recipient or label,message,"Test Queued",created,station_id))
    conn.commit()
    rows=conn.execute("SELECT * FROM emergency_dispatches WHERE created_at=? AND station_id IS ? ORDER BY id DESC",(created, station_id)).fetchall()
    conn.close()
    return jsonify({"success": True, "message": "Demo emergency messages queued. No external agency was contacted.", "dispatches": [row_to_dict(r) for r in rows]})


@app.route("/service-worker.js")
def service_worker():
    response = send_from_directory(BASE_DIR / "static" / "js", "service-worker.js")
    response.headers["Cache-Control"] = "no-cache"
    return response


@app.route("/firebase-messaging-sw.js")
def firebase_messaging_service_worker():
    """FCM requires this service worker at the domain root."""
    response = send_from_directory(BASE_DIR / "static" / "js", "firebase-messaging-sw.js")
    response.headers["Cache-Control"] = "no-cache"
    return response


@app.route("/api/firebase-config")
def api_firebase_config():
    auth = login_required_json()
    if auth:
        return auth
    return jsonify({
        "apiKey": os.environ.get("FIREBASE_WEB_API_KEY", ""),
        "authDomain": os.environ.get("FIREBASE_AUTH_DOMAIN", ""),
        "projectId": os.environ.get("FIREBASE_PROJECT_ID", ""),
        "storageBucket": os.environ.get("FIREBASE_STORAGE_BUCKET", ""),
        "messagingSenderId": os.environ.get("FIREBASE_MESSAGING_SENDER_ID", ""),
        "appId": os.environ.get("FIREBASE_APP_ID", ""),
        "vapidKey": os.environ.get("FIREBASE_VAPID_KEY", ""),
    })


@app.route("/api/fcm/register", methods=["POST"])
def api_fcm_register():
    auth = login_required_json()
    if auth:
        return auth
    data = request.get_json(silent=True) or {}
    fid = str(data.get("installation_id") or "").strip()
    if not fid or len(fid) > 256:
        return jsonify({"error": "A valid Firebase Installation ID is required"}), 400

    user = current_user() or {}
    user_id = int(user.get("id")) if user.get("id") else None
    if is_admin():
        requested_station = data.get("station_id")
        station_id = int(requested_station) if requested_station not in (None, "", "all") else None
    else:
        station_id = int(user.get("station_id")) if user.get("station_id") else None

    now = datetime.now().isoformat(timespec="seconds")
    conn = get_db()
    try:
        conn.execute("""
            INSERT INTO fcm_devices(user_id, installation_id, station_id, created_at, last_seen)
            VALUES(?,?,?,?,?)
            ON CONFLICT(installation_id) DO UPDATE SET
                user_id=excluded.user_id,
                station_id=excluded.station_id,
                last_seen=excluded.last_seen
        """, (user_id, fid, station_id, now, now))
        conn.commit()
    finally:
        conn.close()
    return jsonify({"success": True, "station_id": station_id, "message": "FCM browser registered"})


@app.route("/api/fcm/unregister", methods=["POST"])
def api_fcm_unregister():
    auth = login_required_json()
    if auth:
        return auth
    data = request.get_json(silent=True) or {}
    fid = str(data.get("installation_id") or "").strip()
    if not fid:
        return jsonify({"success": True})
    conn = get_db()
    conn.execute("DELETE FROM fcm_devices WHERE installation_id=? AND user_id=?", (fid, session.get("user_id")))
    conn.commit()
    conn.close()
    return jsonify({"success": True})


@app.route("/api/fcm/status")
def api_fcm_status():
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    count = conn.execute("SELECT COUNT(*) AS n FROM fcm_devices WHERE user_id=?", (session.get("user_id"),)).fetchone()["n"]
    conn.close()
    return jsonify({"configured": bool(os.environ.get("FIREBASE_PROJECT_ID") and os.environ.get("FIREBASE_VAPID_KEY")), "registered": int(count) > 0})


@app.route("/api/incidents/export")
def export_incidents():
    auth = login_required_json()
    if auth:
        return auth
    conn = get_db()
    suffix,params=station_filter_sql("i")
    rows = conn.execute(f"SELECT i.* FROM incidents i WHERE 1=1 {suffix} ORDER BY i.id DESC",params).fetchall()
    conn.close()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        "ID", "Time", "Type", "Sensor", "Severity", "Status", "Smoke Level",
        "AQI", "Temperature", "Humidity", "Latitude", "Longitude", "Description",
        "Created At", "Updated At"
    ])
    for row in rows:
        writer.writerow([row[key] for key in [
            "id", "incident_time", "incident_type", "sensor", "severity", "status",
            "smoke_level", "aqi", "temperature", "humidity", "latitude", "longitude",
            "description", "created_at", "updated_at"
        ]])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=ai-safe-incidents.csv"},
    )



@app.route("/api/advanced-insights")
def api_advanced_insights():
    auth=login_required_json()
    if auth: return auth
    dashboard=build_dashboard_data(request.args.get("source") or "Dataset 1")
    conn=get_db()
    suffix,params=station_filter_sql("i")
    incidents=[row_to_dict(r) for r in conn.execute(f"SELECT i.* FROM incidents i WHERE i.latitude IS NOT NULL AND i.longitude IS NOT NULL {suffix} ORDER BY i.id DESC LIMIT 100",params).fetchall()]
    zones=[row_to_dict(r) for r in conn.execute("SELECT * FROM safe_zones ORDER BY id").fetchall()]
    calibration=row_to_dict(conn.execute("SELECT * FROM sensor_calibration WHERE id=1").fetchone())
    conn.close()
    return jsonify({"risk":dashboard["risk_prediction"],"incidents":incidents,"safe_zones":zones,"calibration":calibration,"hardware":dashboard["hardware"]})

@app.route("/api/calibration", methods=["GET","PUT"])
def api_calibration():
    auth=login_required_json()
    if auth: return auth
    conn=get_db()
    if request.method=="PUT" and not can_manage_users():
        return jsonify({"error":"Only administrators or supervisors can calibrate devices"}), 403
    if request.method=="PUT":
        data=request.get_json(silent=True) or {}
        baseline=safe_float(data.get("baseline"),0)
        notes=str(data.get("notes") or "")[:300]
        next_due=str(data.get("next_due") or "")[:20]
        conn.execute("UPDATE sensor_calibration SET calibrated_at=?, baseline=?, notes=?, next_due=? WHERE id=1",(datetime.now().isoformat(timespec="seconds"),baseline,notes,next_due))
        conn.commit()
    row=conn.execute("SELECT * FROM sensor_calibration WHERE id=1").fetchone(); conn.close()
    return jsonify(row_to_dict(row))

@app.route("/api/database-backup")
def database_backup():
    auth=login_required_json()
    if auth: return auth
    if not is_admin():
        return jsonify({"error":"Only administrators can create database backups"}), 403
    backup=INSTANCE_DIR / f"ai-safe-backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
    src=get_db(); dst=sqlite3.connect(backup); src.backup(dst); dst.close(); src.close()
    return send_from_directory(INSTANCE_DIR, backup.name, as_attachment=True)

@app.route("/api/incidents/report.pdf")
def incident_report_pdf():
    auth=login_required_json()
    if auth: return auth
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet
    except ImportError:
        return jsonify({"error":"PDF support requires reportlab. Run pip install -r requirements.txt"}),500
    path=INSTANCE_DIR / "ai-safe-incident-report.pdf"
    conn=get_db(); suffix, params = station_filter_sql("i"); rows=conn.execute(f"SELECT i.* FROM incidents i WHERE 1=1 {suffix} ORDER BY i.id DESC LIMIT 100", params).fetchall(); conn.close()
    styles=getSampleStyleSheet(); doc=SimpleDocTemplate(str(path),pagesize=A4,rightMargin=24,leftMargin=24,topMargin=24,bottomMargin=24)
    story=[Paragraph("AI-SAFE Incident Report",styles["Title"]),Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",styles["Normal"]),Spacer(1,12)]
    data=[["Time","Type","Severity","Status","Smoke","AQI"]]+[[r["incident_time"],r["incident_type"],r["severity"],r["status"],f'{r["smoke_level"]:.0f}',f'{r["aqi"]:.0f}'] for r in rows]
    t=Table(data,repeatRows=1,colWidths=[75,100,55,60,55,45]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1269db")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.25,colors.grey),("FONTSIZE",(0,0),(-1,-1),7)])); story.append(t); doc.build(story)
    return send_from_directory(INSTANCE_DIR,path.name,as_attachment=True)


init_db()


def _auto_import_air_quality_if_missing():
    """Safety net: if the air_quality dataset hasn't been imported yet
    (fresh clone, or someone forgot to run import_air_quality.py), import
    it automatically from data/file1.csv and data/file2.csv so the
    dashboard never silently shows placeholder dashes for these values."""
    try:
        conn = get_db()
        count = conn.execute("SELECT COUNT(*) AS n FROM air_quality_summary").fetchone()["n"]
        conn.close()
        if count > 0:
            return
        data_dir = BASE_DIR / "data"
        sources = [("Dataset 1", data_dir / "file1.csv"), ("Dataset 2", data_dir / "file2.csv")]
        if not all(path.exists() for _, path in sources):
            print("[AI-SAFE] Air quality CSVs not found in data/; skipping auto-import.")
            return
        print("[AI-SAFE] air_quality_summary is empty — auto-importing dataset(s) from data/ ...")
        import import_air_quality as _import_aq
        _import_aq.main()
        print("[AI-SAFE] Auto-import finished.")
    except Exception as exc:  # never let this block app startup
        print(f"[AI-SAFE] Auto-import of air quality data skipped due to error: {exc}")


_auto_import_air_quality_if_missing()

if __name__ == "__main__":
    start_serial_reader()
    try:
        app.run(host="127.0.0.1", port=5000, debug=False)
    finally:
        stop_serial_reader()
        _camera_release()
