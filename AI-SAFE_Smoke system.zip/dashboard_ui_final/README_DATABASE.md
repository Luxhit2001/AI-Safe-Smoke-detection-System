# AI-SAFE SQLite Backend

This version adds a real SQLite backend to the existing Flask dashboard.

## Database

The application automatically creates:

```text
instance/ai_safe.db
```

The `incidents` table stores:

- incident time
- incident type
- sensor
- severity
- status
- smoke level
- AQI
- temperature
- humidity
- latitude / longitude
- description
- created / updated timestamps

A few sample records are inserted automatically only when the table is empty.

## Manual data entry

1. Log in with `admin / admin123`.
2. Open **Incidents** from the left sidebar.
3. Click **+ Add Incident**.
4. Enter the values.
5. Click **Save to Database**.
6. The dashboard refreshes from SQLite and updates the metrics, activity list, analytics and incident table.

## Edit / Delete

Every incident row has **Edit** and **Delete** buttons.

- Edit sends a `PUT` request to `/api/incidents/<id>`.
- Delete sends a `DELETE` request to `/api/incidents/<id>`.

## API endpoints

All API endpoints require the Flask login session.

```text
GET    /api/dashboard
GET    /api/incidents
POST   /api/incidents
GET    /api/incidents/<id>
PUT    /api/incidents/<id>
DELETE /api/incidents/<id>
GET    /api/incidents/export
```

## Running

```bash
pip install -r requirements.txt
python app.py
```

Open:

```text
http://127.0.0.1:5000/
```

The root URL always shows the login page. Dashboard/API access is protected by the Flask session.

## Imported air-quality datasets

The SQLite database now contains the two supplied datasets in the `air_quality` table:

- **Dataset 1:** 1,600,000 rows
- **Dataset 2:** 20,000 rows

The dashboard reads these records through `/api/dashboard` and `/api/air-quality`.
Use the **Data source** selector on the Overview page to switch between Dataset 1 and Dataset 2.

Displayed real fields are:

- NO2
- CO
- PM10
- PM2.5
- AQI (overall)
- Remarks

The supplied datasets do **not** contain timestamp, GPS, temperature, humidity, or sensor-device fields. The dashboard therefore does not invent those values. The existing incident database remains available separately for manual incident entry.

### Re-importing the CSV files

If you need to rebuild the air-quality table, keep `file1.csv` and `file2.csv` in the `data/` directory and run:

```bash
python import_air_quality.py
```

The import script uses SQLite batches and creates summary/sample tables so the dashboard does not scan 1.62 million records on every refresh.


## Multi-user Role-Based Access

This version adds SQLite-backed authentication with three roles:

- **Admin** — sees all users, all Punjab stations, all sensor readings, incidents, alerts, analytics and reports; can create/delete users.
- **Supervisor** — sees the assigned station and its permitted data.
- **User** — sees only the assigned station's AQI, PM2.5, PM10, CO, NO2, smoke readings, alerts and incidents.

New users are created from **User Management** by an Admin:

```text
Name
Username
Password
Role
Assigned Station
```

Passwords are stored as secure hashes, not plain text. The backend enforces station access; hiding dashboard controls is not the security boundary.

### Punjab Sensor Network

The map now includes multiple seeded Punjab monitoring stations with status colors:

- Punjab Station 01 — Normal
- Punjab Station 02 — Warning
- Punjab Station 03 — Critical
- Punjab Station 04 — Normal
- Punjab Station 05 — Warning

Clicking a station opens its current AQI/smoke/PM data and recent sensor history. A normal user receives only their assigned station on the network map.

### Demo

Admin:

```text
Username: admin
Password: admin123
```

After logging in as Admin, open **User Management** to create a user such as `rahul01` and assign Punjab Station 01. When Rahul logs in, the same dashboard automatically loads only Rahul's permitted station data.
